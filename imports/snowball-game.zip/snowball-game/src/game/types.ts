import type { TerrainConfig } from './ballistics';

export type Difficulty = 'easy' | 'medium' | 'hard';

export type PlayMode = 'bot' | 'online';

export interface DifficultyConfig {
  id: Difficulty;
  label: string;
  description: string;
}

export const DIFFICULTIES: DifficultyConfig[] = [
  {
    id: 'easy',
    label: 'سهل',
    description: 'يضيع كثير ويجيب مرات — مناسب للتحدي الخفيف',
  },
  {
    id: 'medium',
    label: 'متوسط',
    description: 'يصيب جسمك ويضيع ومرات يجيبها بالرأس',
  },
  {
    id: 'hard',
    label: 'صعب',
    description: 'كل ضرباته بالرأس مباشرة!',
  },
];

export type GameScreenState = 'SETUP' | 'ONLINE_LOBBY' | 'PLAYING' | 'GAME_OVER';

export type TurnOwner = 'player' | 'bot';

export type PlayerSlot = 'p1' | 'p2';

export interface OnlinePlayerInfo {
  slot: PlayerSlot;
  name: string;
  connected: boolean;
  rematchReady?: boolean;
}

export interface OnlineRoomSnapshot {
  roomId: string;
  status: 'waiting' | 'playing' | 'finished';
  yourSlot: PlayerSlot;
  players: {
    p1: OnlinePlayerInfo | null;
    p2: OnlinePlayerInfo | null;
  };
  terrain: TerrainConfig;
  turn: PlayerSlot;
  turnCount: number;
  p1X: number;
  p2X: number;
  p1Hp: number;
  p2Hp: number;
  winner: PlayerSlot | null;
  winReason?: 'ko' | 'forfeit';
}

export interface OnlineShotOutcome {
  shooterSlot: PlayerSlot;
  vx: number;
  vy: number;
  hitTarget: PlayerSlot | null;
  hitType: 'headshot' | 'body' | 'ground';
  impactX: number;
  impactY: number;
  p1X: number;
  p2X: number;
  p1Hp: number;
  p2Hp: number;
  winner: PlayerSlot | null;
  nextTurn: PlayerSlot;
  turnCount: number;
}

export interface GameResult {
  mode: PlayMode;
  winnerSlot: 'player' | 'bot' | 'p1' | 'p2';
  winnerName: string;
  didLocalWin: boolean;
  difficulty?: Difficulty;
  winReason?: 'ko' | 'forfeit';
}
