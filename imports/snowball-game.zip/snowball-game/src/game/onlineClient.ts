import type { OnlineRoomSnapshot, OnlineShotOutcome, PlayerSlot } from './types';

export interface AimSyncPayload {
  slot: PlayerSlot;
  active: boolean;
  forcePercent: number;
  angleDeg: number;
}

export interface OnlineClientHandlers {
  onRoomState: (snapshot: OnlineRoomSnapshot) => void;
  onShotBroadcast: (outcome: OnlineShotOutcome) => void;
  onAimSync: (aim: AimSyncPayload) => void;
  onError: (message: string) => void;
  onLeft: () => void;
  onConnectionChange?: (connected: boolean) => void;
}

export class OnlineGameClient {
  private ws: WebSocket | null = null;
  private handlers: OnlineClientHandlers;
  private closedManually = false;
  private reconnectTimer: ReturnType<typeof setTimeout> | null = null;
  private pendingQueue: string[] = [];
  private activeRoomToRejoin: { roomId: string; name: string } | null = null;
  private lastAimSentAt = 0;

  constructor(handlers: OnlineClientHandlers) {
    this.handlers = handlers;
  }

  setHandlers(handlers: OnlineClientHandlers): void {
    this.handlers = handlers;
  }

  connect(): void {
    if (
      this.ws &&
      (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)
    ) {
      return;
    }
    this.closedManually = false;
    const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const url = `${proto}//${window.location.host}/ws`;
    const ws = new WebSocket(url);
    this.ws = ws;

    ws.onopen = () => {
      this.handlers.onConnectionChange?.(true);
      if (this.activeRoomToRejoin) {
        ws.send(
          JSON.stringify({
            type: 'room:join',
            roomId: this.activeRoomToRejoin.roomId,
            name: this.activeRoomToRejoin.name,
          }),
        );
      }
      while (this.pendingQueue.length > 0 && ws.readyState === WebSocket.OPEN) {
        const msg = this.pendingQueue.shift();
        if (msg) ws.send(msg);
      }
    };

    ws.onmessage = (event) => {
      let msg: Record<string, unknown>;
      try {
        msg = JSON.parse(String(event.data));
      } catch {
        return;
      }

      if (msg.type === 'room:state' && msg.snapshot) {
        const snap = msg.snapshot as OnlineRoomSnapshot;
        const myInfo = snap.players[snap.yourSlot];
        if (myInfo) {
          this.activeRoomToRejoin = { roomId: snap.roomId, name: myInfo.name };
        }
        this.handlers.onRoomState(snap);
      } else if (msg.type === 'shot:broadcast' && msg.outcome) {
        this.handlers.onShotBroadcast(msg.outcome as OnlineShotOutcome);
      } else if (msg.type === 'shot:aim_sync') {
        this.handlers.onAimSync({
          slot: msg.slot as PlayerSlot,
          active: Boolean(msg.active),
          forcePercent: Number(msg.forcePercent) || 0,
          angleDeg: Number(msg.angleDeg) || 0,
        });
      } else if (msg.type === 'room:error') {
        this.handlers.onError(String(msg.error || 'حدث خطأ في الاتصال'));
      } else if (msg.type === 'room:left') {
        this.activeRoomToRejoin = null;
        this.handlers.onLeft();
      }
    };

    ws.onclose = () => {
      this.handlers.onConnectionChange?.(false);
      this.ws = null;
      if (!this.closedManually) {
        this.reconnectTimer = setTimeout(() => this.connect(), 1500);
      }
    };

    ws.onerror = () => {
      // Handled via onclose reconnect
    };
  }

  private send(payload: Record<string, unknown>): void {
    const serialized = JSON.stringify(payload);
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(serialized);
    } else {
      this.pendingQueue.push(serialized);
      this.connect();
    }
  }

  createRoom(name: string): void {
    this.activeRoomToRejoin = null;
    this.send({ type: 'room:create', name });
  }

  joinRoom(roomId: string, name: string): void {
    const code = roomId.trim().toUpperCase();
    this.activeRoomToRejoin = { roomId: code, name };
    this.send({ type: 'room:join', roomId: code, name });
  }

  startMatch(): void {
    this.send({ type: 'room:start' });
  }

  leaveRoom(): void {
    this.activeRoomToRejoin = null;
    this.send({ type: 'room:leave' });
  }

  sendAimSync(active: boolean, forcePercent: number, angleDeg: number): void {
    const now = performance.now();
    if (active && now - this.lastAimSentAt < 65) return;
    this.lastAimSentAt = now;
    this.send({ type: 'shot:aim', active, forcePercent, angleDeg });
  }

  fireShot(vx: number, vy: number): void {
    this.send({ type: 'shot:fire', vx, vy });
  }

  requestRematch(): void {
    this.send({ type: 'room:rematch' });
  }

  destroy(): void {
    this.closedManually = true;
    this.activeRoomToRejoin = null;
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    this.pendingQueue = [];
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
  }
}
