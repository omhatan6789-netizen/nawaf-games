import express from 'express';
import http from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import { WebSocket, WebSocketServer } from 'ws';
import {
  generateMatchSetup,
  MAX_HP,
  MAX_THROW_SPEED,
  MIN_THROW_SPEED,
  resolveOnlineShotOnServer,
  type TerrainConfig,
} from './src/game/ballistics.ts';
import type {
  OnlinePlayerInfo,
  OnlineRoomSnapshot,
  OnlineShotOutcome,
  PlayerSlot,
} from './src/game/types.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface ClientConn {
  id: string;
  ws: WebSocket;
  roomId: string | null;
  slot: PlayerSlot | null;
}

interface RoomPlayer extends OnlinePlayerInfo {
  clientId: string;
  disconnectTimer: ReturnType<typeof setTimeout> | null;
}

interface GameRoom {
  roomId: string;
  status: 'waiting' | 'playing' | 'finished';
  players: {
    p1: RoomPlayer | null;
    p2: RoomPlayer | null;
  };
  terrain: TerrainConfig;
  turn: PlayerSlot;
  turnCount: number;
  p1X: number;
  p2X: number;
  p1Hp: number;
  p2Hp: number;
  winner: PlayerSlot | null;
  winReason?: 'ko' | 'forfeit';
  shotLocked: boolean;
}

const rooms = new Map<string, GameRoom>();
const clients = new Map<string, ClientConn>();

function randomId(len = 6): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let out = '';
  for (let i = 0; i < len; i++) {
    out += chars[Math.floor(Math.random() * chars.length)];
  }
  return out;
}

function generateRoomCode(): string {
  let code = randomId(6);
  while (rooms.has(code)) {
    code = randomId(6);
  }
  return code;
}

function sanitizeName(raw: unknown): string {
  const text = typeof raw === 'string' ? raw.trim().slice(0, 32) : '';
  return text || 'انت';
}

function buildSnapshot(room: GameRoom, yourSlot: PlayerSlot): OnlineRoomSnapshot {
  return {
    roomId: room.roomId,
    status: room.status,
    yourSlot,
    players: {
      p1: room.players.p1
        ? {
            slot: 'p1',
            name: room.players.p1.name,
            connected: room.players.p1.connected,
            rematchReady: room.players.p1.rematchReady,
          }
        : null,
      p2: room.players.p2
        ? {
            slot: 'p2',
            name: room.players.p2.name,
            connected: room.players.p2.connected,
            rematchReady: room.players.p2.rematchReady,
          }
        : null,
    },
    terrain: room.terrain,
    turn: room.turn,
    turnCount: room.turnCount,
    p1X: room.p1X,
    p2X: room.p2X,
    p1Hp: room.p1Hp,
    p2Hp: room.p2Hp,
    winner: room.winner,
    winReason: room.winReason,
  };
}

function sendJson(ws: WebSocket, payload: unknown): void {
  if (ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify(payload));
  }
}

function broadcastRoomState(room: GameRoom): void {
  (['p1', 'p2'] as const).forEach((slot) => {
    const p = room.players[slot];
    if (!p) return;
    const conn = clients.get(p.clientId);
    if (conn) {
      sendJson(conn.ws, {
        type: 'room:state',
        snapshot: buildSnapshot(room, slot),
      });
    }
  });
}

function resetRoomMatch(room: GameRoom): void {
  const setup = generateMatchSetup();
  room.terrain = setup.terrain;
  room.status = 'playing';
  room.turn = 'p1';
  room.turnCount = 1;
  room.p1X = setup.p1X;
  room.p2X = setup.p2X;
  room.p1Hp = MAX_HP;
  room.p2Hp = MAX_HP;
  room.winner = null;
  room.winReason = undefined;
  room.shotLocked = false;
  if (room.players.p1) room.players.p1.rematchReady = false;
  if (room.players.p2) room.players.p2.rematchReady = false;
}

function removeClientFromRoom(conn: ClientConn, explicitLeave: boolean): void {
  if (!conn.roomId || !conn.slot) return;
  const room = rooms.get(conn.roomId);
  const slot = conn.slot;
  conn.roomId = null;
  conn.slot = null;
  if (!room) return;

  const player = room.players[slot];
  if (!player || player.clientId !== conn.id) return;

  if (player.disconnectTimer) {
    clearTimeout(player.disconnectTimer);
    player.disconnectTimer = null;
  }

  const otherSlot: PlayerSlot = slot === 'p1' ? 'p2' : 'p1';
  const other = room.players[otherSlot];

  if (explicitLeave || room.status === 'waiting') {
    if (room.status === 'playing' && other && other.connected) {
      room.status = 'finished';
      room.winner = otherSlot;
      room.winReason = 'forfeit';
      broadcastRoomState(room);
    } else {
      room.players[slot] = null;
      if (slot === 'p1' && other) {
        // Promote p2 to host p1 when waiting in lobby
        other.slot = 'p1';
        room.players.p1 = other;
        room.players.p2 = null;
        const otherConn = clients.get(other.clientId);
        if (otherConn) otherConn.slot = 'p1';
      }
      if (!room.players.p1 && !room.players.p2) {
        rooms.delete(room.roomId);
      } else {
        room.status = 'waiting';
        broadcastRoomState(room);
      }
    }
    return;
  }

  // Unexpected socket disconnect during active/finished game: brief grace period
  player.connected = false;
  broadcastRoomState(room);

  player.disconnectTimer = setTimeout(() => {
    const currentRoom = rooms.get(room.roomId);
    if (!currentRoom) return;
    const targetPlayer = currentRoom.players[slot];
    if (!targetPlayer || targetPlayer.connected) return;

    if (currentRoom.status === 'playing' && currentRoom.players[otherSlot]?.connected) {
      currentRoom.status = 'finished';
      currentRoom.winner = otherSlot;
      currentRoom.winReason = 'forfeit';
      broadcastRoomState(currentRoom);
    } else if (!currentRoom.players[otherSlot]?.connected) {
      rooms.delete(currentRoom.roomId);
    }
  }, 10000);
}

async function startServer(): Promise<void> {
  const app = express();
  app.use(express.json());

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true, rooms: rooms.size });
  });

  app.get('/snowball-game.zip', (_req, res) => {
    const zipPath = path.join(__dirname, 'public', 'snowball-game.zip');
    res.download(zipPath, 'snowball-game.zip');
  });

  const server = http.createServer(app);
  const wss = new WebSocketServer({ server, path: '/ws' });

  wss.on('connection', (ws) => {
    const clientId = randomId(12);
    const conn: ClientConn = {
      id: clientId,
      ws,
      roomId: null,
      slot: null,
    };
    clients.set(clientId, conn);

    ws.on('message', (raw) => {
      let msg: Record<string, unknown>;
      try {
        msg = JSON.parse(String(raw));
      } catch {
        return;
      }

      const type = String(msg.type || '');

      if (type === 'room:create') {
        removeClientFromRoom(conn, true);
        const roomId = generateRoomCode();
        const name = sanitizeName(msg.name);
        const setup = generateMatchSetup();
        const room: GameRoom = {
          roomId,
          status: 'waiting',
          players: {
            p1: {
              slot: 'p1',
              name,
              connected: true,
              rematchReady: false,
              clientId,
              disconnectTimer: null,
            },
            p2: null,
          },
          terrain: setup.terrain,
          turn: 'p1',
          turnCount: 1,
          p1X: setup.p1X,
          p2X: setup.p2X,
          p1Hp: MAX_HP,
          p2Hp: MAX_HP,
          winner: null,
          shotLocked: false,
        };
        rooms.set(roomId, room);
        conn.roomId = roomId;
        conn.slot = 'p1';
        broadcastRoomState(room);
        return;
      }

      if (type === 'room:join') {
        const roomId = String(msg.roomId || '').trim().toUpperCase();
        const name = sanitizeName(msg.name);
        const room = rooms.get(roomId);
        if (!room) {
          sendJson(ws, { type: 'room:error', error: 'الغرفة غير موجودة أو انتهت' });
          return;
        }
        if (conn.roomId === roomId && conn.slot) {
          const existing = room.players[conn.slot];
          if (existing) {
            existing.connected = true;
            existing.name = name;
          }
          broadcastRoomState(room);
          return;
        }

        removeClientFromRoom(conn, true);

        let assignSlot: PlayerSlot | null = null;
        if (!room.players.p1) {
          assignSlot = 'p1';
        } else if (!room.players.p2) {
          assignSlot = 'p2';
        } else if (!room.players.p2.connected) {
          assignSlot = 'p2';
        } else if (!room.players.p1.connected) {
          assignSlot = 'p1';
        }

        if (!assignSlot) {
          sendJson(ws, { type: 'room:error', error: 'الغرفة مكتملة بالفعل (لاعبان)' });
          return;
        }

        const prev = room.players[assignSlot];
        if (prev?.disconnectTimer) clearTimeout(prev.disconnectTimer);

        room.players[assignSlot] = {
          slot: assignSlot,
          name,
          connected: true,
          rematchReady: false,
          clientId,
          disconnectTimer: null,
        };
        conn.roomId = roomId;
        conn.slot = assignSlot;
        broadcastRoomState(room);
        return;
      }

      if (type === 'room:start') {
        if (!conn.roomId || conn.slot !== 'p1') return;
        const room = rooms.get(conn.roomId);
        if (!room || !room.players.p1 || !room.players.p2) {
          sendJson(ws, { type: 'room:error', error: 'انتظر انضمام اللاعب الثاني أولًا' });
          return;
        }
        resetRoomMatch(room);
        broadcastRoomState(room);
        return;
      }

      if (type === 'room:leave') {
        removeClientFromRoom(conn, true);
        sendJson(ws, { type: 'room:left' });
        return;
      }

      if (type === 'shot:aim') {
        if (!conn.roomId || !conn.slot) return;
        const room = rooms.get(conn.roomId);
        if (!room || room.status !== 'playing' || room.turn !== conn.slot) return;
        const otherSlot: PlayerSlot = conn.slot === 'p1' ? 'p2' : 'p1';
        const other = room.players[otherSlot];
        if (!other) return;
        const otherConn = clients.get(other.clientId);
        if (otherConn) {
          sendJson(otherConn.ws, {
            type: 'shot:aim_sync',
            slot: conn.slot,
            active: Boolean(msg.active),
            forcePercent: Number(msg.forcePercent) || 0,
            angleDeg: Number(msg.angleDeg) || 0,
          });
        }
        return;
      }

      if (type === 'shot:fire') {
        if (!conn.roomId || !conn.slot) return;
        const room = rooms.get(conn.roomId);
        if (!room || room.status !== 'playing' || room.turn !== conn.slot || room.shotLocked) {
          return;
        }

        let vx = Number(msg.vx);
        let vy = Number(msg.vy);
        if (!Number.isFinite(vx) || !Number.isFinite(vy)) return;

        // Enforce correct throw direction per side and clamp speed
        if (conn.slot === 'p1' && vx < 40) vx = 40;
        if (conn.slot === 'p2' && vx > -40) vx = -40;

        const speed = Math.hypot(vx, vy);
        const clampedSpeed = Math.max(
          MIN_THROW_SPEED,
          Math.min(MAX_THROW_SPEED * 1.05, speed || MIN_THROW_SPEED),
        );
        if (speed > 0) {
          vx = (vx / speed) * clampedSpeed;
          vy = (vy / speed) * clampedSpeed;
        }

        room.shotLocked = true;
        const resolution = resolveOnlineShotOnServer(
          room.terrain,
          conn.slot,
          vx,
          vy,
          room.p1X,
          room.p2X,
          room.p1Hp,
          room.p2Hp,
        );

        room.p1X = resolution.newP1X;
        room.p2X = resolution.newP2X;
        room.p1Hp = resolution.newP1Hp;
        room.p2Hp = resolution.newP2Hp;

        const nextTurn: PlayerSlot = conn.slot === 'p1' ? 'p2' : 'p1';
        if (!resolution.winner) {
          room.turn = nextTurn;
          if (nextTurn === 'p1') room.turnCount += 1;
        } else {
          room.status = 'finished';
          room.winner = resolution.winner;
          room.winReason = 'ko';
        }

        const outcome: OnlineShotOutcome = {
          shooterSlot: conn.slot,
          vx,
          vy,
          hitTarget: resolution.hitTarget,
          hitType: resolution.hitType,
          impactX: resolution.impactX,
          impactY: resolution.impactY,
          p1X: room.p1X,
          p2X: room.p2X,
          p1Hp: room.p1Hp,
          p2Hp: room.p2Hp,
          winner: room.winner,
          nextTurn: room.turn,
          turnCount: room.turnCount,
        };

        // Unlock after brief dispatch guard
        setTimeout(() => {
          const activeRoom = rooms.get(room.roomId);
          if (activeRoom) activeRoom.shotLocked = false;
        }, 500);

        (['p1', 'p2'] as const).forEach((slot) => {
          const p = room.players[slot];
          if (!p) return;
          const targetConn = clients.get(p.clientId);
          if (targetConn) {
            sendJson(targetConn.ws, { type: 'shot:broadcast', outcome });
          }
        });
        return;
      }

      if (type === 'room:rematch') {
        if (!conn.roomId || !conn.slot) return;
        const room = rooms.get(conn.roomId);
        if (!room || !room.players.p1 || !room.players.p2) return;
        const player = room.players[conn.slot];
        if (!player) return;
        player.rematchReady = true;

        if (room.players.p1.rematchReady && room.players.p2.rematchReady) {
          resetRoomMatch(room);
        }
        broadcastRoomState(room);
      }
    });

    ws.on('close', () => {
      removeClientFromRoom(conn, false);
      clients.delete(clientId);
    });
  });

  const isProd = process.env.NODE_ENV === 'production';
  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  const port = Number(process.env.PORT) || 3000;
  server.listen(port, '0.0.0.0', () => {
    console.log(`Snowball server running on http://0.0.0.0:${port}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
