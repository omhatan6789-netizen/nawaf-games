import express from 'express';
import http from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import { WebSocket, WebSocketServer } from 'ws';
import {
  generateMatchSetup,
  MAX_HP,
  MAX_THROW_SPEED,
  MIN_THROW_SPEED,
  resolveOnlineShotOnServer,
  type TerrainConfig,
} from './src/game/ballistics.ts';
import {
  BASE_FLOOR_Y,
  createInitialGravityWorld,
  ensureWorldGeneratedAhead,
  getSpeedAtTime,
  pruneWorldBehind,
  type GravityWorldData,
} from './src/game/gravityLevel.ts';
import {
  FLIP_IMPULSE,
  rectsOverlap,
  RUNNER_H,
  RUNNER_W,
  stepRunnerPhysics,
  type RunnerState,
} from './src/game/gravityPhysics.ts';
import type {
  ActiveGameId,
  GravitySyncRunner,
  GravityTickPayload,
  OnlinePlayerInfo,
  OnlineRoomSnapshot,
  OnlineShotOutcome,
  PlayerSlot,
} from './src/game/types.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface ClientConn {
  id: string;
  ws: WebSocket;
  roomId: string | null;
  slot: PlayerSlot | null;
}

interface RoomPlayer extends OnlinePlayerInfo {
  clientId: string;
  disconnectTimer: ReturnType<typeof setTimeout> | null;
}

interface ServerGravitySim {
  world: GravityWorldData;
  elapsedSec: number;
  cameraX: number;
  runners: Record<PlayerSlot, (RunnerState & { eliminatedAt?: number }) | null>;
  tickTimer: ReturnType<typeof setInterval> | null;
  tickCounter: number;
}

interface GameRoom {
  roomId: string;
  gameType: ActiveGameId;
  status: 'waiting' | 'playing' | 'finished';
  players: {
    p1: RoomPlayer | null;
    p2: RoomPlayer | null;
    p3: RoomPlayer | null;
  };
  // Snowball state
  terrain: TerrainConfig;
  turn: PlayerSlot;
  turnCount: number;
  p1X: number;
  p2X: number;
  p1Hp: number;
  p2Hp: number;
  shotLocked: boolean;
  // Gravity Run state
  gravity: ServerGravitySim | null;
  winner: PlayerSlot | null;
  winReason?: 'ko' | 'forfeit' | 'finish' | 'last_standing';
}

const rooms = new Map<string, GameRoom>();
const clients = new Map<string, ClientConn>();

function randomId(len = 6): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let out = '';
  for (let i = 0; i < len; i++) {
    out += chars[Math.floor(Math.random() * chars.length)];
  }
  return out;
}

function generateRoomCode(): string {
  let code = randomId(6);
  while (rooms.has(code)) {
    code = randomId(6);
  }
  return code;
}

function sanitizeName(raw: unknown): string {
  const text = typeof raw === 'string' ? raw.trim().slice(0, 32) : '';
  return text || 'انت';
}

function getAllSlots(room: GameRoom): PlayerSlot[] {
  return room.gameType === 'gravity' ? ['p1', 'p2', 'p3'] : ['p1', 'p2'];
}

function getConnectedPlayers(room: GameRoom): RoomPlayer[] {
  return getAllSlots(room)
    .map((s) => room.players[s])
    .filter((p): p is RoomPlayer => Boolean(p && p.connected));
}

function serializeRunner(
  slot: PlayerSlot,
  r: (RunnerState & { eliminatedAt?: number }) | null,
): GravitySyncRunner | null {
  if (!r) return null;
  return {
    slot,
    x: r.x,
    y: r.y,
    vy: r.vy,
    gravityDir: r.gravityDir,
    grounded: r.grounded,
    boostTimer: r.boostTimer,
    alive: r.alive,
    eliminatedAt: r.eliminatedAt,
  };
}

function buildGravityPayload(room: GameRoom): GravityTickPayload | undefined {
  if (!room.gravity) return undefined;
  return {
    elapsedSec: room.gravity.elapsedSec,
    cameraX: room.gravity.cameraX,
    finishLineX: room.gravity.world.finishLineX,
    runners: {
      p1: serializeRunner('p1', room.gravity.runners.p1),
      p2: serializeRunner('p2', room.gravity.runners.p2),
      p3: serializeRunner('p3', room.gravity.runners.p3),
    },
    winner: room.winner,
    winReason:
      room.winReason === 'finish' || room.winReason === 'last_standing' || room.winReason === 'forfeit'
        ? room.winReason
        : undefined,
  };
}

function buildSnapshot(room: GameRoom, yourSlot: PlayerSlot): OnlineRoomSnapshot {
  const mapPlayer = (slot: PlayerSlot): OnlinePlayerInfo | null => {
    const p = room.players[slot];
    return p
      ? {
          slot,
          name: p.name,
          connected: p.connected,
          rematchReady: p.rematchReady,
        }
      : null;
  };

  return {
    roomId: room.roomId,
    gameType: room.gameType,
    status: room.status,
    yourSlot,
    players: {
      p1: mapPlayer('p1'),
      p2: mapPlayer('p2'),
      p3: room.gameType === 'gravity' ? mapPlayer('p3') : undefined,
    },
    terrain: room.gameType === 'snowball' ? room.terrain : undefined,
    turn: room.gameType === 'snowball' ? room.turn : undefined,
    turnCount: room.gameType === 'snowball' ? room.turnCount : undefined,
    p1X: room.gameType === 'snowball' ? room.p1X : undefined,
    p2X: room.gameType === 'snowball' ? room.p2X : undefined,
    p1Hp: room.gameType === 'snowball' ? room.p1Hp : undefined,
    p2Hp: room.gameType === 'snowball' ? room.p2Hp : undefined,
    seed: room.gravity?.world.seed,
    gravityState: buildGravityPayload(room),
    winner: room.winner,
    winReason: room.winReason,
  };
}

function sendJson(ws: WebSocket, payload: unknown): void {
  if (ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify(payload));
  }
}

function broadcastToRoom(room: GameRoom, payload: unknown): void {
  getAllSlots(room).forEach((slot) => {
    const p = room.players[slot];
    if (!p) return;
    const conn = clients.get(p.clientId);
    if (conn) sendJson(conn.ws, payload);
  });
}

function broadcastRoomState(room: GameRoom): void {
  getAllSlots(room).forEach((slot) => {
    const p = room.players[slot];
    if (!p) return;
    const conn = clients.get(p.clientId);
    if (conn) {
      sendJson(conn.ws, {
        type: 'room:state',
        snapshot: buildSnapshot(room, slot),
      });
    }
  });
}

function stopGravityLoop(room: GameRoom): void {
  if (room.gravity?.tickTimer) {
    clearInterval(room.gravity.tickTimer);
    room.gravity.tickTimer = null;
  }
}

function createServerRunner(startX: number): RunnerState & { eliminatedAt?: number } {
  return {
    x: startX,
    y: BASE_FLOOR_Y - RUNNER_H,
    vy: 0,
    gravityDir: 1,
    grounded: true,
    coyoteTimer: 0.085,
    flipBufferTimer: 0,
    boostTimer: 0,
    runPhase: 0,
    trail: [],
    alive: true,
    stuckDir: null,
  };
}

function finishGravityMatch(
  room: GameRoom,
  winnerSlot: PlayerSlot,
  winReason: 'finish' | 'last_standing' | 'forfeit',
): void {
  if (room.status === 'finished') return;
  stopGravityLoop(room);
  room.status = 'finished';
  room.winner = winnerSlot;
  room.winReason = winReason;
  const payload = buildGravityPayload(room);
  if (payload) {
    broadcastToRoom(room, { type: 'gravity:state', state: payload });
  }
  broadcastRoomState(room);
}

function startGravitySimulation(room: GameRoom): void {
  stopGravityLoop(room);
  const world = createInitialGravityWorld();
  ensureWorldGeneratedAhead(world, 2600, 0);

  const runners: Record<PlayerSlot, (RunnerState & { eliminatedAt?: number }) | null> = {
    p1: room.players.p1 ? createServerRunner(220) : null,
    p2: room.players.p2 ? createServerRunner(198) : null,
    p3: room.players.p3 ? createServerRunner(176) : null,
  };

  room.gravity = {
    world,
    elapsedSec: 0,
    cameraX: 0,
    runners,
    tickTimer: null,
    tickCounter: 0,
  };

  const dt = 1 / 60;
  room.gravity.tickTimer = setInterval(() => {
    const activeRoom = rooms.get(room.roomId);
    if (!activeRoom || !activeRoom.gravity || activeRoom.status !== 'playing') {
      if (activeRoom) stopGravityLoop(activeRoom);
      return;
    }

    const sim = activeRoom.gravity;
    sim.elapsedSec += dt;
    const baseSpeed = getSpeedAtTime(sim.elapsedSec);
    sim.cameraX += baseSpeed * dt;

    ensureWorldGeneratedAhead(sim.world, sim.cameraX + 2200, sim.elapsedSec);
    pruneWorldBehind(sim.world, sim.cameraX - 450);

    const slots: PlayerSlot[] = ['p1', 'p2', 'p3'];
    const targetLead: Record<PlayerSlot, number> = { p1: 220, p2: 198, p3: 176 };
    const newlyEliminated: Array<{ slot: PlayerSlot; x: number }> = [];

    for (const slot of slots) {
      const r = sim.runners[slot];
      if (!r || !r.alive) continue;

      if (r.flipBufferTimer > 0) r.flipBufferTimer = Math.max(0, r.flipBufferTimer - dt);
      if (r.boostTimer > 0) r.boostTimer = Math.max(0, r.boostTimer - dt);

      let spd = baseSpeed;
      if (r.boostTimer > 0) {
        spd += 95;
      } else if (r.x < sim.cameraX + targetLead[slot]) {
        spd += 38;
      } else if (r.x > sim.cameraX + targetLead[slot] + 12) {
        spd -= 8;
      }
      if (r.x > sim.cameraX + 380) {
        spd = Math.min(spd, baseSpeed);
      }

      const outcome = stepRunnerPhysics(r, sim.world, spd * dt, dt);

      if (r.grounded && r.flipBufferTimer > 0) {
        r.gravityDir = r.gravityDir === 1 ? -1 : 1;
        r.vy = r.gravityDir * FLIP_IMPULSE;
        r.grounded = false;
        r.coyoteTimer = 0;
        r.flipBufferTimer = 0;
        broadcastToRoom(activeRoom, {
          type: 'gravity:flip',
          slot,
          x: r.x,
          y: r.y,
          vy: r.vy,
          gravityDir: r.gravityDir,
          elapsedSec: sim.elapsedSec,
        });
      }

      // Boost pad pickup
      for (let i = 0; i < sim.world.boosts.length; i++) {
        const b = sim.world.boosts[i];
        const by = b.surface === 'floor' ? b.y - 14 : b.y;
        if (rectsOverlap(r.x, r.y, RUNNER_W, RUNNER_H, b.x, by, b.width, 14)) {
          r.boostTimer = 0.95;
        }
      }

      const offScreen = r.x + RUNNER_W < sim.cameraX - 10;
      if (outcome.hitSpike || outcome.fellOut || offScreen) {
        r.alive = false;
        r.eliminatedAt = sim.elapsedSec;
        newlyEliminated.push({ slot, x: r.x });
      }
    }

    // Finish line check
    if (sim.world.finishLineX !== null) {
      const crossed = slots
        .map((s) => ({ slot: s, r: sim.runners[s] }))
        .filter((item) => item.r && item.r.alive && item.r.x + RUNNER_W >= sim.world.finishLineX!);
      if (crossed.length > 0) {
        crossed.sort((a, b) => (b.r?.x || 0) - (a.r?.x || 0));
        finishGravityMatch(activeRoom, crossed[0].slot, 'finish');
        return;
      }
    }

    // Last survivor check
    const aliveSlots = slots.filter((s) => sim.runners[s]?.alive);
    if (aliveSlots.length === 1) {
      finishGravityMatch(activeRoom, aliveSlots[0], 'last_standing');
      return;
    }
    if (aliveSlots.length === 0) {
      newlyEliminated.sort((a, b) => b.x - a.x);
      const fallbackWinner = newlyEliminated[0]?.slot || 'p1';
      finishGravityMatch(activeRoom, fallbackWinner, 'last_standing');
      return;
    }

    sim.tickCounter += 1;
    // Broadcast authoritative snapshot at 20Hz (or immediately when someone is eliminated for spectator transition)
    if (sim.tickCounter % 3 === 0 || newlyEliminated.length > 0) {
      const payload = buildGravityPayload(activeRoom);
      if (payload) {
        broadcastToRoom(activeRoom, { type: 'gravity:state', state: payload });
      }
    }
  }, 1000 / 60);
}

function resetRoomMatch(room: GameRoom): void {
  room.status = 'playing';
  room.winner = null;
  room.winReason = undefined;
  room.shotLocked = false;
  getAllSlots(room).forEach((s) => {
    const p = room.players[s];
    if (p) p.rematchReady = false;
  });

  if (room.gameType === 'gravity') {
    startGravitySimulation(room);
  } else {
    const setup = generateMatchSetup();
    room.terrain = setup.terrain;
    room.turn = 'p1';
    room.turnCount = 1;
    room.p1X = setup.p1X;
    room.p2X = setup.p2X;
    room.p1Hp = MAX_HP;
    room.p2Hp = MAX_HP;
  }
}

function removeClientFromRoom(conn: ClientConn, explicitLeave: boolean): void {
  if (!conn.roomId || !conn.slot) return;
  const room = rooms.get(conn.roomId);
  const slot = conn.slot;
  conn.roomId = null;
  conn.slot = null;
  if (!room) return;

  const player = room.players[slot];
  if (!player || player.clientId !== conn.id) return;

  if (player.disconnectTimer) {
    clearTimeout(player.disconnectTimer);
    player.disconnectTimer = null;
  }

  const slots = getAllSlots(room);
  const remainingPlayers = slots
    .filter((s) => s !== slot)
    .map((s) => room.players[s])
    .filter((p): p is RoomPlayer => Boolean(p && p.connected));

  if (explicitLeave || room.status === 'waiting') {
    if (room.status === 'playing') {
      if (room.gameType === 'gravity' && room.gravity) {
        const r = room.gravity.runners[slot];
        if (r) r.alive = false;
        const aliveRemaining = slots.filter((s) => s !== slot && room.gravity?.runners[s]?.alive);
        if (aliveRemaining.length === 1) {
          finishGravityMatch(room, aliveRemaining[0], 'forfeit');
          return;
        }
        if (remainingPlayers.length <= 1 && remainingPlayers[0]) {
          finishGravityMatch(room, remainingPlayers[0].slot, 'forfeit');
          return;
        }
        room.players[slot] = null;
        broadcastRoomState(room);
        return;
      }
      if (remainingPlayers.length >= 1) {
        room.status = 'finished';
        room.winner = remainingPlayers[0].slot;
        room.winReason = 'forfeit';
        broadcastRoomState(room);
        return;
      }
    }

    room.players[slot] = null;
    if (slot === 'p1') {
      const nextHost = room.players.p2 || room.players.p3;
      if (nextHost) {
        const oldSlot = nextHost.slot;
        nextHost.slot = 'p1';
        room.players.p1 = nextHost;
        room.players[oldSlot] = null;
        const nextConn = clients.get(nextHost.clientId);
        if (nextConn) nextConn.slot = 'p1';
        if (oldSlot === 'p2' && room.players.p3) {
          room.players.p3.slot = 'p2';
          room.players.p2 = room.players.p3;
          room.players.p3 = null;
          const p3Conn = clients.get(room.players.p2.clientId);
          if (p3Conn) p3Conn.slot = 'p2';
        }
      }
    } else if (slot === 'p2' && room.players.p3) {
      room.players.p3.slot = 'p2';
      room.players.p2 = room.players.p3;
      room.players.p3 = null;
      const p3Conn = clients.get(room.players.p2.clientId);
      if (p3Conn) p3Conn.slot = 'p2';
    }

    if (!room.players.p1 && !room.players.p2 && !room.players.p3) {
      stopGravityLoop(room);
      rooms.delete(room.roomId);
    } else {
      room.status = 'waiting';
      broadcastRoomState(room);
    }
    return;
  }

  // Unexpected socket disconnect during active/finished game
  player.connected = false;
  broadcastRoomState(room);

  player.disconnectTimer = setTimeout(() => {
    const currentRoom = rooms.get(room.roomId);
    if (!currentRoom) return;
    const targetPlayer = currentRoom.players[slot];
    if (!targetPlayer || targetPlayer.connected) return;

    const activeOthers = getConnectedPlayers(currentRoom).filter((p) => p.slot !== slot);
    if (currentRoom.status === 'playing' && currentRoom.gameType === 'gravity' && currentRoom.gravity) {
      const r = currentRoom.gravity.runners[slot];
      if (r) r.alive = false;
      const aliveSlots = getAllSlots(currentRoom).filter((s) => currentRoom.gravity?.runners[s]?.alive);
      if (aliveSlots.length === 1) {
        finishGravityMatch(currentRoom, aliveSlots[0], 'forfeit');
        return;
      }
    }

    if (currentRoom.status === 'playing' && activeOthers.length === 1) {
      if (currentRoom.gameType === 'gravity') {
        finishGravityMatch(currentRoom, activeOthers[0].slot, 'forfeit');
      } else {
        currentRoom.status = 'finished';
        currentRoom.winner = activeOthers[0].slot;
        currentRoom.winReason = 'forfeit';
        broadcastRoomState(currentRoom);
      }
    } else if (activeOthers.length === 0) {
      stopGravityLoop(currentRoom);
      rooms.delete(currentRoom.roomId);
    }
  }, 10000);
}

async function startServer(): Promise<void> {
  const app = express();
  app.use(express.json());

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true, rooms: rooms.size });
  });

  app.get('/gravity-run-game.zip', (_req, res) => {
    const zipPath = path.join(__dirname, 'public', 'gravity-run-game.zip');
    res.download(zipPath, 'gravity-run-game.zip');
  });

  app.get('/snowball-game.zip', (_req, res) => {
    const zipPath = path.join(__dirname, 'public', 'gravity-run-game.zip');
    res.download(zipPath, 'gravity-run-game.zip');
  });

  const server = http.createServer(app);
  const wss = new WebSocketServer({ server, path: '/ws' });

  wss.on('connection', (ws) => {
    const clientId = randomId(12);
    const conn: ClientConn = {
      id: clientId,
      ws,
      roomId: null,
      slot: null,
    };
    clients.set(clientId, conn);

    ws.on('message', (raw) => {
      let msg: Record<string, unknown>;
      try {
        msg = JSON.parse(String(raw));
      } catch {
        return;
      }

      const type = String(msg.type || '');

      if (type === 'room:create') {
        removeClientFromRoom(conn, true);
        const roomId = generateRoomCode();
        const name = sanitizeName(msg.name);
        const gameType: ActiveGameId = msg.gameType === 'gravity' ? 'gravity' : 'snowball';
        const setup = generateMatchSetup();
        const room: GameRoom = {
          roomId,
          gameType,
          status: 'waiting',
          players: {
            p1: {
              slot: 'p1',
              name,
              connected: true,
              rematchReady: false,
              clientId,
              disconnectTimer: null,
            },
            p2: null,
            p3: null,
          },
          terrain: setup.terrain,
          turn: 'p1',
          turnCount: 1,
          p1X: setup.p1X,
          p2X: setup.p2X,
          p1Hp: MAX_HP,
          p2Hp: MAX_HP,
          shotLocked: false,
          gravity: null,
          winner: null,
        };
        rooms.set(roomId, room);
        conn.roomId = roomId;
        conn.slot = 'p1';
        broadcastRoomState(room);
        return;
      }

      if (type === 'room:join') {
        const roomId = String(msg.roomId || '').trim().toUpperCase();
        const name = sanitizeName(msg.name);
        const room = rooms.get(roomId);
        if (!room) {
          sendJson(ws, { type: 'room:error', error: 'الغرفة غير موجودة أو انتهت' });
          return;
        }
        if (conn.roomId === roomId && conn.slot) {
          const existing = room.players[conn.slot];
          if (existing) {
            existing.connected = true;
            existing.name = name;
          }
          broadcastRoomState(room);
          return;
        }

        removeClientFromRoom(conn, true);

        const maxSlots = getAllSlots(room);
        let assignSlot: PlayerSlot | null = null;
        for (const candidate of maxSlots) {
          if (!room.players[candidate]) {
            assignSlot = candidate;
            break;
          }
        }
        if (!assignSlot) {
          for (const candidate of maxSlots) {
            if (room.players[candidate] && !room.players[candidate]!.connected) {
              assignSlot = candidate;
              break;
            }
          }
        }

        if (!assignSlot) {
          const cap = room.gameType === 'gravity' ? 3 : 2;
          sendJson(ws, { type: 'room:error', error: `الغرفة مكتملة بالفعل (${cap} لاعبين)` });
          return;
        }

        const prev = room.players[assignSlot];
        if (prev?.disconnectTimer) clearTimeout(prev.disconnectTimer);

        room.players[assignSlot] = {
          slot: assignSlot,
          name,
          connected: true,
          rematchReady: false,
          clientId,
          disconnectTimer: null,
        };
        conn.roomId = roomId;
        conn.slot = assignSlot;
        broadcastRoomState(room);
        return;
      }

      if (type === 'room:start') {
        if (!conn.roomId || conn.slot !== 'p1') return;
        const room = rooms.get(conn.roomId);
        if (!room) return;
        const connectedCount = getConnectedPlayers(room).length;
        if (connectedCount < 2) {
          sendJson(ws, { type: 'room:error', error: 'انتظر انضمام لاعب آخر على الأقل' });
          return;
        }
        resetRoomMatch(room);
        broadcastRoomState(room);
        return;
      }

      if (type === 'room:leave') {
        removeClientFromRoom(conn, true);
        sendJson(ws, { type: 'room:left' });
        return;
      }

      if (type === 'gravity:flip') {
        if (!conn.roomId || !conn.slot) return;
        const room = rooms.get(conn.roomId);
        if (!room || room.gameType !== 'gravity' || room.status !== 'playing' || !room.gravity) return;
        const runner = room.gravity.runners[conn.slot];
        if (!runner || !runner.alive) return;

        if (runner.grounded || runner.coyoteTimer > 0) {
          runner.gravityDir = runner.gravityDir === 1 ? -1 : 1;
          runner.vy = runner.gravityDir * FLIP_IMPULSE;
          runner.grounded = false;
          runner.coyoteTimer = 0;
          runner.flipBufferTimer = 0;
          broadcastToRoom(room, {
            type: 'gravity:flip',
            slot: conn.slot,
            x: runner.x,
            y: runner.y,
            vy: runner.vy,
            gravityDir: runner.gravityDir,
            elapsedSec: room.gravity.elapsedSec,
          });
        } else {
          runner.flipBufferTimer = 0.16;
        }
        return;
      }

      if (type === 'shot:aim') {
        if (!conn.roomId || !conn.slot) return;
        const room = rooms.get(conn.roomId);
        if (!room || room.gameType !== 'snowball' || room.status !== 'playing' || room.turn !== conn.slot) {
          return;
        }
        const otherSlot: PlayerSlot = conn.slot === 'p1' ? 'p2' : 'p1';
        const other = room.players[otherSlot];
        if (!other) return;
        const otherConn = clients.get(other.clientId);
        if (otherConn) {
          sendJson(otherConn.ws, {
            type: 'shot:aim_sync',
            slot: conn.slot,
            active: Boolean(msg.active),
            forcePercent: Number(msg.forcePercent) || 0,
            angleDeg: Number(msg.angleDeg) || 0,
          });
        }
        return;
      }

      if (type === 'shot:fire') {
        if (!conn.roomId || !conn.slot) return;
        const room = rooms.get(conn.roomId);
        if (
          !room ||
          room.gameType !== 'snowball' ||
          room.status !== 'playing' ||
          room.turn !== conn.slot ||
          room.shotLocked
        ) {
          return;
        }

        let vx = Number(msg.vx);
        let vy = Number(msg.vy);
        if (!Number.isFinite(vx) || !Number.isFinite(vy)) return;

        if (conn.slot === 'p1' && vx < 40) vx = 40;
        if (conn.slot === 'p2' && vx > -40) vx = -40;

        const speed = Math.hypot(vx, vy);
        const clampedSpeed = Math.max(
          MIN_THROW_SPEED,
          Math.min(MAX_THROW_SPEED * 1.05, speed || MIN_THROW_SPEED),
        );
        if (speed > 0) {
          vx = (vx / speed) * clampedSpeed;
          vy = (vy / speed) * clampedSpeed;
        }

        room.shotLocked = true;
        const resolution = resolveOnlineShotOnServer(
          room.terrain,
          conn.slot === 'p1' ? 'p1' : 'p2',
          vx,
          vy,
          room.p1X,
          room.p2X,
          room.p1Hp,
          room.p2Hp,
        );

        room.p1X = resolution.newP1X;
        room.p2X = resolution.newP2X;
        room.p1Hp = resolution.newP1Hp;
        room.p2Hp = resolution.newP2Hp;

        const nextTurn: PlayerSlot = conn.slot === 'p1' ? 'p2' : 'p1';
        if (!resolution.winner) {
          room.turn = nextTurn;
          if (nextTurn === 'p1') room.turnCount += 1;
        } else {
          room.status = 'finished';
          room.winner = resolution.winner;
          room.winReason = 'ko';
        }

        const outcome: OnlineShotOutcome = {
          shooterSlot: conn.slot,
          vx,
          vy,
          hitTarget: resolution.hitTarget,
          hitType: resolution.hitType,
          impactX: resolution.impactX,
          impactY: resolution.impactY,
          p1X: room.p1X,
          p2X: room.p2X,
          p1Hp: room.p1Hp,
          p2Hp: room.p2Hp,
          winner: room.winner,
          nextTurn: room.turn,
          turnCount: room.turnCount,
        };

        setTimeout(() => {
          const activeRoom = rooms.get(room.roomId);
          if (activeRoom) activeRoom.shotLocked = false;
        }, 500);

        (['p1', 'p2'] as const).forEach((slot) => {
          const p = room.players[slot];
          if (!p) return;
          const targetConn = clients.get(p.clientId);
          if (targetConn) {
            sendJson(targetConn.ws, { type: 'shot:broadcast', outcome });
          }
        });
        return;
      }

      if (type === 'room:rematch') {
        if (!conn.roomId || !conn.slot) return;
        const room = rooms.get(conn.roomId);
        if (!room) return;
        const player = room.players[conn.slot];
        if (!player) return;
        player.rematchReady = true;

        const connected = getConnectedPlayers(room);
        if (connected.length >= 2 && connected.every((p) => p.rematchReady)) {
          resetRoomMatch(room);
        }
        broadcastRoomState(room);
      }
    });

    ws.on('close', () => {
      removeClientFromRoom(conn, false);
      clients.delete(clientId);
    });
  });

  const isProd = process.env.NODE_ENV === 'production';
  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  const port = Number(process.env.PORT) || 3000;
  server.listen(port, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${port}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
