import { useEffect, useRef, useState } from 'react';
import { Copy, Check, Send, Users, Bot, Download, Zap, Snowflake } from 'lucide-react';
import { GravityRunArena } from './components/GravityRunArena';
import { SnowballArena } from './components/SnowballArena';
import {
  OnlineGameClient,
  type AimSyncPayload,
  type GravityFlipPayload,
} from './game/onlineClient';
import {
  closeTelegramWebApp,
  getInitialRoomCodeFromUrl,
  getTelegramDisplayName,
  initTelegramWebApp,
  shareInviteOnTelegram,
} from './game/telegram';
import {
  DIFFICULTIES,
  GRAVITY_DIFFICULTIES,
  type ActiveGameId,
  type Difficulty,
  type GameResult,
  type GameScreenState,
  type GravityTickPayload,
  type OnlineRoomSnapshot,
  type OnlineShotOutcome,
  type PlayMode,
} from './game/types';

function FighterBadge({ color, label }: { color: string; label: string }) {
  return (
    <div className="flex items-center gap-2.5 bg-[#100709]/65 border border-white/15 rounded-2xl px-3 py-2.5 flex-1 min-w-0">
      <div
        className="w-10 h-10 rounded-xl border-2 border-[#0b0e14] flex items-center justify-center shrink-0 shadow"
        style={{ backgroundColor: color }}
      >
        <svg viewBox="0 0 44 44" className="w-8 h-8 block" aria-hidden="true">
          <path d="M13 13 L11 4 L18 9 L22 3 L26 9 L33 4 L31 13 Z" fill="#facc15" stroke="#07090e" strokeWidth="2.4" strokeLinejoin="round" />
          <ellipse cx="22" cy="24" rx="14" ry="13" fill="#1f2937" stroke="#07090e" strokeWidth="2.6" />
          <rect x="7" y="12" width="30" height="7" rx="3.5" fill={color} stroke="#07090e" strokeWidth="2.4" />
          <ellipse cx="24" cy="25" rx="4.2" ry="5" fill="#ffffff" />
          <ellipse cx="30" cy="25" rx="3.8" ry="4.6" fill="#ffffff" />
          <circle cx="25.5" cy="25.2" r="1.6" fill="#07090e" />
          <circle cx="31.2" cy="25.2" r="1.5" fill="#07090e" />
        </svg>
      </div>
      <div className="min-w-0 text-right">
        <strong className="block text-sm font-extrabold text-white truncate">{label}</strong>
      </div>
    </div>
  );
}

export default function App() {
  const [activeGame, setActiveGame] = useState<ActiveGameId>('gravity');
  const [screen, setScreen] = useState<GameScreenState>('SETUP');
  const [playMode, setPlayMode] = useState<PlayMode>('bot');
  const [difficulty, setDifficulty] = useState<Difficulty>('medium');
  const [playerName, setPlayerName] = useState<string>('انت');
  const [matchKey, setMatchKey] = useState<number>(1);
  const [result, setResult] = useState<GameResult | null>(null);

  // Online multiplayer state
  const [roomInput, setRoomInput] = useState<string>('');
  const [onlineError, setOnlineError] = useState<string>('');
  const [onlineSnapshot, setOnlineSnapshot] = useState<OnlineRoomSnapshot | null>(null);
  const [latestOnlineShot, setLatestOnlineShot] = useState<{
    seq: number;
    outcome: OnlineShotOutcome;
  } | null>(null);
  const [remoteAimSync, setRemoteAimSync] = useState<AimSyncPayload | null>(null);
  const [latestGravityState, setLatestGravityState] = useState<GravityTickPayload | null>(null);
  const [latestGravityFlip, setLatestGravityFlip] = useState<{
    seq: number;
    flip: GravityFlipPayload;
  } | null>(null);
  const [copiedLink, setCopiedLink] = useState(false);
  const [downloadingZip, setDownloadingZip] = useState(false);

  const clientRef = useRef<OnlineGameClient | null>(null);
  const shotSeqRef = useRef<number>(0);
  const flipSeqRef = useRef<number>(0);
  const screenRef = useRef<GameScreenState>(screen);
  screenRef.current = screen;

  const ensureOnlineClient = (): OnlineGameClient => {
    if (!clientRef.current) {
      clientRef.current = new OnlineGameClient({
        onRoomState: (snap) => {
          setOnlineError('');
          setOnlineSnapshot(snap);
          setActiveGame(snap.gameType);

          if (snap.status === 'waiting') {
            setResult(null);
            setLatestGravityState(null);
            setLatestGravityFlip(null);
            setScreen('ONLINE_LOBBY');
          } else if (snap.status === 'playing') {
            if (snap.gravityState) {
              setLatestGravityState(snap.gravityState);
            }
            if (screenRef.current !== 'PLAYING') {
              setResult(null);
              setLatestOnlineShot(null);
              setRemoteAimSync(null);
              setLatestGravityFlip(null);
              setMatchKey((k) => k + 1);
              setScreen('PLAYING');
            }
          }
        },
        onShotBroadcast: (outcome) => {
          shotSeqRef.current += 1;
          setRemoteAimSync(null);
          setLatestOnlineShot({ seq: shotSeqRef.current, outcome });
        },
        onAimSync: (aim) => {
          setRemoteAimSync(aim);
        },
        onGravityState: (state) => {
          setLatestGravityState(state);
        },
        onGravityFlip: (flip) => {
          flipSeqRef.current += 1;
          setLatestGravityFlip({ seq: flipSeqRef.current, flip });
        },
        onError: (msg) => {
          setOnlineError(msg);
        },
        onLeft: () => {
          setOnlineSnapshot(null);
          setLatestOnlineShot(null);
          setRemoteAimSync(null);
          setLatestGravityState(null);
          setLatestGravityFlip(null);
          setResult(null);
          setScreen('SETUP');
        },
      });
      clientRef.current.connect();
    }
    return clientRef.current;
  };

  useEffect(() => {
    initTelegramWebApp();
    const resolvedName = getTelegramDisplayName();
    setPlayerName(resolvedName);

    const inviteRoomCode = getInitialRoomCodeFromUrl();
    if (inviteRoomCode) {
      setPlayMode('online');
      setRoomInput(inviteRoomCode);
      const client = ensureOnlineClient();
      client.joinRoom(inviteRoomCode, resolvedName);
    }

    return () => {
      clientRef.current?.destroy();
      clientRef.current = null;
    };
  }, []);

  const startBotMatch = () => {
    setPlayMode('bot');
    setResult(null);
    setMatchKey((k) => k + 1);
    setScreen('PLAYING');
  };

  const handleCreateOnlineRoom = () => {
    setOnlineError('');
    setPlayMode('online');
    const client = ensureOnlineClient();
    client.createRoom(playerName, activeGame);
  };

  const handleJoinOnlineRoom = () => {
    const code = roomInput.trim().toUpperCase();
    if (!code) {
      setOnlineError('اكتب رمز الغرفة أولًا');
      return;
    }
    setOnlineError('');
    setPlayMode('online');
    const client = ensureOnlineClient();
    client.joinRoom(code, playerName);
  };

  const handleLeaveOnline = () => {
    if (clientRef.current) {
      clientRef.current.leaveRoom();
    }
    setOnlineSnapshot(null);
    setLatestOnlineShot(null);
    setRemoteAimSync(null);
    setLatestGravityState(null);
    setLatestGravityFlip(null);
    setResult(null);
    setScreen('SETUP');
  };

  const handleGameOver = (gameResult: GameResult) => {
    setResult(gameResult);
    setScreen('GAME_OVER');
  };

  const handleClosePage = () => {
    const closed = closeTelegramWebApp();
    if (!closed) {
      if (playMode === 'online') {
        handleLeaveOnline();
      } else {
        setResult(null);
        setScreen('SETUP');
      }
    }
  };

  const inviteUrl = onlineSnapshot
    ? `${window.location.origin}${window.location.pathname}?room=${onlineSnapshot.roomId}`
    : '';

  const handleCopyInvite = async () => {
    if (!inviteUrl) return;
    try {
      await navigator.clipboard.writeText(inviteUrl);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    } catch {
      // Fallback ignored
    }
  };

  const handleShareTelegram = () => {
    if (!inviteUrl) return;
    const opened = shareInviteOnTelegram(inviteUrl, playerName);
    if (!opened) {
      handleCopyInvite();
    }
  };

  const handleDownloadZip = async () => {
    if (downloadingZip) return;
    setDownloadingZip(true);
    try {
      const response = await fetch('/gravity-run-game.zip');
      if (!response.ok) throw new Error('download failed');
      const blob = await response.blob();
      const blobUrl = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = blobUrl;
      link.download = 'gravity-run-game.zip';
      document.body.appendChild(link);
      link.click();
      link.remove();
      setTimeout(() => URL.revokeObjectURL(blobUrl), 1000);
    } catch {
      // Ignore transient errors
    } finally {
      setDownloadingZip(false);
    }
  };

  const mySlot = onlineSnapshot?.yourSlot || 'p1';
  const myOnlineInfo = onlineSnapshot ? onlineSnapshot.players[mySlot] : null;
  const otherSlots = (['p1', 'p2', 'p3'] as const).filter((s) => s !== mySlot);
  const oppRequestedRematch = Boolean(
    onlineSnapshot && otherSlots.some((s) => onlineSnapshot.players[s]?.rematchReady),
  );
  const iRequestedRematch = Boolean(myOnlineInfo?.rematchReady);

  return (
    <div className="min-h-dvh w-full flex flex-col items-center justify-center">
      {screen === 'SETUP' && (
        <main className="w-full max-w-[560px] mx-auto px-4 py-6">
          {/* Game Switcher */}
          <div className="grid grid-cols-2 gap-2.5 mb-4">
            <button
              type="button"
              onClick={() => {
                setActiveGame('gravity');
                setOnlineError('');
              }}
              className={`nawaf-level flex items-center justify-center gap-2 py-3 ${
                activeGame === 'gravity' ? 'active' : ''
              }`}
            >
              <Zap className="w-5 h-5" />
              <span>جري الجاذبية</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveGame('snowball');
                setOnlineError('');
              }}
              className={`nawaf-level flex items-center justify-center gap-2 py-3 ${
                activeGame === 'snowball' ? 'active' : ''
              }`}
            >
              <Snowflake className="w-5 h-5" />
              <span>كرة الثلج</span>
            </button>
          </div>

          <header className="text-center mb-5">
            <h1 className="text-[clamp(30px,8vw,40px)] font-black text-white m-0 leading-tight">
              {activeGame === 'gravity' ? 'جري الجاذبية ⚡' : 'كرة الثلج ❄️'}
            </h1>
            <p className="text-white/75 text-sm sm:text-base font-bold mt-1.5">
              {activeGame === 'gravity'
                ? 'اقلب الجاذبية وتفادَ الأشواك والصناديق — ضد البوت أو أونلاين حتى 3 لاعبين'
                : 'اسحب وصوّب كرة الثلج نحو الخصم قبل ما يطيّحك'}
            </p>
          </header>

          <section className="nawaf-panel">
            {activeGame === 'gravity' ? (
              <>
                {/* Mode Switcher for Gravity Run: Bot vs Online (2-3 Players) */}
                <div className="grid grid-cols-2 gap-2.5 mb-5">
                  <button
                    type="button"
                    onClick={() => {
                      setPlayMode('bot');
                      setOnlineError('');
                    }}
                    className={`nawaf-level flex items-center justify-center gap-2 ${
                      playMode === 'bot' ? 'active' : ''
                    }`}
                  >
                    <Bot className="w-5 h-5" />
                    <span>ضد البوت</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setPlayMode('online');
                      setOnlineError('');
                    }}
                    className={`nawaf-level flex items-center justify-center gap-2 ${
                      playMode === 'online' ? 'active' : ''
                    }`}
                  >
                    <Users className="w-5 h-5" />
                    <span>أونلاين (2–3 لاعبين)</span>
                  </button>
                </div>

                {playMode === 'bot' ? (
                  <>
                    <div className="flex items-center gap-2.5 mb-5">
                      <FighterBadge color="#ef4444" label={playerName} />
                      <span className="text-xs font-black text-white/55 shrink-0">VS</span>
                      <FighterBadge color="#3b82f6" label="البوت" />
                    </div>

                    <div className="text-sm sm:text-base font-bold text-white/80 mb-3">
                      اختر مستوى البوت
                    </div>

                    <div className="grid grid-cols-3 gap-2.5 mb-5">
                      {GRAVITY_DIFFICULTIES.map((lvl) => {
                        const isActive = difficulty === lvl.id;
                        return (
                          <button
                            key={lvl.id}
                            type="button"
                            onClick={() => setDifficulty(lvl.id)}
                            className={`nawaf-level ${isActive ? 'active' : ''}`}
                          >
                            <span className="block text-base font-black">{lvl.label}</span>
                          </button>
                        );
                      })}
                    </div>

                    <button type="button" onClick={startBotMatch} className="nawaf-start">
                      ابدأ اللعب ⚡
                    </button>
                  </>
                ) : (
                  <>
                    <div className="grid grid-cols-3 gap-2 mb-4">
                      <FighterBadge color="#ef4444" label={playerName} />
                      <FighterBadge color="#3b82f6" label="لاعب 2" />
                      <FighterBadge color="#a855f7" label="لاعب 3 (اختياري)" />
                    </div>

                    <button type="button" onClick={handleCreateOnlineRoom} className="nawaf-start mb-4">
                      إنشاء غرفة جري الجاذبية (2–3 لاعبين) 👥
                    </button>

                    <div className="relative flex items-center gap-2 my-3">
                      <div className="h-px flex-1 bg-white/15" />
                      <span className="text-xs font-bold text-white/55">أو ادخل برمز الغرفة</span>
                      <div className="h-px flex-1 bg-white/15" />
                    </div>

                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={roomInput}
                        onChange={(e) => setRoomInput(e.target.value.toUpperCase())}
                        placeholder="مثال: GRV482"
                        maxLength={8}
                        dir="ltr"
                        className="flex-1 min-w-0 rounded-xl bg-[#100709]/80 border border-white/25 px-3.5 py-3 text-center text-base font-black tracking-widest text-white placeholder:text-white/35 focus:outline-none focus:border-[#ff8994]"
                      />
                      <button
                        type="button"
                        onClick={handleJoinOnlineRoom}
                        className="px-5 rounded-xl bg-white text-[#1a1111] font-black text-sm shadow-[0_4px_0_#260609] active:translate-y-0.5 cursor-pointer whitespace-nowrap"
                      >
                        انضمام
                      </button>
                    </div>

                    {onlineError && (
                      <div className="mt-3 rounded-xl bg-[#ff3b4e]/20 border border-[#ff3b4e]/50 px-3 py-2 text-center text-sm font-bold text-[#ffd3d7]">
                        {onlineError}
                      </div>
                    )}
                  </>
                )}

                <div className="mt-4 pt-3.5 border-t border-white/10 text-center text-xs text-white/65 font-semibold leading-relaxed">
                  كل شخص يتحكم بشخصيته فقط · الصناديق والجدران توقفك بدون خسارة إلا إذا طلعت من الشاشة · خط النهاية بعد دقيقتين 🏁
                </div>
              </>
            ) : (
              <>
                {/* Mode Switcher: Bot vs Online */}
                <div className="grid grid-cols-2 gap-2.5 mb-5">
                  <button
                    type="button"
                    onClick={() => {
                      setPlayMode('bot');
                      setOnlineError('');
                    }}
                    className={`nawaf-level flex items-center justify-center gap-2 ${
                      playMode === 'bot' ? 'active' : ''
                    }`}
                  >
                    <Bot className="w-5 h-5" />
                    <span>ضد البوت</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setPlayMode('online');
                      setOnlineError('');
                    }}
                    className={`nawaf-level flex items-center justify-center gap-2 ${
                      playMode === 'online' ? 'active' : ''
                    }`}
                  >
                    <Users className="w-5 h-5" />
                    <span>أونلاين تيليجرام</span>
                  </button>
                </div>

                {playMode === 'bot' ? (
                  <>
                    <div className="flex items-center gap-2.5 mb-5">
                      <FighterBadge color="#f13a3a" label={playerName} />
                      <span className="text-xs font-black text-white/55 shrink-0">VS</span>
                      <FighterBadge color="#2eb6ff" label="البوت" />
                    </div>

                    <div className="text-sm sm:text-base font-bold text-white/80 mb-3">
                      اختر مستوى البوت
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 mb-5">
                      {DIFFICULTIES.map((lvl) => {
                        const isActive = difficulty === lvl.id;
                        return (
                          <button
                            key={lvl.id}
                            type="button"
                            onClick={() => setDifficulty(lvl.id)}
                            className={`nawaf-level ${isActive ? 'active' : ''}`}
                          >
                            <span className="block text-base font-black">{lvl.label}</span>
                            <small className="block text-[11px] font-semibold text-white/70 mt-1 leading-snug">
                              {lvl.description}
                            </small>
                          </button>
                        );
                      })}
                    </div>

                    <button type="button" onClick={startBotMatch} className="nawaf-start">
                      ابدأ اللعب ❄️
                    </button>
                  </>
                ) : (
                  <>
                    <div className="flex items-center gap-2.5 mb-4">
                      <FighterBadge color="#f13a3a" label={playerName} />
                      <span className="text-xs font-black text-white/55 shrink-0">VS</span>
                      <FighterBadge color="#2eb6ff" label="صديقك في تيليجرام" />
                    </div>

                    <button type="button" onClick={handleCreateOnlineRoom} className="nawaf-start mb-4">
                      إنشاء غرفة جديدة ونسخ الدعوة 👥
                    </button>

                    <div className="relative flex items-center gap-2 my-3">
                      <div className="h-px flex-1 bg-white/15" />
                      <span className="text-xs font-bold text-white/55">أو ادخل برمز الغرفة</span>
                      <div className="h-px flex-1 bg-white/15" />
                    </div>

                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={roomInput}
                        onChange={(e) => setRoomInput(e.target.value.toUpperCase())}
                        placeholder="مثال: SNW482"
                        maxLength={8}
                        dir="ltr"
                        className="flex-1 min-w-0 rounded-xl bg-[#100709]/80 border border-white/25 px-3.5 py-3 text-center text-base font-black tracking-widest text-white placeholder:text-white/35 focus:outline-none focus:border-[#ff8994]"
                      />
                      <button
                        type="button"
                        onClick={handleJoinOnlineRoom}
                        className="px-5 rounded-xl bg-white text-[#1a1111] font-black text-sm shadow-[0_4px_0_#260609] active:translate-y-0.5 cursor-pointer whitespace-nowrap"
                      >
                        انضمام
                      </button>
                    </div>

                    {onlineError && (
                      <div className="mt-3 rounded-xl bg-[#ff3b4e]/20 border border-[#ff3b4e]/50 px-3 py-2 text-center text-sm font-bold text-[#ffd3d7]">
                        {onlineError}
                      </div>
                    )}
                  </>
                )}

                <div className="mt-4 pt-3.5 border-t border-white/10 text-center text-xs text-white/65 font-semibold leading-relaxed">
                  اسحب للخلف للتصويب ثم اترك · ضربة الجسم = 25 ضرر · ضربة الرأس (Headshot!) = 50 ضرر
                </div>
              </>
            )}

            <button
              type="button"
              onClick={handleDownloadZip}
              disabled={downloadingZip}
              className="mt-3 w-full flex items-center justify-center gap-2 rounded-xl bg-white/10 hover:bg-white/15 border border-white/20 py-2.5 px-4 text-xs font-extrabold text-white/90 cursor-pointer transition-colors disabled:opacity-60"
            >
              <Download className="w-4 h-4" />
              <span>{downloadingZip ? 'جاري تجهيز الملف...' : 'تنزيل ملفات جري الجاذبية (ZIP)'}</span>
            </button>
          </section>
        </main>
      )}

      {screen === 'ONLINE_LOBBY' && onlineSnapshot && (
        <main className="w-full max-w-[560px] mx-auto px-4 py-6">
          <header className="text-center mb-5">
            <h1 className="text-[clamp(28px,7vw,36px)] font-black text-white m-0">
              {onlineSnapshot.gameType === 'gravity' ? 'غرفة جري الجاذبية ⚡' : 'غرفة كرة الثلج ❄️'}
            </h1>
            <p className="text-white/75 text-sm font-bold mt-1">
              رمز الغرفة:{' '}
              <span className="text-white font-black tracking-widest" dir="ltr">
                {onlineSnapshot.roomId}
              </span>
            </p>
          </header>

          <section className="nawaf-panel space-y-4">
            {(() => {
              const isGravity = onlineSnapshot.gameType === 'gravity';
              const maxPlayers = isGravity ? 3 : 2;
              const playerCount =
                (onlineSnapshot.players.p1 ? 1 : 0) +
                (onlineSnapshot.players.p2 ? 1 : 0) +
                (isGravity && onlineSnapshot.players.p3 ? 1 : 0);
              const canHostStart = playerCount >= 2;
              return (
                <>
                  <div className="text-sm font-bold text-white/80">
                    اللاعبون ({playerCount}/{maxPlayers})
                    {isGravity && playerCount === 2 && (
                      <span className="text-xs text-white/60 mr-2">
                        (تقدرون تبدأون الآن بالأحمر والأزرق أو تنتظرون الثالث بالبنفسجي!)
                      </span>
                    )}
                  </div>

                  <div className={`grid gap-2.5 ${isGravity ? 'grid-cols-3' : 'grid-cols-2'}`}>
                    <div className="rounded-2xl bg-[#100709]/75 border border-white/15 p-3 text-center">
                      <span className="inline-block w-3.5 h-3.5 rounded-full bg-[#ef4444] mb-1 border border-white/50" />
                      <strong className="block text-sm font-black text-white truncate">
                        {onlineSnapshot.players.p1?.name || 'بانتظار لاعب'}
                      </strong>
                      <small className="block text-[11px] text-white/65 mt-0.5">
                        {onlineSnapshot.players.p1 ? 'أحمر · المضيف ✓' : 'المقعد الأول'}
                      </small>
                    </div>

                    <div className="rounded-2xl bg-[#100709]/75 border border-white/15 p-3 text-center">
                      <span className="inline-block w-3.5 h-3.5 rounded-full bg-[#3b82f6] mb-1 border border-white/50" />
                      <strong className="block text-sm font-black text-white truncate">
                        {onlineSnapshot.players.p2?.name || 'بانتظار لاعب...'}
                      </strong>
                      <small className="block text-[11px] text-white/65 mt-0.5">
                        {onlineSnapshot.players.p2
                          ? onlineSnapshot.players.p2.connected
                            ? 'أزرق · منضم ✓'
                            : 'منقطع مؤقتًا...'
                          : 'المقعد الثاني'}
                      </small>
                    </div>

                    {isGravity && (
                      <div className="rounded-2xl bg-[#100709]/75 border border-white/15 p-3 text-center">
                        <span className="inline-block w-3.5 h-3.5 rounded-full bg-[#a855f7] mb-1 border border-white/50" />
                        <strong className="block text-sm font-black text-white truncate">
                          {onlineSnapshot.players.p3?.name || 'بانتظار ثالث...'}
                        </strong>
                        <small className="block text-[11px] text-white/65 mt-0.5">
                          {onlineSnapshot.players.p3
                            ? onlineSnapshot.players.p3.connected
                              ? 'بنفسجي · منضم ✓'
                              : 'منقطع مؤقتًا...'
                            : 'اختياري'}
                        </small>
                      </div>
                    )}
                  </div>

                  {playerCount < maxPlayers && (
                    <div className="rounded-2xl bg-[#100709]/65 border border-white/15 p-3.5 space-y-2.5">
                      <div className="text-xs font-bold text-white/80 text-center">
                        أرسل رابط الغرفة لأصدقائك في تيليجرام للانضمام فورًا
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        <button
                          type="button"
                          onClick={handleShareTelegram}
                          className="flex items-center justify-center gap-2 rounded-xl bg-[#229ED9] text-white font-black text-sm py-3 px-3 cursor-pointer active:scale-98"
                        >
                          <Send className="w-4 h-4" />
                          <span>مشاركة في تيليجرام</span>
                        </button>
                        <button
                          type="button"
                          onClick={handleCopyInvite}
                          className="flex items-center justify-center gap-2 rounded-xl bg-white/12 border border-white/25 text-white font-black text-sm py-3 px-3 cursor-pointer active:scale-98"
                        >
                          {copiedLink ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                          <span>{copiedLink ? 'تم نسخ الرابط!' : 'نسخ رابط الغرفة'}</span>
                        </button>
                      </div>
                    </div>
                  )}

                  {onlineSnapshot.yourSlot === 'p1' ? (
                    <button
                      type="button"
                      disabled={!canHostStart}
                      onClick={() => clientRef.current?.startMatch()}
                      className="nawaf-start disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {canHostStart
                        ? isGravity
                          ? `ابدأ السباق (${playerCount} لاعبين) ⚡`
                          : 'ابدأ المباراة 🚀'
                        : 'بانتظار انضمام لاعب ثانٍ على الأقل...'}
                    </button>
                  ) : (
                    <div className="rounded-xl bg-[#100709]/65 border border-white/15 py-3.5 px-3 text-center text-sm font-bold text-white/85">
                      انضممت بنجاح ✓ — بانتظار صاحب الغرفة لبدء المباراة...
                    </div>
                  )}
                </>
              );
            })()}

            {onlineError && (
              <div className="rounded-xl bg-[#ff3b4e]/20 border border-[#ff3b4e]/50 px-3 py-2 text-center text-sm font-bold text-[#ffd3d7]">
                {onlineError}
              </div>
            )}

            <button type="button" onClick={handleLeaveOnline} className="nawaf-secondary">
              مغادرة الغرفة
            </button>
          </section>
        </main>
      )}

      {(screen === 'PLAYING' || screen === 'GAME_OVER') && (
        <div
          className={
            activeGame === 'gravity'
              ? 'gravity-fullscreen-stage'
              : 'w-full h-dvh sm:h-[min(94dvh,860px)] sm:max-w-[460px] sm:rounded-[28px] sm:border-[3px] sm:border-white/20 sm:shadow-[0_24px_80px_rgba(0,0,0,0.65)] overflow-hidden relative'
          }
        >
          {activeGame === 'gravity' ? (
            <GravityRunArena
              key={matchKey}
              mode={playMode}
              difficulty={difficulty}
              playerName={playerName}
              onlineSnapshot={onlineSnapshot || undefined}
              onlineClient={clientRef.current || undefined}
              latestGravityState={latestGravityState}
              latestGravityFlip={latestGravityFlip}
              onExit={() => {
                if (playMode === 'online') {
                  handleLeaveOnline();
                } else {
                  setResult(null);
                  setScreen('SETUP');
                }
              }}
              onGameOver={handleGameOver}
            />
          ) : (
            <SnowballArena
              key={matchKey}
              mode={playMode}
              difficulty={difficulty}
              playerName={playerName}
              onlineSnapshot={onlineSnapshot || undefined}
              onlineClient={clientRef.current || undefined}
              latestOnlineShot={latestOnlineShot}
              remoteAimSync={remoteAimSync}
              onExit={() => {
                if (playMode === 'online') {
                  handleLeaveOnline();
                } else {
                  setResult(null);
                  setScreen('SETUP');
                }
              }}
              onGameOver={handleGameOver}
            />
          )}
        </div>
      )}

      {/* Exact Game End Overlay matching nawaf-bot-v2 */}
      {screen === 'GAME_OVER' && result && (
        <div className="online-end-overlay" role="dialog" aria-modal="true">
          <div className="online-end-card">
            <h2>{result.didLocalWin ? '🎉 مبروك الفوز!' : '🏆 انتهت المباراة!'}</h2>
            <div className="online-end-winner">{result.winnerName}</div>
            <p>
              {result.winReason === 'forfeit'
                ? `انسحب الخصم — مبروك ${result.winnerName}! الفوز لك 🏆`
                : result.winReason === 'finish'
                  ? result.didLocalWin
                    ? `وصلت خط النهاية أولًا بعد دقيقتين! مبروك ${result.winnerName} 🏆`
                    : result.mode === 'online'
                      ? `وصل ${result.winnerName} إلى خط النهاية أولًا! 🏆`
                      : 'سبقك البوت إلى خط النهاية! حاول مرة ثانية 💪'
                  : result.winReason === 'last_standing'
                    ? result.didLocalWin
                      ? `صمدت للنهاية وخرج البقية! مبروك ${result.winnerName} 🏆`
                      : `فاز ${result.winnerName} ببقائه آخر صامد في السباق 🏆`
                    : result.winReason === 'bot_crash'
                      ? `سقط البوت في الفخاخ — مبروك ${result.winnerName}! تستاهل الفوز 🏆`
                      : result.winReason === 'player_crash'
                        ? 'وقعت في الأشواك أو خرجت من الشاشة! حاول مرة ثانية 💪'
                        : result.didLocalWin
                          ? `مبروك ${result.winnerName}! تستاهل الفوز 🏆`
                          : result.mode === 'online'
                            ? `مبروك ${result.winnerName}! تستاهل الفوز 🏆`
                            : 'هارد لك! حاول مرة ثانية وهزم البوت 💪'}
            </p>
            <div className="online-end-actions">
              {result.mode === 'online' ? (
                <>
                  <button
                    type="button"
                    disabled={iRequestedRematch}
                    onClick={() => clientRef.current?.requestRematch()}
                  >
                    {iRequestedRematch
                      ? 'بانتظار موافقة الخصم...'
                      : oppRequestedRematch
                        ? 'الخصم جاهز — ابدأ جولة جديدة!'
                        : 'لعب مرة ثانية'}
                  </button>
                  <button type="button" onClick={handleLeaveOnline}>
                    الرجوع للقائمة الرئيسية
                  </button>
                  <button type="button" onClick={handleClosePage}>
                    قفل الصفحة
                  </button>
                </>
              ) : (
                <>
                  <button type="button" onClick={startBotMatch}>
                    لعب مرة ثانية
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setResult(null);
                      setScreen('SETUP');
                    }}
                  >
                    تغيير المستوى
                  </button>
                  <button type="button" onClick={handleClosePage}>
                    قفل الصفحة
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
