import {
  ARENA_HEIGHT,
  type GravityWorldData,
  type SpikeTrap,
} from './gravityLevel.ts';

export const RUNNER_W = 44;
export const RUNNER_H = 54;
export const GRAVITY_ACCEL = 3250;
export const FLIP_IMPULSE = 230;
export const MAX_VY = 1020;

export interface RunnerState {
  x: number;
  y: number;
  vy: number;
  gravityDir: 1 | -1;
  grounded: boolean;
  coyoteTimer: number;
  flipBufferTimer: number;
  boostTimer: number;
  runPhase: number;
  trail: Array<{ x: number; y: number; alpha: number }>;
  alive: boolean;
  stuckDir?: 1 | -1 | null;
}

export interface StepOutcome {
  hitSpike: boolean;
  fellOut: boolean;
  wallBlocked: boolean;
  landed: boolean;
}

export interface SimBranchResult {
  safe: boolean;
  wallBlocked: boolean;
  stepsSurvived: number;
  groundedAtEnd: boolean;
}

export function rectsOverlap(
  ax: number,
  ay: number,
  aw: number,
  ah: number,
  bx: number,
  by: number,
  bw: number,
  bh: number,
): boolean {
  return ax < bx + bw && ax + aw > bx && ay < by + bh && ay + ah > by;
}

export function getSpikeHitbox(s: SpikeTrap): { x: number; y: number; w: number; h: number } {
  if (s.dir === 'up') {
    return { x: s.x + 7, y: s.y - s.height + 6, w: Math.max(4, s.width - 14), h: s.height - 6 };
  }
  if (s.dir === 'down') {
    return { x: s.x + 7, y: s.y, w: Math.max(4, s.width - 14), h: s.height - 6 };
  }
  if (s.dir === 'left') {
    return { x: s.x - s.width + 6, y: s.y + 6, w: s.width - 6, h: Math.max(4, s.height - 12) };
  }
  return { x: s.x, y: s.y + 6, w: s.width - 6, h: Math.max(4, s.height - 12) };
}

export function checkRunnerSpikes(rx: number, ry: number, world: GravityWorldData): boolean {
  const px = rx + 6;
  const py = ry + 6;
  const pw = RUNNER_W - 12;
  const ph = RUNNER_H - 12;

  for (let i = 0; i < world.spikes.length; i++) {
    const hb = getSpikeHitbox(world.spikes[i]);
    if (rectsOverlap(px, py, pw, ph, hb.x, hb.y, hb.w, hb.h)) {
      return true;
    }
  }
  for (let i = 0; i < world.walls.length; i++) {
    const wall = world.walls[i];
    for (let j = 0; j < wall.spikes.length; j++) {
      const hb = getSpikeHitbox(wall.spikes[j]);
      if (rectsOverlap(px, py, pw, ph, hb.x, hb.y, hb.w, hb.h)) {
        return true;
      }
    }
  }
  return false;
}

/**
 * Advances one runner by dx / dt against floors, ceilings, solid walls, wooden crates, and spikes.
 * Note: Hitting the front of a wall or wooden crate DOES NOT eliminate the runner and DOES NOT drop them;
 * it keeps them cleanly clinging/hooked onto the obstacle face until they flip gravity over/under it
 * or scroll off the left edge of the screen.
 */
export function stepRunnerPhysics(
  runner: RunnerState,
  world: GravityWorldData,
  dx: number,
  dt: number,
): StepOutcome {
  const prevX = runner.x;
  const prevY = runner.y;
  const hitAllowance = Math.max(26, dx + 10);

  runner.x += dx;

  // Vertical integration unless actively clinging to an obstacle in the current gravity direction
  const isClingingInCurrentDir = runner.stuckDir === runner.gravityDir;
  if (isClingingInCurrentDir) {
    runner.vy = 0;
  } else {
    runner.vy += runner.gravityDir * GRAVITY_ACCEL * dt;
    if (runner.vy > MAX_VY) runner.vy = MAX_VY;
    if (runner.vy < -MAX_VY) runner.vy = -MAX_VY;
    runner.y += runner.vy * dt;
  }

  let landed = false;
  let wallBlocked = false;

  // Horizontal solid obstacle blocking (walls + wooden crates + floor/ceiling edges)
  const checkHorizontalBlock = (
    bx: number,
    by: number,
    bw: number,
    bh: number,
    topBottomMargin: number,
  ) => {
    if (bx + bw < runner.x - 50 || bx > runner.x + RUNNER_W + 50) return;
    const vertOverlap =
      runner.y + RUNNER_H > by + topBottomMargin && runner.y < by + bh - topBottomMargin;
    if (
      vertOverlap &&
      runner.x + RUNNER_W > bx &&
      runner.x < bx + bw &&
      prevX + RUNNER_W <= bx + hitAllowance
    ) {
      runner.x = bx - RUNNER_W - 0.5;
      wallBlocked = true;
    }
  };

  for (let i = 0; i < world.walls.length; i++) {
    const w = world.walls[i];
    checkHorizontalBlock(w.x, w.y, w.width, w.height, 8);
  }
  for (let i = 0; i < world.crates.length; i++) {
    const c = world.crates[i];
    checkHorizontalBlock(c.x, c.y, c.width, c.height, 8);
  }
  for (let i = 0; i < world.floors.length; i++) {
    const s = world.floors[i];
    const extendedH = Math.max(s.thickness, ARENA_HEIGHT - s.y + 140);
    checkHorizontalBlock(s.x, s.y, s.width, extendedH, 12);
  }
  for (let i = 0; i < world.ceilings.length; i++) {
    const s = world.ceilings[i];
    const topEdge = -140;
    const extendedH = s.y + s.thickness - topEdge;
    checkHorizontalBlock(s.x, topEdge, s.width, extendedH, 12);
  }

  if (wallBlocked) {
    // Only engage cling if we didn't just flip away from an earlier stuck orientation
    if (!runner.stuckDir || runner.stuckDir === runner.gravityDir) {
      runner.stuckDir = runner.gravityDir;
      runner.y = prevY;
      runner.vy = 0;
      landed = true;
    }
  } else {
    runner.stuckDir = null;
  }

  // Vertical landing on floors, ceilings, walls, and wooden crates
  const hOverlapStart = runner.x + 5;
  const hOverlapEnd = runner.x + RUNNER_W - 5;

  if (!wallBlocked) {
    if (runner.gravityDir === 1) {
      let bestTop: number | null = null;
      for (let i = 0; i < world.floors.length; i++) {
        const s = world.floors[i];
        if (hOverlapEnd > s.x && hOverlapStart < s.x + s.width) {
          if (prevY + RUNNER_H <= s.y + 15 && runner.y + RUNNER_H >= s.y) {
            if (bestTop === null || s.y < bestTop) bestTop = s.y;
          }
        }
      }
      for (let i = 0; i < world.walls.length; i++) {
        const w = world.walls[i];
        if (hOverlapEnd > w.x && hOverlapStart < w.x + w.width) {
          if (prevY + RUNNER_H <= w.y + 15 && runner.y + RUNNER_H >= w.y) {
            if (bestTop === null || w.y < bestTop) bestTop = w.y;
          }
        }
      }
      for (let i = 0; i < world.crates.length; i++) {
        const c = world.crates[i];
        if (hOverlapEnd > c.x && hOverlapStart < c.x + c.width) {
          if (prevY + RUNNER_H <= c.y + 15 && runner.y + RUNNER_H >= c.y) {
            if (bestTop === null || c.y < bestTop) bestTop = c.y;
          }
        }
      }
      if (bestTop !== null) {
        runner.y = bestTop - RUNNER_H;
        runner.vy = 0;
        landed = true;
      }
    } else {
      let bestBottom: number | null = null;
      for (let i = 0; i < world.ceilings.length; i++) {
        const s = world.ceilings[i];
        const bottom = s.y + s.thickness;
        if (hOverlapEnd > s.x && hOverlapStart < s.x + s.width) {
          if (prevY >= bottom - 15 && runner.y <= bottom) {
            if (bestBottom === null || bottom > bestBottom) bestBottom = bottom;
          }
        }
      }
      for (let i = 0; i < world.walls.length; i++) {
        const w = world.walls[i];
        const bottom = w.y + w.height;
        if (hOverlapEnd > w.x && hOverlapStart < w.x + w.width) {
          if (prevY >= bottom - 15 && runner.y <= bottom) {
            if (bestBottom === null || bottom > bestBottom) bestBottom = bottom;
          }
        }
      }
      for (let i = 0; i < world.crates.length; i++) {
        const c = world.crates[i];
        const bottom = c.y + c.height;
        if (hOverlapEnd > c.x && hOverlapStart < c.x + c.width) {
          if (prevY >= bottom - 15 && runner.y <= bottom) {
            if (bestBottom === null || bottom > bestBottom) bestBottom = bottom;
          }
        }
      }
      if (bestBottom !== null) {
        runner.y = bestBottom;
        runner.vy = 0;
        landed = true;
      }
    }
  }

  runner.grounded = landed;
  if (landed) {
    runner.coyoteTimer = 0.085;
  } else {
    runner.coyoteTimer = Math.max(0, runner.coyoteTimer - dt);
  }

  const hitSpike = checkRunnerSpikes(runner.x, runner.y, world);
  const fellOut = runner.y > ARENA_HEIGHT + 34 || runner.y + RUNNER_H < -34;

  return { hitSpike, fellOut, wallBlocked, landed };
}

export function simulateBotBranch(
  bot: RunnerState,
  world: GravityWorldData,
  speed: number,
  flipImmediately: boolean,
  steps = 30,
): SimBranchResult {
  const sim: RunnerState = {
    x: bot.x,
    y: bot.y,
    vy: bot.vy,
    gravityDir: bot.gravityDir,
    grounded: bot.grounded,
    coyoteTimer: bot.coyoteTimer,
    flipBufferTimer: 0,
    boostTimer: 0,
    runPhase: 0,
    trail: [],
    alive: true,
    stuckDir: bot.stuckDir ?? null,
  };

  if (flipImmediately) {
    sim.gravityDir = sim.gravityDir === 1 ? -1 : 1;
    sim.vy = sim.gravityDir * FLIP_IMPULSE;
    sim.grounded = false;
  }

  const simDt = 1 / 60;
  let wallBlocked = false;
  for (let i = 0; i < steps; i++) {
    const out = stepRunnerPhysics(sim, world, speed * simDt, simDt);
    if (out.wallBlocked) wallBlocked = true;
    if (out.hitSpike || out.fellOut) {
      return {
        safe: false,
        wallBlocked,
        stepsSurvived: i,
        groundedAtEnd: sim.grounded,
      };
    }
  }

  return {
    safe: !wallBlocked,
    wallBlocked,
    stepsSurvived: steps,
    groundedAtEnd: sim.grounded,
  };
}
