export interface SurfaceSpan {
  x: number;
  width: number;
  y: number;
  thickness: number;
}

export interface SpikeTrap {
  x: number;
  y: number;
  width: number;
  height: number;
  dir: 'up' | 'down' | 'left' | 'right';
}

export interface WallObstacle {
  x: number;
  y: number;
  width: number;
  height: number;
  spikes: SpikeTrap[];
}

export interface WoodenCrate {
  x: number;
  y: number;
  width: number;
  height: number;
  variant: 'single' | 'tall' | 'hanging';
}

export interface BoostPad {
  x: number;
  y: number;
  width: number;
  surface: 'floor' | 'ceiling';
}

export interface BiomePalette {
  id: string;
  name: string;
  skyTop: string;
  skyBottom: string;
  gridColor: string;
  parallaxFar: string;
  parallaxNear: string;
  platformFill: string;
  platformTrim: string;
  spikeFill: string;
  spikeGlow: string;
  patternType: 'circuit' | 'chevron' | 'crystal' | 'industrial' | 'stadium';
}

export const BIOMES: BiomePalette[] = [
  {
    id: 'arctic_tech',
    name: 'المختبر الجليدي',
    skyTop: '#0b1d3a',
    skyBottom: '#163f6b',
    gridColor: 'rgba(94, 210, 255, 0.13)',
    parallaxFar: '#102b52',
    parallaxNear: '#153663',
    platformFill: '#1b2b48',
    platformTrim: '#48c9ff',
    spikeFill: '#ff4757',
    spikeGlow: 'rgba(255, 71, 87, 0.45)',
    patternType: 'circuit',
  },
  {
    id: 'neon_sector',
    name: 'القطاع النيوني',
    skyTop: '#160d2e',
    skyBottom: '#2d1654',
    gridColor: 'rgba(217, 70, 239, 0.13)',
    parallaxFar: '#1f1140',
    parallaxNear: '#27144f',
    platformFill: '#24163d',
    platformTrim: '#e879f9',
    spikeFill: '#fb7185',
    spikeGlow: 'rgba(251, 113, 133, 0.45)',
    patternType: 'chevron',
  },
  {
    id: 'crystal_cavern',
    name: 'كهوف الكريستال',
    skyTop: '#072227',
    skyBottom: '#0f4c5c',
    gridColor: 'rgba(45, 212, 191, 0.13)',
    parallaxFar: '#0a313a',
    parallaxNear: '#0d3f4a',
    platformFill: '#12313b',
    platformTrim: '#2dd4bf',
    spikeFill: '#f97316',
    spikeGlow: 'rgba(249, 115, 22, 0.45)',
    patternType: 'crystal',
  },
  {
    id: 'magma_core',
    name: 'قلب المفاعل',
    skyTop: '#240b0e',
    skyBottom: '#4a141c',
    gridColor: 'rgba(248, 113, 113, 0.13)',
    parallaxFar: '#310d12',
    parallaxNear: '#3d1016',
    platformFill: '#2d1317',
    platformTrim: '#fb923c',
    spikeFill: '#facc15',
    spikeGlow: 'rgba(250, 204, 21, 0.45)',
    patternType: 'industrial',
  },
  {
    id: 'finish_arena',
    name: 'ساحة النهاية',
    skyTop: '#0d1b2a',
    skyBottom: '#1b3a4b',
    gridColor: 'rgba(250, 204, 21, 0.15)',
    parallaxFar: '#14293d',
    parallaxNear: '#19354d',
    platformFill: '#1e293b',
    platformTrim: '#facc15',
    spikeFill: '#ef4444',
    spikeGlow: 'rgba(239, 68, 68, 0.5)',
    patternType: 'stadium',
  },
];

export const ARENA_HEIGHT = 600;
export const BASE_FLOOR_Y = 510;
export const BASE_CEILING_Y = 90;
export const ROUND_DURATION_SECONDS = 120; // 2 minutes

export interface GravityWorldData {
  seed: number;
  rngState: number;
  floors: SurfaceSpan[];
  ceilings: SurfaceSpan[];
  spikes: SpikeTrap[];
  walls: WallObstacle[];
  crates: WoodenCrate[];
  boosts: BoostPad[];
  biomeOrder: BiomePalette[];
  generatedUntilX: number;
  lastPatterns: string[];
  finishLineX: number | null;
}

/** Deterministic PRNG (Mulberry32) so matches sync across online players and vary every new seed */
function nextRand(world: GravityWorldData): number {
  let t = (world.rngState += 0x6d2b79f5);
  t = Math.imul(t ^ (t >>> 15), t | 1);
  t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
}

function randRange(world: GravityWorldData, min: number, max: number): number {
  return min + nextRand(world) * (max - min);
}

function randInt(world: GravityWorldData, min: number, max: number): number {
  return Math.floor(randRange(world, min, max + 1));
}

export function getSpeedAtTime(elapsedSec: number): number {
  const progress = Math.min(1, Math.max(0, elapsedSec / ROUND_DURATION_SECONDS));
  return 345 + progress * 170;
}

export function getDifficultyFactor(elapsedSec: number): number {
  return Math.min(1, Math.max(0, elapsedSec / ROUND_DURATION_SECONDS));
}

export function createInitialGravityWorld(seedInput?: number): GravityWorldData {
  const seed =
    typeof seedInput === 'number' && Number.isFinite(seedInput)
      ? seedInput >>> 0
      : Math.floor(Math.random() * 2147483647) >>> 0;

  const world: GravityWorldData = {
    seed,
    rngState: seed || 123456789,
    floors: [{ x: -250, width: 1180, y: BASE_FLOOR_Y, thickness: 140 }],
    ceilings: [{ x: -250, width: 1180, y: 0, thickness: BASE_CEILING_Y }],
    spikes: [],
    walls: [],
    crates: [],
    boosts: [],
    biomeOrder: [],
    generatedUntilX: 930,
    lastPatterns: [],
    finishLineX: null,
  };

  // Seeded shuffle of first 4 biomes so every match looks fresh
  const coreBiomes = [...BIOMES.slice(0, 4)];
  for (let i = coreBiomes.length - 1; i > 0; i--) {
    const j = Math.floor(nextRand(world) * (i + 1));
    [coreBiomes[i], coreBiomes[j]] = [coreBiomes[j], coreBiomes[i]];
  }
  world.biomeOrder = [...coreBiomes, BIOMES[4]];

  return world;
}

function pickNonRepeatingPattern(
  world: GravityWorldData,
  candidates: string[],
): string {
  const filtered = candidates.filter((c) => !world.lastPatterns.slice(-3).includes(c));
  const pool = filtered.length > 0 ? filtered : candidates;
  const chosen = pool[Math.floor(nextRand(world) * pool.length)];
  world.lastPatterns.push(chosen);
  if (world.lastPatterns.length > 6) world.lastPatterns.shift();
  return chosen;
}

function trySpawnSafeBoostPad(
  world: GravityWorldData,
  chunkStartX: number,
  chunkLen: number,
): void {
  const padW = 76;
  const surfaceChoice: 'floor' | 'ceiling' = nextRand(world) < 0.45 ? 'ceiling' : 'floor';
  const candidateX = chunkStartX + randInt(world, 45, Math.max(55, Math.min(180, chunkLen - 220)));

  const spans = surfaceChoice === 'floor' ? world.floors : world.ceilings;
  const host = spans.find(
    (s) => s.x <= candidateX - 24 && s.x + s.width >= candidateX + padW + 115,
  );
  if (!host) return;

  const padY = surfaceChoice === 'floor' ? host.y : host.y + host.thickness;

  // Never place a boost pad near or leading straight into a spike, crate, or wall on that side
  const dangerStart = candidateX - 40;
  const dangerEnd = candidateX + padW + 170;

  for (let i = 0; i < world.spikes.length; i++) {
    const sp = world.spikes[i];
    const sameSide = surfaceChoice === 'floor' ? sp.dir === 'up' : sp.dir === 'down';
    if (sameSide && sp.x + sp.width > dangerStart && sp.x < dangerEnd) {
      return;
    }
  }
  for (let i = 0; i < world.crates.length; i++) {
    const cr = world.crates[i];
    if (cr.x + cr.width > dangerStart && cr.x < dangerEnd) {
      return;
    }
  }
  for (let i = 0; i < world.walls.length; i++) {
    const w = world.walls[i];
    if (w.x + w.width > dangerStart && w.x < dangerEnd) {
      return;
    }
  }

  world.boosts.push({
    x: candidateX,
    y: padY,
    width: padW,
    surface: surfaceChoice,
  });
}

export function ensureWorldGeneratedAhead(
  world: GravityWorldData,
  targetX: number,
  elapsedSec: number,
): void {
  while (world.generatedUntilX < targetX) {
    if (elapsedSec >= ROUND_DURATION_SECONDS - 5 && world.finishLineX === null) {
      const runwayStart = world.generatedUntilX;
      const runwayLen = 2200;
      world.floors.push({
        x: runwayStart,
        width: runwayLen,
        y: BASE_FLOOR_Y,
        thickness: 140,
      });
      world.ceilings.push({
        x: runwayStart,
        width: runwayLen,
        y: 0,
        thickness: BASE_CEILING_Y,
      });
      world.finishLineX = runwayStart + 1450;
      world.generatedUntilX = runwayStart + runwayLen;
      break;
    }

    if (world.finishLineX !== null) {
      const x = world.generatedUntilX;
      world.floors.push({ x, width: 900, y: BASE_FLOOR_Y, thickness: 140 });
      world.ceilings.push({ x, width: 900, y: 0, thickness: BASE_CEILING_Y });
      world.generatedUntilX = x + 900;
      continue;
    }

    const diff = getDifficultyFactor(elapsedSec);
    const x = world.generatedUntilX;

    let candidates: string[];
    if (diff < 0.2) {
      candidates = [
        'easy_floor_gap',
        'easy_ceil_gap',
        'single_floor_spike',
        'single_ceil_spike',
        'crate_floor_hop',
        'elevated_step',
      ];
    } else if (diff < 0.48) {
      candidates = [
        'staggered_gaps',
        'floor_and_ceil_spikes',
        'crate_floor_hop',
        'crate_ceiling_hang',
        'crate_and_spike_mix',
        'center_pillar_clean',
        'elevated_step',
        'boost_leap',
        'wall_edge_spike_single',
      ];
    } else if (diff < 0.75) {
      candidates = [
        'staggered_gaps',
        'crate_double_stagger',
        'crate_and_spike_mix',
        'wall_edge_spike_single',
        'wall_pillar_spiked',
        'sawtooth_corridor',
        'flip_slalom',
        'boost_leap',
      ];
    } else {
      candidates = [
        'crate_double_stagger',
        'wall_pillar_spiked',
        'dual_wall_spikes',
        'sawtooth_corridor',
        'flip_slalom',
        'narrow_spike_gate',
        'crate_and_spike_mix',
        'boost_leap',
      ];
    }

    const pattern = pickNonRepeatingPattern(world, candidates);
    const jitterX = randInt(world, -26, 36);
    const fy = BASE_FLOOR_Y;
    const cy = BASE_CEILING_Y;

    let chunkLen = 580 + randInt(world, -20, 60);

    if (pattern === 'easy_floor_gap') {
      chunkLen = 560 + randInt(world, 0, 50);
      const pre = randInt(world, 130, 210);
      const gapW = 145 + Math.round(diff * 65) + randInt(world, 0, 25);
      world.floors.push({ x, width: pre, y: BASE_FLOOR_Y, thickness: 140 });
      world.floors.push({ x: x + pre + gapW, width: chunkLen - pre - gapW, y: BASE_FLOOR_Y, thickness: 140 });
      world.ceilings.push({ x, width: chunkLen, y: 0, thickness: BASE_CEILING_Y });
    } else if (pattern === 'easy_ceil_gap') {
      chunkLen = 560 + randInt(world, 0, 50);
      const pre = randInt(world, 130, 210);
      const gapW = 145 + Math.round(diff * 65) + randInt(world, 0, 25);
      world.floors.push({ x, width: chunkLen, y: BASE_FLOOR_Y, thickness: 140 });
      world.ceilings.push({ x, width: pre, y: 0, thickness: BASE_CEILING_Y });
      world.ceilings.push({ x: x + pre + gapW, width: chunkLen - pre - gapW, y: 0, thickness: BASE_CEILING_Y });
    } else if (pattern === 'single_floor_spike') {
      chunkLen = 560 + randInt(world, -10, 50);
      const spikeW = 70 + Math.round(diff * 30);
      const sx = x + randInt(world, 175, 295);
      world.floors.push({ x, width: chunkLen, y: BASE_FLOOR_Y, thickness: 140 });
      world.ceilings.push({ x, width: chunkLen, y: 0, thickness: BASE_CEILING_Y });
      world.spikes.push({ x: sx, y: BASE_FLOOR_Y, width: spikeW, height: 24, dir: 'up' });
    } else if (pattern === 'single_ceil_spike') {
      chunkLen = 560 + randInt(world, -10, 50);
      const spikeW = 70 + Math.round(diff * 30);
      const sx = x + randInt(world, 175, 295);
      world.floors.push({ x, width: chunkLen, y: BASE_FLOOR_Y, thickness: 140 });
      world.ceilings.push({ x, width: chunkLen, y: 0, thickness: BASE_CEILING_Y });
      world.spikes.push({ x: sx, y: BASE_CEILING_Y, width: spikeW, height: 24, dir: 'down' });
    } else if (pattern === 'crate_floor_hop') {
      chunkLen = 620 + randInt(world, 0, 60);
      const crateSize = randInt(world, 58, 78);
      const tall = nextRand(world) < 0.38 + diff * 0.3;
      const crateH = tall ? crateSize + 28 : crateSize;
      const cx = x + randInt(world, 200, 320);
      world.floors.push({ x, width: chunkLen, y: BASE_FLOOR_Y, thickness: 140 });
      world.ceilings.push({ x, width: chunkLen, y: 0, thickness: BASE_CEILING_Y });
      world.crates.push({
        x: cx,
        y: BASE_FLOOR_Y - crateH,
        width: crateSize,
        height: crateH,
        variant: tall ? 'tall' : 'single',
      });
    } else if (pattern === 'crate_ceiling_hang') {
      chunkLen = 640 + randInt(world, 0, 60);
      const cw = randInt(world, 60, 78);
      const ch = randInt(world, 64, 96);
      const cx = x + randInt(world, 180, 310);
      world.floors.push({ x, width: chunkLen, y: BASE_FLOOR_Y, thickness: 140 });
      world.ceilings.push({ x, width: chunkLen, y: 0, thickness: BASE_CEILING_Y });
      world.crates.push({
        x: cx,
        y: BASE_CEILING_Y,
        width: cw,
        height: ch,
        variant: 'hanging',
      });
    } else if (pattern === 'crate_double_stagger') {
      chunkLen = 780 + randInt(world, 0, 60);
      const c1H = randInt(world, 64, 92);
      const c2H = randInt(world, 64, 92);
      const firstOnFloor = nextRand(world) < 0.5;
      world.floors.push({ x, width: chunkLen, y: BASE_FLOOR_Y, thickness: 140 });
      world.ceilings.push({ x, width: chunkLen, y: 0, thickness: BASE_CEILING_Y });
      world.crates.push({
        x: x + randInt(world, 150, 220),
        y: firstOnFloor ? BASE_FLOOR_Y - c1H : BASE_CEILING_Y,
        width: 66,
        height: c1H,
        variant: firstOnFloor ? 'tall' : 'hanging',
      });
      world.crates.push({
        x: x + randInt(world, 450, 540),
        y: firstOnFloor ? BASE_CEILING_Y : BASE_FLOOR_Y - c2H,
        width: 66,
        height: c2H,
        variant: firstOnFloor ? 'hanging' : 'tall',
      });
    } else if (pattern === 'crate_and_spike_mix') {
      chunkLen = 740 + randInt(world, 0, 60);
      const crateOnFloor = nextRand(world) < 0.5;
      const crateH = randInt(world, 62, 88);
      world.floors.push({ x, width: chunkLen, y: BASE_FLOOR_Y, thickness: 140 });
      world.ceilings.push({ x, width: chunkLen, y: 0, thickness: BASE_CEILING_Y });
      world.crates.push({
        x: x + randInt(world, 165, 230),
        y: crateOnFloor ? BASE_FLOOR_Y - crateH : BASE_CEILING_Y,
        width: 66,
        height: crateH,
        variant: crateOnFloor ? 'single' : 'hanging',
      });
      world.spikes.push({
        x: x + randInt(world, 430, 510),
        y: crateOnFloor ? BASE_CEILING_Y : BASE_FLOOR_Y,
        width: randInt(world, 72, 96),
        height: 24,
        dir: crateOnFloor ? 'down' : 'up',
      });
    } else if (pattern === 'elevated_step') {
      chunkLen = 650;
      const stepLift = randInt(world, 52, 68);
      const midY = BASE_FLOOR_Y - stepLift;
      world.floors.push({ x, width: 175, y: BASE_FLOOR_Y, thickness: 140 });
      world.floors.push({ x: x + 175, width: 270, y: midY, thickness: 140 + stepLift });
      world.floors.push({ x: x + 445, width: 205, y: BASE_FLOOR_Y, thickness: 140 });
      world.ceilings.push({ x, width: chunkLen, y: 0, thickness: BASE_CEILING_Y });
      if (diff > 0.3) {
        world.spikes.push({
          x: x + randInt(world, 235, 315),
          y: BASE_CEILING_Y,
          width: 78,
          height: 24,
          dir: 'down',
        });
      }
    } else if (pattern === 'staggered_gaps') {
      chunkLen = 760 + randInt(world, 0, 50);
      const gapW = 160 + Math.round(diff * 55);
      const p1 = randInt(world, 125, 175);
      world.floors.push({ x, width: p1, y: fy, thickness: 140 });
      world.floors.push({ x: x + p1 + gapW, width: chunkLen - p1 - gapW, y: BASE_FLOOR_Y, thickness: 140 });
      const c1 = randInt(world, 390, 445);
      world.ceilings.push({ x, width: c1, y: 0, thickness: cy });
      world.ceilings.push({ x: x + c1 + gapW, width: chunkLen - c1 - gapW, y: 0, thickness: BASE_CEILING_Y });
    } else if (pattern === 'floor_and_ceil_spikes') {
      chunkLen = 720;
      world.floors.push({ x, width: chunkLen, y: fy, thickness: 140 });
      world.ceilings.push({ x, width: chunkLen, y: 0, thickness: cy });
      const firstFloor = nextRand(world) < 0.5;
      world.spikes.push({
        x: x + randInt(world, 140, 200),
        y: firstFloor ? fy : cy,
        width: 82,
        height: 24,
        dir: firstFloor ? 'up' : 'down',
      });
      world.spikes.push({
        x: x + randInt(world, 405, 485),
        y: firstFloor ? cy : fy,
        width: 86,
        height: 24,
        dir: firstFloor ? 'down' : 'up',
      });
    } else if (pattern === 'center_pillar_clean') {
      chunkLen = 680;
      world.floors.push({ x, width: chunkLen, y: BASE_FLOOR_Y, thickness: 140 });
      world.ceilings.push({ x, width: chunkLen, y: 0, thickness: BASE_CEILING_Y });
      const blockY = randInt(world, 205, 275);
      world.walls.push({
        x: x + 260 + jitterX,
        y: blockY,
        width: randInt(world, 95, 130),
        height: randInt(world, 95, 125),
        spikes: [],
      });
    } else if (pattern === 'wall_edge_spike_single') {
      chunkLen = 730;
      world.floors.push({ x, width: chunkLen, y: BASE_FLOOR_Y, thickness: 140 });
      world.ceilings.push({ x, width: chunkLen, y: 0, thickness: BASE_CEILING_Y });
      const onFloor = nextRand(world) < 0.5;
      const wx = x + randInt(world, 240, 320);
      const wallH = randInt(world, 110, 136);
      if (onFloor) {
        const wallY = BASE_FLOOR_Y - wallH;
        world.walls.push({
          x: wx,
          y: wallY,
          width: 74,
          height: wallH,
          spikes: [{ x: wx, y: wallY + 18, width: 20, height: wallH - 36, dir: 'left' }],
        });
      } else {
        world.walls.push({
          x: wx,
          y: BASE_CEILING_Y,
          width: 74,
          height: wallH,
          spikes: [{ x: wx, y: BASE_CEILING_Y + 18, width: 20, height: wallH - 36, dir: 'left' }],
        });
      }
    } else if (pattern === 'wall_pillar_spiked') {
      chunkLen = 770;
      world.floors.push({ x, width: chunkLen, y: BASE_FLOOR_Y, thickness: 140 });
      world.ceilings.push({ x, width: chunkLen, y: 0, thickness: BASE_CEILING_Y });
      const wallH = randInt(world, 100, 124);
      const wallY = randInt(world, 225, 260);
      const wx = x + randInt(world, 265, 335);
      const spikeFloor = nextRand(world) < 0.5;
      world.walls.push({
        x: wx,
        y: wallY,
        width: 108,
        height: wallH,
        spikes: [{ x: wx, y: wallY + 16, width: 20, height: wallH - 32, dir: 'left' }],
      });
      if (spikeFloor) {
        world.spikes.push({ x: wx + 12, y: BASE_FLOOR_Y, width: 84, height: 24, dir: 'up' });
      } else {
        world.spikes.push({ x: wx + 12, y: BASE_CEILING_Y, width: 84, height: 24, dir: 'down' });
      }
    } else if (pattern === 'dual_wall_spikes') {
      chunkLen = 860;
      world.floors.push({ x, width: chunkLen, y: BASE_FLOOR_Y, thickness: 140 });
      world.ceilings.push({ x, width: chunkLen, y: 0, thickness: BASE_CEILING_Y });
      const flipOrder = nextRand(world) < 0.5;
      const w1x = x + randInt(world, 185, 235);
      const w2x = x + randInt(world, 515, 575);
      if (flipOrder) {
        world.walls.push({
          x: w1x,
          y: BASE_FLOOR_Y - 122,
          width: 68,
          height: 122,
          spikes: [{ x: w1x, y: BASE_FLOOR_Y - 104, width: 20, height: 84, dir: 'left' }],
        });
        world.walls.push({
          x: w2x,
          y: BASE_CEILING_Y,
          width: 68,
          height: 122,
          spikes: [{ x: w2x, y: BASE_CEILING_Y + 18, width: 20, height: 84, dir: 'left' }],
        });
      } else {
        world.walls.push({
          x: w1x,
          y: BASE_CEILING_Y,
          width: 68,
          height: 122,
          spikes: [{ x: w1x, y: BASE_CEILING_Y + 18, width: 20, height: 84, dir: 'left' }],
        });
        world.walls.push({
          x: w2x,
          y: BASE_FLOOR_Y - 122,
          width: 68,
          height: 122,
          spikes: [{ x: w2x, y: BASE_FLOOR_Y - 104, width: 20, height: 84, dir: 'left' }],
        });
      }
    } else if (pattern === 'sawtooth_corridor') {
      chunkLen = 840;
      world.floors.push({ x, width: chunkLen, y: BASE_FLOOR_Y, thickness: 140 });
      world.ceilings.push({ x, width: chunkLen, y: 0, thickness: BASE_CEILING_Y });
      const startTop = nextRand(world) < 0.5;
      world.spikes.push({
        x: x + randInt(world, 130, 175),
        y: startTop ? BASE_CEILING_Y : BASE_FLOOR_Y,
        width: 76,
        height: 24,
        dir: startTop ? 'down' : 'up',
      });
      world.spikes.push({
        x: x + randInt(world, 350, 405),
        y: startTop ? BASE_FLOOR_Y : BASE_CEILING_Y,
        width: 80,
        height: 24,
        dir: startTop ? 'up' : 'down',
      });
      world.spikes.push({
        x: x + randInt(world, 570, 630),
        y: startTop ? BASE_CEILING_Y : BASE_FLOOR_Y,
        width: 76,
        height: 24,
        dir: startTop ? 'down' : 'up',
      });
    } else if (pattern === 'flip_slalom') {
      chunkLen = 880;
      world.floors.push({ x, width: 235, y: BASE_FLOOR_Y, thickness: 140 });
      world.floors.push({ x: x + 425, width: 455, y: BASE_FLOOR_Y, thickness: 140 });
      world.ceilings.push({ x, width: 530, y: 0, thickness: BASE_CEILING_Y });
      world.ceilings.push({ x: x + 715, width: 165, y: 0, thickness: BASE_CEILING_Y });
      world.spikes.push({ x: x + randInt(world, 475, 535), y: BASE_FLOOR_Y, width: 64, height: 24, dir: 'up' });
    } else if (pattern === 'narrow_spike_gate') {
      chunkLen = 760;
      world.floors.push({ x, width: chunkLen, y: BASE_FLOOR_Y, thickness: 140 });
      world.ceilings.push({ x, width: chunkLen, y: 0, thickness: BASE_CEILING_Y });
      const wallX = x + randInt(world, 240, 290);
      world.walls.push({
        x: wallX,
        y: randInt(world, 255, 290),
        width: 225,
        height: 44,
        spikes: [],
      });
      world.spikes.push({ x: wallX + 20, y: BASE_FLOOR_Y, width: 170, height: 24, dir: 'up' });
      world.spikes.push({ x: wallX + 20, y: BASE_CEILING_Y, width: 170, height: 24, dir: 'down' });
    } else {
      // boost_leap
      chunkLen = 780;
      world.floors.push({ x, width: 315, y: BASE_FLOOR_Y, thickness: 140 });
      world.floors.push({ x: x + 505, width: 275, y: BASE_FLOOR_Y, thickness: 140 });
      world.ceilings.push({ x, width: chunkLen, y: 0, thickness: BASE_CEILING_Y });
      world.boosts.push({
        x: x + randInt(world, 100, 155),
        y: BASE_FLOOR_Y,
        width: 84,
        surface: 'floor',
      });
      world.spikes.push({
        x: x + randInt(world, 560, 625),
        y: BASE_CEILING_Y,
        width: 68,
        height: 24,
        dir: 'down',
      });
    }

    // Randomized bonus boost pads (validated flush on real surfaces & clear of traps/pits)
    if (pattern !== 'boost_leap' && nextRand(world) < 0.28) {
      trySpawnSafeBoostPad(world, x, chunkLen);
    }

    world.generatedUntilX = x + chunkLen;
  }
}

export function pruneWorldBehind(world: GravityWorldData, minX: number): void {
  world.floors = world.floors.filter((s) => s.x + s.width > minX);
  world.ceilings = world.ceilings.filter((s) => s.x + s.width > minX);
  world.spikes = world.spikes.filter((s) => s.x + s.width > minX);
  world.walls = world.walls.filter((w) => w.x + w.width > minX);
  world.crates = world.crates.filter((c) => c.x + c.width > minX);
  world.boosts = world.boosts.filter((b) => b.x + b.width > minX);
}
