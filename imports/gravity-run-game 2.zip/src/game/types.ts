import type { TerrainConfig } from './ballistics';

export type ActiveGameId = 'gravity' | 'snowball';

export type Difficulty = 'easy' | 'medium' | 'hard';

export type PlayMode = 'bot' | 'online';

export interface DifficultyConfig {
  id: Difficulty;
  label: string;
  description: string;
}

export const DIFFICULTIES: DifficultyConfig[] = [
  {
    id: 'easy',
    label: 'سهل',
    description: 'يضيع كثير ويجيب مرات — مناسب للتحدي الخفيف',
  },
  {
    id: 'medium',
    label: 'متوسط',
    description: 'يصيب جسمك ويضيع ومرات يجيبها بالرأس',
  },
  {
    id: 'hard',
    label: 'صعب',
    description: 'كل ضرباته بالرأس مباشرة!',
  },
];

export const GRAVITY_DIFFICULTIES: DifficultyConfig[] = [
  {
    id: 'easy',
    label: 'سهل',
    description: '',
  },
  {
    id: 'medium',
    label: 'متوسط',
    description: '',
  },
  {
    id: 'hard',
    label: 'صعب',
    description: '',
  },
];

export type GameScreenState = 'SETUP' | 'ONLINE_LOBBY' | 'PLAYING' | 'GAME_OVER';

export type TurnOwner = 'player' | 'bot';

export type PlayerSlot = 'p1' | 'p2' | 'p3';

export interface OnlinePlayerInfo {
  slot: PlayerSlot;
  name: string;
  connected: boolean;
  rematchReady?: boolean;
}

export interface GravitySyncRunner {
  slot: PlayerSlot;
  x: number;
  y: number;
  vy: number;
  gravityDir: 1 | -1;
  grounded: boolean;
  boostTimer: number;
  alive: boolean;
  eliminatedAt?: number;
}

export interface GravityTickPayload {
  elapsedSec: number;
  cameraX: number;
  finishLineX: number | null;
  runners: {
    p1: GravitySyncRunner | null;
    p2: GravitySyncRunner | null;
    p3: GravitySyncRunner | null;
  };
  winner: PlayerSlot | null;
  winReason?: 'finish' | 'last_standing' | 'forfeit';
}

export interface OnlineRoomSnapshot {
  roomId: string;
  gameType: ActiveGameId;
  status: 'waiting' | 'playing' | 'finished';
  yourSlot: PlayerSlot;
  players: {
    p1: OnlinePlayerInfo | null;
    p2: OnlinePlayerInfo | null;
    p3?: OnlinePlayerInfo | null;
  };
  // Snowball fields
  terrain?: TerrainConfig;
  turn?: PlayerSlot;
  turnCount?: number;
  p1X?: number;
  p2X?: number;
  p1Hp?: number;
  p2Hp?: number;
  // Gravity Run fields
  seed?: number;
  gravityState?: GravityTickPayload;
  winner: PlayerSlot | null;
  winReason?: 'ko' | 'forfeit' | 'finish' | 'last_standing';
}

export interface OnlineShotOutcome {
  shooterSlot: PlayerSlot;
  vx: number;
  vy: number;
  hitTarget: PlayerSlot | null;
  hitType: 'headshot' | 'body' | 'ground';
  impactX: number;
  impactY: number;
  p1X: number;
  p2X: number;
  p1Hp: number;
  p2Hp: number;
  winner: PlayerSlot | null;
  nextTurn: PlayerSlot;
  turnCount: number;
}

export interface GameResult {
  gameId?: ActiveGameId;
  mode: PlayMode;
  winnerSlot: 'player' | 'bot' | 'p1' | 'p2' | 'p3';
  winnerName: string;
  didLocalWin: boolean;
  difficulty?: Difficulty;
  winReason?: 'ko' | 'forfeit' | 'finish' | 'bot_crash' | 'player_crash' | 'last_standing';
  elapsedSeconds?: number;
}


