interface TelegramWebAppUser {
  id?: number;
  first_name?: string;
  last_name?: string;
  username?: string;
}

interface TelegramWebApp {
  ready?: () => void;
  expand?: () => void;
  close?: () => void;
  openTelegramLink?: (url: string) => void;
  initData?: string;
  initDataUnsafe?: {
    user?: TelegramWebAppUser;
    start_param?: string;
  };
}

declare global {
  interface Window {
    Telegram?: {
      WebApp?: TelegramWebApp;
    };
  }
}

export function initTelegramWebApp(): void {
  const tg = window.Telegram?.WebApp;
  if (!tg) return;
  try {
    tg.ready?.();
    tg.expand?.();
  } catch {
    // Ignore outside Telegram
  }
}

/**
 * Matches nawaf-bot-v2 logic:
 * Uses Telegram user full name (first_name + last_name) or username,
 * falling back to "انت" when unavailable.
 */
export function getTelegramDisplayName(): string {
  const tgUser = window.Telegram?.WebApp?.initDataUnsafe?.user;
  if (tgUser) {
    const fullName = [tgUser.first_name, tgUser.last_name]
      .filter(Boolean)
      .join(' ')
      .trim();
    if (fullName) return fullName;
    if (tgUser.username?.trim()) return tgUser.username.trim();
  }

  try {
    const params = new URLSearchParams(window.location.search);
    const paramName = params.get('name')?.trim();
    if (paramName) return paramName;
  } catch {
    // Ignore URL errors
  }

  return 'انت';
}

export function getTelegramUserId(): string | null {
  const id = window.Telegram?.WebApp?.initDataUnsafe?.user?.id;
  return id ? String(id) : null;
}

export function getInitialRoomCodeFromUrl(): string | null {
  try {
    const startParam = window.Telegram?.WebApp?.initDataUnsafe?.start_param || '';
    if (startParam.startsWith('room_')) {
      const code = startParam.slice(5).trim().toUpperCase();
      if (code) return code;
    }
    const params = new URLSearchParams(window.location.search);
    const room = (params.get('room') || params.get('tgWebAppStartParam') || '').trim();
    if (room.startsWith('room_')) return room.slice(5).toUpperCase();
    if (room) return room.toUpperCase();
  } catch {
    // Ignore URL errors
  }
  return null;
}

export function shareInviteOnTelegram(inviteUrl: string, hostName: string): boolean {
  const text = `❄️ ${hostName} يتحداك في لعبة كرة الثلج! اضغط للانضمام للمباراة:`;
  const shareUrl = `https://t.me/share/url?url=${encodeURIComponent(inviteUrl)}&text=${encodeURIComponent(text)}`;
  const tg = window.Telegram?.WebApp;
  if (tg && typeof tg.openTelegramLink === 'function') {
    tg.openTelegramLink(shareUrl);
    return true;
  }
  return false;
}

export function closeTelegramWebApp(): boolean {
  const tg = window.Telegram?.WebApp;
  if (tg && typeof tg.close === 'function') {
    tg.close();
    return true;
  }
  return false;
}
