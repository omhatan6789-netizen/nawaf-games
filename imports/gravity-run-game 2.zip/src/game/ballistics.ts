import type { Difficulty, PlayerSlot } from './types';

export const WORLD_WIDTH = 2800;
export const VIRTUAL_HEIGHT = 800;
export const PIXELS_PER_METER = 24;
export const GRAVITY = 760;
export const MAX_THROW_SPEED = 1320;
export const MIN_THROW_SPEED = 220;

// Taller character geometry & tighter head hitbox so headshots require precision
export const HEAD_OFFSET_Y = -78;
export const HEAD_RADIUS = 14.5;
export const BODY_TOP_OFFSET = -62;
export const BODY_HALF_WIDTH = 21;
export const BODY_OFFSET_Y = -32;
export const SHOULDER_OFFSET_Y = -48;

export const MAX_HP = 100;
export const BODY_DAMAGE = 25;
export const HEADSHOT_DAMAGE = 50;

export interface TerrainPoint {
  x: number;
  y: number;
}

export interface TerrainConfig {
  points: TerrainPoint[];
  leftPlateauY: number;
  rightPlateauY: number;
  valleyY: number;
  leftEdgeX: number;
  rightEdgeX: number;
}

export interface MatchSetup {
  terrain: TerrainConfig;
  p1X: number;
  p2X: number;
}

export function createTerrain(
  leftEdgeXOverride?: number,
  rightEdgeXOverride?: number,
): TerrainConfig {
  const leftPlateauY = 475 + Math.round(Math.random() * 90);
  const rightPlateauY = 465 + Math.round(Math.random() * 100);

  const leftEdgeX = leftEdgeXOverride ?? 780 + Math.round(Math.random() * 240);
  const rightEdgeX =
    rightEdgeXOverride ?? leftEdgeX + 360 + Math.round(Math.random() * 320);
  const canyonWidth = Math.max(240, rightEdgeX - leftEdgeX);

  const maxPlateauY = Math.max(leftPlateauY, rightPlateauY);
  const valleyY = Math.min(720, maxPlateauY + 95 + Math.round(Math.random() * 75));
  const slopeW = Math.min(165, Math.floor(canyonWidth * 0.34));

  const points: TerrainPoint[] = [
    { x: -200, y: leftPlateauY },
    { x: leftEdgeX, y: leftPlateauY },
    { x: leftEdgeX + slopeW, y: valleyY },
    { x: rightEdgeX - slopeW, y: valleyY },
    { x: rightEdgeX, y: rightPlateauY },
    { x: WORLD_WIDTH + 200, y: rightPlateauY },
  ];

  return {
    points,
    leftPlateauY,
    rightPlateauY,
    valleyY,
    leftEdgeX,
    rightEdgeX,
  };
}

export function generateMatchSetup(): MatchSetup {
  // Always spawn between 40m and 80m apart (960px to 1920px)
  const targetMeters = 40 + Math.random() * 40;
  const targetDist = Math.round(targetMeters * PIXELS_PER_METER);

  const centerShift = Math.round((Math.random() - 0.5) * 200);
  const midX = WORLD_WIDTH / 2 + centerShift;

  const p1X = Math.max(280, Math.round(midX - targetDist / 2));
  const p2X = Math.min(WORLD_WIDTH - 280, p1X + targetDist);
  const actualDist = p2X - p1X;

  const canyonWidth = Math.min(
    actualDist - 150,
    340 + Math.round(Math.random() * Math.min(440, Math.max(80, actualDist - 490))),
  );
  const canyonShift = Math.round((Math.random() - 0.5) * Math.max(0, actualDist - canyonWidth - 180) * 0.5);
  const canyonCenter = (p1X + p2X) / 2 + canyonShift;

  const leftEdgeX = Math.max(p1X + 65, Math.round(canyonCenter - canyonWidth / 2));
  const rightEdgeX = Math.min(p2X - 65, Math.round(canyonCenter + canyonWidth / 2));

  const terrain = createTerrain(leftEdgeX, rightEdgeX);

  return { terrain, p1X, p2X };
}

export function getGroundY(terrain: TerrainConfig, x: number): number {
  const pts = terrain.points;
  if (x <= pts[0].x) return pts[0].y;
  for (let i = 0; i < pts.length - 1; i++) {
    const a = pts[i];
    const b = pts[i + 1];
    if (x >= a.x && x <= b.x) {
      const t = (x - a.x) / (b.x - a.x || 1);
      return a.y + (b.y - a.y) * t;
    }
  }
  return pts[pts.length - 1].y;
}

export function clampFighterX(
  terrain: TerrainConfig,
  side: 'left' | 'right',
  x: number,
): number {
  if (side === 'left') {
    return Math.max(150, Math.min(terrain.leftEdgeX - 45, x));
  }
  return Math.max(terrain.rightEdgeX + 45, Math.min(WORLD_WIDTH - 150, x));
}

export interface SolvedShot {
  vx: number;
  vy: number;
  forcePercent: number;
  angleDeg: number;
  intendedOutcome: 'headshot' | 'body' | 'miss';
}

function trajectoryClearsTerrain(
  terrain: TerrainConfig,
  sx: number,
  sy: number,
  vx: number,
  vy: number,
  flightTime: number,
): boolean {
  const steps = 28;
  for (let i = 1; i < steps; i++) {
    const t = (flightTime * i) / steps;
    const px = sx + vx * t;
    const py = sy + vy * t + 0.5 * GRAVITY * t * t;
    const gy = getGroundY(terrain, px);
    if (py + 12 >= gy) {
      return false;
    }
  }
  return true;
}

/**
 * Exact ballistic solver using closed-form Velocity Verlet kinematics:
 *   x(t) = sx + vx * t
 *   y(t) = sy + vy * t + 0.5 * g * t^2
 *
 * - Hard ('صعب'): 100% direct headshot every single turn.
 * - Medium ('متوسط'): ~35% miss, ~45% body hit, ~20% headshot.
 * - Easy ('سهل'): ~55% miss, ~40% body hit, ~5% lucky headshot (0% on turn 1).
 */
export function solveBotShot(
  difficulty: Difficulty,
  turnNumber: number,
  terrain: TerrainConfig,
  botX: number,
  botGroundY: number,
  playerX: number,
  playerGroundY: number,
): SolvedShot {
  const sx = botX - 24;
  const sy = botGroundY + SHOULDER_OFFSET_Y;

  let intendedOutcome: 'headshot' | 'body' | 'miss' = 'body';
  const roll = Math.random();

  if (difficulty === 'hard') {
    intendedOutcome = 'headshot';
  } else if (difficulty === 'medium') {
    if (roll < 0.35) intendedOutcome = 'miss';
    else if (roll < 0.8) intendedOutcome = 'body';
    else intendedOutcome = 'headshot';
  } else {
    if (roll < 0.55) intendedOutcome = 'miss';
    else if (roll < 0.95 || turnNumber <= 1) intendedOutcome = 'body';
    else intendedOutcome = 'headshot';
  }

  let tx = playerX;
  let ty = playerGroundY + BODY_OFFSET_Y;

  if (intendedOutcome === 'headshot') {
    tx = playerX;
    ty = playerGroundY + HEAD_OFFSET_Y;
  } else if (intendedOutcome === 'body') {
    tx = playerX + 8;
    ty = playerGroundY - 26;
  } else {
    const missShort = Math.random() < 0.55;
    if (difficulty === 'easy') {
      const offset = missShort
        ? 110 + Math.random() * 140
        : -(100 + Math.random() * 130);
      tx = Math.max(140, playerX + offset);
      ty = getGroundY(terrain, tx) - 4;
    } else {
      const offset = missShort
        ? 68 + Math.random() * 65
        : -(65 + Math.random() * 65);
      tx = Math.max(140, playerX + offset);
      ty = getGroundY(terrain, tx) - 4;
    }
  }

  const dist = Math.abs(tx - sx);
  const chosenT =
    intendedOutcome === 'body'
      ? Math.max(0.85, Math.min(2.15, dist / 900))
      : Math.max(0.95, Math.min(2.35, dist / 800));

  let vx = (tx - sx) / chosenT;
  let vy = (ty - sy - 0.5 * GRAVITY * chosenT * chosenT) / chosenT;

  const hitsHeadAlongWay = (candVx: number, candVy: number, flightTime: number) => {
    const headX = playerX;
    const headY = playerGroundY + HEAD_OFFSET_Y;
    for (let i = 1; i <= 40; i++) {
      const t = (flightTime * i) / 40;
      const px = sx + candVx * t;
      const py = sy + candVy * t + 0.5 * GRAVITY * t * t;
      if (Math.hypot(px - headX, py - headY) <= HEAD_RADIUS + 8) {
        return true;
      }
    }
    return false;
  };

  for (let attempt = 0; attempt < 22; attempt++) {
    const t = chosenT + attempt * 0.07;
    const candVx = (tx - sx) / t;
    const candVy = (ty - sy - 0.5 * GRAVITY * t * t) / t;
    const speed = Math.hypot(candVx, candVy);
    const clears = trajectoryClearsTerrain(terrain, sx, sy, candVx, candVy, t);
    const avoidsHeadIfBody =
      intendedOutcome !== 'body' || !hitsHeadAlongWay(candVx, candVy, t);

    if (speed <= MAX_THROW_SPEED * 1.1 && clears && avoidsHeadIfBody) {
      vx = candVx;
      vy = candVy;
      break;
    }
  }

  const speed = Math.hypot(vx, vy);
  const forcePercent = Math.max(
    15,
    Math.min(
      100,
      Math.round(((speed - MIN_THROW_SPEED) / (MAX_THROW_SPEED - MIN_THROW_SPEED)) * 100),
    ),
  );
  const angleDeg = Math.round((Math.atan2(-vy, -vx) * 180) / Math.PI);

  return {
    vx,
    vy,
    forcePercent,
    angleDeg,
    intendedOutcome,
  };
}

export interface AuthoritativeShotResolution {
  hitTarget: PlayerSlot | null;
  hitType: 'headshot' | 'body' | 'ground';
  impactX: number;
  impactY: number;
  newP1X: number;
  newP2X: number;
  newP1Hp: number;
  newP2Hp: number;
  winner: PlayerSlot | null;
}

/**
 * Deterministic server-side shot simulation for online multiplayer.
 */
export function resolveOnlineShotOnServer(
  terrain: TerrainConfig,
  shooterSlot: PlayerSlot,
  vx: number,
  vy: number,
  p1X: number,
  p2X: number,
  p1Hp: number,
  p2Hp: number,
): AuthoritativeShotResolution {
  const shooterX = shooterSlot === 'p1' ? p1X : p2X;
  const facing = shooterSlot === 'p1' ? 1 : -1;
  const shooterGy = getGroundY(terrain, shooterX);

  let px = shooterX + facing * 24;
  let py = shooterGy + SHOULDER_OFFSET_Y;
  let cvx = vx;
  let cvy = vy;

  const targetSlot: PlayerSlot = shooterSlot === 'p1' ? 'p2' : 'p1';
  const targetX = targetSlot === 'p1' ? p1X : p2X;
  const targetGy = getGroundY(terrain, targetX);
  const headX = targetX;
  const headY = targetGy + HEAD_OFFSET_Y;
  const bodyTop = targetGy + BODY_TOP_OFFSET;
  const bodyBottom = targetGy + 2;

  const subDt = 1 / 240; // Ultra-fine server integration for deterministic collision
  const maxSteps = 240 * 5; // Up to 5 seconds flight

  let hitType: 'headshot' | 'body' | 'ground' = 'ground';
  let hitTarget: PlayerSlot | null = null;
  let impactX = px;
  let impactY = py;

  for (let i = 0; i < maxSteps; i++) {
    px += cvx * subDt;
    py += cvy * subDt + 0.5 * GRAVITY * subDt * subDt;
    cvy += GRAVITY * subDt;

    if (Math.hypot(px - headX, py - headY) <= HEAD_RADIUS + 4) {
      hitTarget = targetSlot;
      hitType = 'headshot';
      impactX = headX;
      impactY = headY;
      break;
    }

    if (
      Math.abs(px - targetX) <= BODY_HALF_WIDTH &&
      py >= bodyTop &&
      py <= bodyBottom
    ) {
      hitTarget = targetSlot;
      hitType = 'body';
      impactX = px;
      impactY = targetGy + BODY_OFFSET_Y;
      break;
    }

    const gy = getGroundY(terrain, px);
    if (py + 7 >= gy) {
      hitTarget = null;
      hitType = 'ground';
      impactX = px;
      impactY = gy;
      break;
    }

    if (px < -150 || px > WORLD_WIDTH + 150 || py > VIRTUAL_HEIGHT + 150) {
      hitTarget = null;
      hitType = 'ground';
      impactX = px;
      impactY = gy;
      break;
    }
  }

  let newP1X = p1X;
  let newP2X = p2X;
  let newP1Hp = p1Hp;
  let newP2Hp = p2Hp;
  let winner: PlayerSlot | null = null;

  if (hitTarget) {
    const dmg = hitType === 'headshot' ? HEADSHOT_DAMAGE : BODY_DAMAGE;
    const knockbackDist = 92;
    if (hitTarget === 'p1') {
      newP1Hp = Math.max(0, p1Hp - dmg);
      newP1X = clampFighterX(terrain, 'left', p1X - knockbackDist);
      if (newP1Hp <= 0) winner = 'p2';
    } else {
      newP2Hp = Math.max(0, p2Hp - dmg);
      newP2X = clampFighterX(terrain, 'right', p2X + knockbackDist);
      if (newP2Hp <= 0) winner = 'p1';
    }
  }

  return {
    hitTarget,
    hitType,
    impactX,
    impactY,
    newP1X,
    newP2X,
    newP1Hp,
    newP2Hp,
    winner,
  };
}
