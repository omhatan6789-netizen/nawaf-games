import React, { useEffect, useRef, useState } from 'react';
import { Volume2, VolumeX } from 'lucide-react';
import {
  BODY_DAMAGE,
  BODY_HALF_WIDTH,
  BODY_OFFSET_Y,
  BODY_TOP_OFFSET,
  clampFighterX,
  generateMatchSetup,
  getGroundY,
  GRAVITY,
  HEAD_OFFSET_Y,
  HEAD_RADIUS,
  HEADSHOT_DAMAGE,
  MAX_HP,
  MAX_THROW_SPEED,
  MIN_THROW_SPEED,
  PIXELS_PER_METER,
  SHOULDER_OFFSET_Y,
  solveBotShot,
  type TerrainConfig,
  VIRTUAL_HEIGHT,
  WORLD_WIDTH,
} from '../game/ballistics';
import type { AimSyncPayload, OnlineGameClient } from '../game/onlineClient';
import { soundManager } from '../game/sound';
import type {
  Difficulty,
  GameResult,
  OnlineRoomSnapshot,
  OnlineShotOutcome,
  PlayerSlot,
} from '../game/types';

interface SnowballArenaProps {
  mode: 'bot' | 'online';
  difficulty?: Difficulty;
  playerName: string;
  onlineSnapshot?: OnlineRoomSnapshot;
  onlineClient?: OnlineGameClient;
  latestOnlineShot?: { seq: number; outcome: OnlineShotOutcome } | null;
  remoteAimSync?: AimSyncPayload | null;
  onExit: () => void;
  onGameOver: (result: GameResult) => void;
}

type ArenaPhase =
  | 'INTRO'
  | 'AIM'
  | 'AWAITING_SERVER'
  | 'FLIGHT'
  | 'IMPACT_PAUSE'
  | 'BOT_THINK'
  | 'VICTORY_POSE';

interface FighterState {
  x: number;
  hp: number;
  maxHp: number;
  facing: 1 | -1;
  knockbackVelX: number;
  fallTimer: number;
  throwAnimTimer: number;
  waveTimer: number;
  dazed: boolean;
  dead: boolean;
}

interface ProjectileState {
  x: number;
  y: number;
  vx: number;
  vy: number;
  shooterSlot: PlayerSlot;
  trail: Array<{ x: number; y: number }>;
  authoritativeOutcome?: OnlineShotOutcome;
  flightElapsed: number;
}

interface SnowParticle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  life: number;
  maxLife: number;
  color: string;
}

interface FloatingBanner {
  x: number;
  y: number;
  text: string;
  life: number;
  maxLife: number;
}

interface HeadshotBurst {
  x: number;
  y: number;
  life: number;
  maxLife: number;
}

interface AimState {
  active: boolean;
  startX: number;
  startY: number;
  currX: number;
  currY: number;
  forcePercent: number;
  angleDeg: number;
  vx: number;
  vy: number;
}

function MiniAvatarIcon({ color }: { color: string }) {
  return (
    <svg viewBox="0 0 40 40" className="w-7 h-7 block" aria-hidden="true">
      <rect x="6" y="7" width="28" height="27" rx="9" fill="#ffffff" stroke="#0b0e14" strokeWidth="3" />
      <rect x="11" y="12" width="18" height="17" rx="5" fill="#ffe0c2" stroke="#0b0e14" strokeWidth="2.4" />
      <rect x="11" y="11" width="18" height="6" rx="2" fill="#14171f" />
      <rect x="15" y="19" width="2.8" height="5" rx="1.4" fill="#14171f" />
      <rect x="22" y="19" width="2.8" height="5" rx="1.4" fill="#14171f" />
      <path d="M8 31 Q20 36 32 31 L34 39 L6 39 Z" fill={color} stroke="#0b0e14" strokeWidth="2.5" />
    </svg>
  );
}

export const SnowballArena: React.FC<SnowballArenaProps> = ({
  mode,
  difficulty = 'medium',
  playerName,
  onlineSnapshot,
  onlineClient,
  latestOnlineShot,
  remoteAimSync,
  onExit,
  onGameOver,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  const localSlot: PlayerSlot = mode === 'online' ? onlineSnapshot?.yourSlot || 'p1' : 'p1';
  const p1Label =
    mode === 'online' ? onlineSnapshot?.players.p1?.name || 'اللاعب 1' : playerName;
  const p2Label =
    mode === 'online' ? onlineSnapshot?.players.p2?.name || 'اللاعب 2' : 'البوت';

  const [p1HpUi, setP1HpUi] = useState(onlineSnapshot?.p1Hp ?? MAX_HP);
  const [p2HpUi, setP2HpUi] = useState(onlineSnapshot?.p2Hp ?? MAX_HP);
  const [turnUi, setTurnUi] = useState<PlayerSlot>(onlineSnapshot?.turn ?? 'p1');
  const [phaseUi, setPhaseUi] = useState<ArenaPhase>('INTRO');
  const [isAimingUi, setIsAimingUi] = useState(false);
  const [tapHintVisible, setTapHintVisible] = useState(false);
  const [muted, setMuted] = useState(soundManager.muted);

  const remoteAimRef = useRef<AimSyncPayload | null>(null);
  remoteAimRef.current = remoteAimSync || null;

  const lastShotSeqRef = useRef<number>(0);

  const engineRef = useRef<{
    terrain: TerrainConfig;
    phase: ArenaPhase;
    turn: PlayerSlot;
    turnCount: number;
    p1: FighterState;
    p2: FighterState;
    projectile: ProjectileState | null;
    particles: SnowParticle[];
    banners: FloatingBanner[];
    headshotBursts: HeadshotBurst[];
    aim: AimState;
    cameraX: number;
    targetCameraX: number;
    shakeTime: number;
    shakeStrength: number;
    phaseTimer: number;
    botThinkDuration: number;
    botAimProgress: number;
    botSolvedShot: ReturnType<typeof solveBotShot> | null;
    winner: PlayerSlot | null;
    winReason?: 'ko' | 'forfeit';
    reportedGameOver: boolean;
    viewWidth: number;
    tapHintTimer: number;
  } | null>(null);

  if (!engineRef.current) {
    const fallbackSetup = generateMatchSetup();
    const terrain =
      mode === 'online' && onlineSnapshot?.terrain ? onlineSnapshot.terrain : fallbackSetup.terrain;
    const initialP1X =
      mode === 'online' && onlineSnapshot?.p1X !== undefined ? onlineSnapshot.p1X : fallbackSetup.p1X;
    const initialP2X =
      mode === 'online' && onlineSnapshot?.p2X !== undefined ? onlineSnapshot.p2X : fallbackSetup.p2X;
    const focusFighterX = localSlot === 'p1' ? initialP1X : initialP2X;

    engineRef.current = {
      terrain,
      phase: 'INTRO',
      turn: onlineSnapshot?.turn ?? 'p1',
      turnCount: onlineSnapshot?.turnCount ?? 1,
      p1: {
        x: initialP1X,
        hp: onlineSnapshot?.p1Hp ?? MAX_HP,
        maxHp: MAX_HP,
        facing: 1,
        knockbackVelX: 0,
        fallTimer: 0,
        throwAnimTimer: 0,
        waveTimer: 1.0,
        dazed: false,
        dead: false,
      },
      p2: {
        x: initialP2X,
        hp: onlineSnapshot?.p2Hp ?? MAX_HP,
        maxHp: MAX_HP,
        facing: -1,
        knockbackVelX: 0,
        fallTimer: 0,
        throwAnimTimer: 0,
        waveTimer: mode === 'online' ? 1.0 : 0,
        dazed: false,
        dead: false,
      },
      projectile: null,
      particles: [],
      banners: [],
      headshotBursts: [],
      aim: {
        active: false,
        startX: 0,
        startY: 0,
        currX: 0,
        currY: 0,
        forcePercent: 0,
        angleDeg: 15,
        vx: 0,
        vy: 0,
      },
      cameraX: 760,
      targetCameraX: focusFighterX - 180,
      shakeTime: 0,
      shakeStrength: 0,
      phaseTimer: 0.95,
      botThinkDuration: 1.05,
      botAimProgress: 0,
      botSolvedShot: null,
      winner: null,
      reportedGameOver: false,
      viewWidth: 450,
      tapHintTimer: 0,
    };
  }

  // Handle forfeit / room finish from server in online mode
  useEffect(() => {
    if (mode !== 'online' || !onlineSnapshot || !engineRef.current) return;
    const state = engineRef.current;
    if (
      onlineSnapshot.status === 'finished' &&
      onlineSnapshot.winReason === 'forfeit' &&
      onlineSnapshot.winner &&
      !state.reportedGameOver
    ) {
      state.winner = onlineSnapshot.winner;
      state.winReason = 'forfeit';
      state.phase = 'VICTORY_POSE';
      state.phaseTimer = 0.8;
      setPhaseUi('VICTORY_POSE');
      if (onlineSnapshot.winner === localSlot) soundManager.playVictory();
      else soundManager.playDefeat();
    }
  }, [localSlot, mode, onlineSnapshot]);

  // Handle authoritative shot broadcast from server in online mode
  useEffect(() => {
    if (mode !== 'online' || !latestOnlineShot || !engineRef.current) return;
    if (latestOnlineShot.seq === lastShotSeqRef.current) return;
    lastShotSeqRef.current = latestOnlineShot.seq;

    const state = engineRef.current;
    const { outcome } = latestOnlineShot;
    const shooter = outcome.shooterSlot === 'p1' ? state.p1 : state.p2;
    const gy = getGroundY(state.terrain, shooter.x);
    const sx = shooter.x + shooter.facing * 24;
    const sy = gy + SHOULDER_OFFSET_Y;

    shooter.throwAnimTimer = 0.28;
    state.aim.active = false;
    setIsAimingUi(false);
    state.projectile = {
      x: sx,
      y: sy,
      vx: outcome.vx,
      vy: outcome.vy,
      shooterSlot: outcome.shooterSlot,
      trail: [{ x: sx, y: sy }],
      authoritativeOutcome: outcome,
      flightElapsed: 0,
    };
    state.phase = 'FLIGHT';
    setPhaseUi('FLIGHT');
    soundManager.playThrow();
  }, [latestOnlineShot, mode]);

  const toggleMute = () => {
    soundManager.muted = !soundManager.muted;
    setMuted(soundManager.muted);
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    const state = engineRef.current;
    if (!canvas || !container || !state) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let rafId = 0;
    let lastTime = performance.now();

    const resize = () => {
      const rect = container.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.max(1, Math.floor(rect.width * dpr));
      canvas.height = Math.max(1, Math.floor(rect.height * dpr));
      const aspect = rect.width / Math.max(1, rect.height);
      state.viewWidth = VIRTUAL_HEIGHT * aspect;
    };

    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(container);

    const spawnSnowSplash = (x: number, y: number, count: number, intense = false) => {
      for (let i = 0; i < count; i++) {
        const angle = -Math.PI + Math.random() * Math.PI * 2;
        const speed = (intense ? 150 : 90) + Math.random() * (intense ? 260 : 180);
        state.particles.push({
          x,
          y,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed - (intense ? 140 : 80),
          r: (intense ? 5.5 : 4) + Math.random() * 5,
          life: 0.55 + Math.random() * 0.35,
          maxLife: 0.9,
          color: '#ffffff',
        });
      }
    };

    const launchBotProjectile = (vx: number, vy: number) => {
      const shooter = state.p2;
      const gy = getGroundY(state.terrain, shooter.x);
      const sx = shooter.x - 24;
      const sy = gy + SHOULDER_OFFSET_Y;

      shooter.throwAnimTimer = 0.28;
      state.projectile = {
        x: sx,
        y: sy,
        vx,
        vy,
        shooterSlot: 'p2',
        trail: [{ x: sx, y: sy }],
        flightElapsed: 0,
      };
      state.phase = 'FLIGHT';
      setPhaseUi('FLIGHT');
      soundManager.playThrow();
    };

    const startBotTurn = () => {
      state.turn = 'p2';
      state.phase = 'BOT_THINK';
      state.phaseTimer = 0;
      state.botThinkDuration = 1.05;
      state.botAimProgress = 0;

      const botGy = getGroundY(state.terrain, state.p2.x);
      const playerGy = getGroundY(state.terrain, state.p1.x);
      state.botSolvedShot = solveBotShot(
        difficulty,
        state.turnCount,
        state.terrain,
        state.p2.x,
        botGy,
        state.p1.x,
        playerGy,
      );

      setTurnUi('p2');
      setPhaseUi('BOT_THINK');
    };

    const startNextAimTurn = (nextSlot: PlayerSlot, nextTurnCount?: number) => {
      state.turn = nextSlot;
      state.turnCount = nextTurnCount ?? state.turnCount + (nextSlot === 'p1' ? 1 : 0);
      state.phase = 'AIM';
      state.aim.active = false;
      setTurnUi(nextSlot);
      setPhaseUi('AIM');
      setIsAimingUi(false);
    };

    const applyImpactEffects = (
      targetSlot: PlayerSlot | null,
      hitType: 'headshot' | 'body' | 'ground',
      impactX: number,
      impactY: number,
      authoritative?: OnlineShotOutcome,
    ) => {
      state.projectile = null;

      if (targetSlot && (hitType === 'headshot' || hitType === 'body')) {
        const victim = targetSlot === 'p1' ? state.p1 : state.p2;
        const damage = hitType === 'headshot' ? HEADSHOT_DAMAGE : BODY_DAMAGE;

        if (authoritative) {
          state.p1.hp = authoritative.p1Hp;
          state.p2.hp = authoritative.p2Hp;
        } else {
          victim.hp = Math.max(0, victim.hp - damage);
        }

        victim.dazed = true;
        victim.fallTimer = victim.hp <= 0 ? 999 : 0.95;
        victim.knockbackVelX = targetSlot === 'p1' ? -240 : 240;

        setP1HpUi(state.p1.hp);
        setP2HpUi(state.p2.hp);

        if (hitType === 'headshot') {
          soundManager.playHeadshot();
          spawnSnowSplash(impactX, impactY, 12, true);
          state.shakeTime = 0.28;
          state.shakeStrength = 13;
          state.headshotBursts.push({
            x: impactX,
            y: impactY,
            life: 0.95,
            maxLife: 0.95,
          });
          state.banners.push({
            x: victim.x,
            y: getGroundY(state.terrain, victim.x) - 116,
            text: 'Headshot!',
            life: 1.15,
            maxLife: 1.15,
          });
        } else {
          soundManager.playBodyHit();
          spawnSnowSplash(impactX, impactY, 8, false);
          state.shakeTime = 0.16;
          state.shakeStrength = 6;
        }

        if (victim.hp <= 0) {
          victim.dead = true;
          state.winner = authoritative?.winner ?? (targetSlot === 'p1' ? 'p2' : 'p1');
          state.winReason = 'ko';
        }
      } else {
        soundManager.playSnowMiss();
        spawnSnowSplash(impactX, impactY, 7, false);
      }

      // Snap exact authoritative positions if online after knockback settles
      if (authoritative) {
        state.turn = authoritative.nextTurn;
        state.turnCount = authoritative.turnCount;
      }

      state.phase = 'IMPACT_PAUSE';
      state.phaseTimer = 0.92;
      setPhaseUi('IMPACT_PAUSE');
    };

    const update = (dt: number) => {
      [state.p1, state.p2].forEach((f, idx) => {
        if (f.waveTimer > 0) f.waveTimer = Math.max(0, f.waveTimer - dt);
        if (f.throwAnimTimer > 0) f.throwAnimTimer = Math.max(0, f.throwAnimTimer - dt);

        if (Math.abs(f.knockbackVelX) > 2) {
          f.x = clampFighterX(
            state.terrain,
            idx === 0 ? 'left' : 'right',
            f.x + f.knockbackVelX * dt,
          );
          f.knockbackVelX *= Math.pow(0.03, dt);
        } else {
          f.knockbackVelX = 0;
        }

        if (f.fallTimer > 0 && !f.dead) {
          f.fallTimer = Math.max(0, f.fallTimer - dt);
          if (f.fallTimer === 0) f.dazed = false;
        }
      });

      if (state.tapHintTimer > 0) {
        state.tapHintTimer = Math.max(0, state.tapHintTimer - dt);
        if (state.tapHintTimer === 0) setTapHintVisible(false);
      }

      for (let i = state.particles.length - 1; i >= 0; i--) {
        const p = state.particles[i];
        p.life -= dt;
        if (p.life <= 0) {
          state.particles.splice(i, 1);
          continue;
        }
        p.vy += GRAVITY * 0.65 * dt;
        p.x += p.vx * dt;
        p.y += p.vy * dt;
      }

      for (let i = state.banners.length - 1; i >= 0; i--) {
        const b = state.banners[i];
        b.life -= dt;
        b.y -= 26 * dt;
        if (b.life <= 0) state.banners.splice(i, 1);
      }

      for (let i = state.headshotBursts.length - 1; i >= 0; i--) {
        const h = state.headshotBursts[i];
        h.life -= dt;
        if (h.life <= 0) state.headshotBursts.splice(i, 1);
      }

      if (state.shakeTime > 0) {
        state.shakeTime = Math.max(0, state.shakeTime - dt);
      }

      const activeFighter = state.turn === 'p1' ? state.p1 : state.p2;

      if (state.phase === 'INTRO') {
        state.phaseTimer -= dt;
        state.targetCameraX =
          state.p1.x - state.viewWidth * 0.34;
        if (state.phaseTimer <= 0) {
          state.phase = 'AIM';
          setPhaseUi('AIM');
        }
      } else if (state.phase === 'AIM') {
        if (state.turn === 'p1') {
          state.targetCameraX = state.p1.x - state.viewWidth * 0.34;
        } else {
          state.targetCameraX = state.p2.x - state.viewWidth * 0.66;
        }
      } else if (state.phase === 'AWAITING_SERVER') {
        state.targetCameraX =
          activeFighter.x - state.viewWidth * (state.turn === 'p1' ? 0.34 : 0.66);
      } else if (state.phase === 'BOT_THINK') {
        state.targetCameraX = state.p2.x - state.viewWidth * 0.66;
        state.phaseTimer += dt;
        state.botAimProgress = Math.min(1, state.phaseTimer / state.botThinkDuration);
        if (state.phaseTimer >= state.botThinkDuration && state.botSolvedShot) {
          launchBotProjectile(state.botSolvedShot.vx, state.botSolvedShot.vy);
        }
      } else if (state.phase === 'FLIGHT' && state.projectile) {
        const proj = state.projectile;
        proj.flightElapsed += dt;
        const subSteps = 4;
        const subDt = dt / subSteps;
        let collided = false;

        for (let s = 0; s < subSteps; s++) {
          proj.x += proj.vx * subDt;
          proj.y += proj.vy * subDt + 0.5 * GRAVITY * subDt * subDt;
          proj.vy += GRAVITY * subDt;

          const targetSlot: PlayerSlot = proj.shooterSlot === 'p1' ? 'p2' : 'p1';
          const target = targetSlot === 'p1' ? state.p1 : state.p2;
          const targetGy = getGroundY(state.terrain, target.x);

          // Taller character head hitbox check
          const headX = target.x;
          const headY = targetGy + HEAD_OFFSET_Y;
          if (Math.hypot(proj.x - headX, proj.y - headY) <= HEAD_RADIUS + 4) {
            const auth = proj.authoritativeOutcome;
            applyImpactEffects(
              auth ? auth.hitTarget : targetSlot,
              auth ? auth.hitType : 'headshot',
              auth ? auth.impactX : headX,
              auth ? auth.impactY : headY,
              auth,
            );
            collided = true;
            break;
          }

          // Taller character body hitbox check
          const bodyTop = targetGy + BODY_TOP_OFFSET;
          const bodyBottom = targetGy + 2;
          if (
            Math.abs(proj.x - target.x) <= BODY_HALF_WIDTH &&
            proj.y >= bodyTop &&
            proj.y <= bodyBottom
          ) {
            const auth = proj.authoritativeOutcome;
            applyImpactEffects(
              auth ? auth.hitTarget : targetSlot,
              auth ? auth.hitType : 'body',
              auth ? auth.impactX : proj.x,
              auth ? auth.impactY : targetGy + BODY_OFFSET_Y,
              auth,
            );
            collided = true;
            break;
          }

          const gy = getGroundY(state.terrain, proj.x);
          if (proj.y + 7 >= gy) {
            const auth = proj.authoritativeOutcome;
            applyImpactEffects(
              auth ? auth.hitTarget : null,
              auth ? auth.hitType : 'ground',
              auth ? auth.impactX : proj.x,
              auth ? auth.impactY : gy,
              auth,
            );
            collided = true;
            break;
          }

          if (
            proj.x < -150 ||
            proj.x > WORLD_WIDTH + 150 ||
            proj.y > VIRTUAL_HEIGHT + 150 ||
            proj.flightElapsed > 5.2
          ) {
            const auth = proj.authoritativeOutcome;
            applyImpactEffects(
              auth ? auth.hitTarget : null,
              auth ? auth.hitType : 'ground',
              auth ? auth.impactX : proj.x,
              auth ? auth.impactY : gy,
              auth,
            );
            collided = true;
            break;
          }
        }

        if (!collided && state.projectile) {
          state.projectile.trail.push({ x: proj.x, y: proj.y });
          if (state.projectile.trail.length > 14) {
            state.projectile.trail.shift();
          }
          state.targetCameraX = proj.x - state.viewWidth * 0.5;
        }
      } else if (state.phase === 'IMPACT_PAUSE') {
        state.phaseTimer -= dt;
        if (state.phaseTimer <= 0) {
          if (state.winner) {
            state.phase = 'VICTORY_POSE';
            state.phaseTimer = 1.45;
            setPhaseUi('VICTORY_POSE');
            if (state.winner === localSlot) {
              soundManager.playVictory();
            } else {
              soundManager.playDefeat();
            }
          } else if (mode === 'bot') {
            if (state.turn === 'p1') {
              startBotTurn();
            } else {
              startNextAimTurn('p1', state.turnCount + 1);
            }
          } else {
            // Online mode: state.turn was already updated to nextTurn from authoritative outcome
            startNextAimTurn(state.turn, state.turnCount);
          }
        }
      } else if (state.phase === 'VICTORY_POSE') {
        const winnerFighter = state.winner === 'p1' ? state.p1 : state.p2;
        state.targetCameraX = winnerFighter.x - state.viewWidth * 0.5;
        state.phaseTimer -= dt;
        if (state.phaseTimer <= 0 && !state.reportedGameOver && state.winner) {
          state.reportedGameOver = true;
          const winnerName = state.winner === 'p1' ? p1Label : p2Label;
          onGameOver({
            mode,
            winnerSlot: mode === 'bot' ? (state.winner === 'p1' ? 'player' : 'bot') : state.winner,
            winnerName,
            didLocalWin: state.winner === localSlot,
            difficulty: mode === 'bot' ? difficulty : undefined,
            winReason: state.winReason,
          });
        }
      }

      const maxCam = Math.max(0, WORLD_WIDTH - state.viewWidth);
      const clampedTarget = Math.max(0, Math.min(maxCam, state.targetCameraX));
      const lerpSpeed = state.phase === 'FLIGHT' ? 10 : 5.2;
      state.cameraX += (clampedTarget - state.cameraX) * Math.min(1, lerpSpeed * dt);
    };

    const drawFighter = (
      fighter: FighterState,
      slot: PlayerSlot,
      color: string,
      darkColor: string,
      nowSec: number,
    ) => {
      const gy = getGroundY(state.terrain, fighter.x);
      ctx.save();

      let jumpOffset = 0;
      const isWinner = state.phase === 'VICTORY_POSE' && state.winner === slot;
      if (isWinner) {
        jumpOffset = -Math.abs(Math.sin(nowSec * 9)) * 18;
      }

      ctx.translate(fighter.x, gy + jumpOffset);

      if (fighter.fallTimer > 0 || fighter.dead) {
        const rot = slot === 'p1' ? -Math.PI / 2 : Math.PI / 2;
        ctx.translate(0, -18);
        ctx.rotate(rot);
        ctx.translate(0, 18);
      }

      // Aiming lean-back tilt (local player, bot, or remote online player)
      let aimPull = 0;
      let aimAngleRad = 0.25;
      const isLocalTurnAim =
        state.phase === 'AIM' && state.turn === slot && slot === localSlot && state.aim.active;
      const isRemoteOnlineAim =
        mode === 'online' &&
        state.phase === 'AIM' &&
        state.turn === slot &&
        slot !== localSlot &&
        remoteAimRef.current?.slot === slot &&
        remoteAimRef.current.active;
      const isBotThink = mode === 'bot' && slot === 'p2' && state.phase === 'BOT_THINK';

      if (isLocalTurnAim) {
        aimPull = state.aim.forcePercent / 100;
        aimAngleRad = (state.aim.angleDeg * Math.PI) / 180;
        ctx.rotate(-fighter.facing * 0.16 * aimPull);
      } else if (isRemoteOnlineAim && remoteAimRef.current) {
        aimPull = remoteAimRef.current.forcePercent / 100;
        aimAngleRad = (remoteAimRef.current.angleDeg * Math.PI) / 180;
        ctx.rotate(-fighter.facing * 0.16 * aimPull);
      } else if (isBotThink && state.botSolvedShot) {
        aimPull = state.botAimProgress * (state.botSolvedShot.forcePercent / 100);
        aimAngleRad = (state.botSolvedShot.angleDeg * Math.PI) / 180;
        ctx.rotate(0.16 * aimPull);
      }

      const outline = '#0b0e14';
      ctx.lineWidth = 3.5;
      ctx.strokeStyle = outline;
      ctx.lineJoin = 'round';
      ctx.lineCap = 'round';

      // Taller Legs & Boots (-24 to 0)
      const spread = aimPull > 0.05 ? 5 * aimPull : 0;
      ctx.fillStyle = '#161922';
      ctx.beginPath();
      ctx.roundRect(-11 - spread, -24, 6.5, 21, 3);
      ctx.fill();
      ctx.stroke();
      ctx.beginPath();
      ctx.roundRect(-15 - spread, -8, 13, 9, 4);
      ctx.fill();
      ctx.stroke();

      ctx.beginPath();
      ctx.roundRect(4.5 + spread, -24, 6.5, 21, 3);
      ctx.fill();
      ctx.stroke();
      ctx.beginPath();
      ctx.roundRect(2 + spread, -8, 13, 9, 4);
      ctx.fill();
      ctx.stroke();

      // Back arm (attached at higher shoulder y = -50)
      ctx.save();
      ctx.translate(-fighter.facing * 17, -50);
      if (isWinner) {
        ctx.rotate(fighter.facing * 2.4);
      } else if (aimPull > 0.05) {
        ctx.rotate(-fighter.facing * 0.55 * aimPull);
      } else {
        ctx.rotate(fighter.facing * 0.18);
      }
      ctx.fillStyle = color;
      ctx.beginPath();
      ctx.roundRect(-5.5, -2, 11, 24, 5.5);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(0, 21, 5.2, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.restore();

      // Taller Torso (parka jacket from -62 to -18)
      ctx.fillStyle = color;
      ctx.beginPath();
      ctx.roundRect(-19.5, -62, 39, 44, 12);
      ctx.fill();
      // Lower shading band
      ctx.fillStyle = darkColor;
      ctx.beginPath();
      ctx.roundRect(-17.5, -29, 35, 9, 5);
      ctx.fill();
      ctx.beginPath();
      ctx.roundRect(-19.5, -62, 39, 44, 12);
      ctx.stroke();

      // White fur hood + Head positioned higher (-94 to -60, tighter head silhouette)
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.roundRect(-15.5, -94, 31, 34, 11);
      ctx.fill();
      ctx.stroke();

      // Face inside hood
      ctx.fillStyle = '#ffe0c2';
      ctx.beginPath();
      ctx.roundRect(-10, -88, 20, 22, 5.5);
      ctx.fill();
      ctx.stroke();

      // Hair cap
      ctx.fillStyle = '#14171f';
      ctx.beginPath();
      ctx.roundRect(-10, -89, 20, 6.5, [4.5, 4.5, 1, 1]);
      ctx.fill();

      // Eyes
      const eyeOffset = fighter.facing * 1.8;
      if (fighter.dazed || fighter.dead) {
        ctx.strokeStyle = '#14171f';
        ctx.lineWidth = 2.3;
        ctx.beginPath();
        ctx.moveTo(-5.5 + eyeOffset, -78);
        ctx.lineTo(-1.5 + eyeOffset, -75);
        ctx.lineTo(-5.5 + eyeOffset, -72);
        ctx.moveTo(5.5 + eyeOffset, -78);
        ctx.lineTo(1.5 + eyeOffset, -75);
        ctx.lineTo(5.5 + eyeOffset, -72);
        ctx.stroke();
      } else {
        ctx.fillStyle = '#14171f';
        ctx.beginPath();
        ctx.roundRect(-5 + eyeOffset, -79, 2.8, 6.2, 1.4);
        ctx.roundRect(2.2 + eyeOffset, -79, 2.8, 6.2, 1.4);
        ctx.fill();
      }

      // Throwing / Front Arm with Snowball (at shoulder y = -50)
      ctx.save();
      ctx.translate(fighter.facing * 15, -50);
      let armRot = 0;
      let showSnowballInHand = false;

      if (isWinner) {
        armRot = -fighter.facing * 2.4;
      } else if (fighter.waveTimer > 0) {
        armRot = -fighter.facing * (1.8 + Math.sin(nowSec * 14) * 0.45);
      } else if (fighter.throwAnimTimer > 0) {
        armRot = fighter.facing * 1.1;
      } else if (aimPull > 0.05) {
        armRot = -fighter.facing * (1.1 + aimPull * 1.05 + aimAngleRad * 0.25);
        showSnowballInHand = true;
      } else if (state.turn === slot && (state.phase === 'AIM' || state.phase === 'BOT_THINK')) {
        armRot = -fighter.facing * 0.35;
        showSnowballInHand = true;
      }

      ctx.rotate(armRot);
      ctx.lineWidth = 3.5;
      ctx.strokeStyle = outline;
      ctx.fillStyle = color;
      ctx.beginPath();
      ctx.roundRect(-5.5, -2, 11, 24, 5.5);
      ctx.fill();
      ctx.stroke();

      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(0, 21, 5.2, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      if (showSnowballInHand && !fighter.dazed && !fighter.dead) {
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(fighter.facing * 4, 25, 7.2, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
      }
      ctx.restore();

      // Victory cheering stars above taller head
      if (isWinner) {
        const starColors =
          slot === 'p1'
            ? ['#ef3b3b', '#ff8c42', '#ffd166']
            : ['#2eb6ff', '#44d8ff', '#ffffff'];
        for (let i = 0; i < 3; i++) {
          const sx = (i - 1) * 24 + Math.sin(nowSec * 4 + i) * 4;
          const sy = -114 - Math.abs(Math.cos(nowSec * 5 + i * 1.2)) * 10;
          ctx.fillStyle = starColors[i];
          ctx.strokeStyle = '#0b0e14';
          ctx.lineWidth = 2;
          ctx.beginPath();
          for (let p = 0; p < 10; p++) {
            const rad = p % 2 === 0 ? 7.5 : 3.5;
            const a = (p * Math.PI) / 5 - Math.PI / 2 + nowSec * 1.5;
            const px = sx + Math.cos(a) * rad;
            const py = sy + Math.sin(a) * rad;
            if (p === 0) ctx.moveTo(px, py);
            else ctx.lineTo(px, py);
          }
          ctx.closePath();
          ctx.fill();
          ctx.stroke();
        }
      }

      ctx.restore();
    };

    const drawHeadshotStarburst = (burst: HeadshotBurst) => {
      const progress = 1 - burst.life / burst.maxLife;
      const scale = progress < 0.2 ? progress / 0.2 : 1 - (progress - 0.2) * 0.25;
      const alpha = burst.life < 0.25 ? burst.life / 0.25 : 1;

      ctx.save();
      ctx.translate(burst.x, burst.y);
      ctx.scale(scale, scale);
      ctx.globalAlpha = Math.max(0, Math.min(1, alpha));

      ctx.fillStyle = '#25c8ff';
      ctx.strokeStyle = '#0b0e14';
      ctx.lineWidth = 3.5;
      ctx.lineJoin = 'round';
      ctx.beginPath();
      const spikes = 8;
      for (let i = 0; i < spikes * 2; i++) {
        const r = i % 2 === 0 ? 28 : 16;
        const a = (i * Math.PI) / spikes;
        const px = Math.cos(a) * r;
        const py = Math.sin(a) * r;
        if (i === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.closePath();
      ctx.fill();
      ctx.stroke();

      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 3.4;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(-7, -7);
      ctx.lineTo(7, 7);
      ctx.moveTo(7, -7);
      ctx.lineTo(-7, 7);
      ctx.stroke();

      ctx.restore();
    };

    const render = (now: number) => {
      const dt = Math.min(0.033, Math.max(0.001, (now - lastTime) / 1000));
      lastTime = now;
      const nowSec = now / 1000;

      update(dt);

      const cw = canvas.width;
      const ch = canvas.height;
      const scale = ch / VIRTUAL_HEIGHT;

      ctx.save();
      ctx.clearRect(0, 0, cw, ch);
      ctx.scale(scale, scale);

      let shakeX = 0;
      let shakeY = 0;
      if (state.shakeTime > 0) {
        const mag = state.shakeStrength * (state.shakeTime / 0.28);
        shakeX = (Math.random() - 0.5) * mag * 2;
        shakeY = (Math.random() - 0.5) * mag * 2;
      }

      const vw = state.viewWidth;
      const camX = state.cameraX;

      // 1. Sky Gradient
      const skyGrad = ctx.createLinearGradient(0, 0, 0, VIRTUAL_HEIGHT);
      skyGrad.addColorStop(0, '#44b7fc');
      skyGrad.addColorStop(0.65, '#76d1ff');
      skyGrad.addColorStop(1, '#9de3ff');
      ctx.fillStyle = skyGrad;
      ctx.fillRect(0, 0, vw, VIRTUAL_HEIGHT);

      // 2. Parallax Clouds & Far Ice Domes
      ctx.save();
      const p1 = -camX * 0.18;
      ctx.fillStyle = '#bde9ff';
      [120, 420, 740, 1080, 1420].forEach((cx, i) => {
        const x = ((cx + p1) % (vw + 360)) - 120;
        const y = 115 + (i % 3) * 48;
        ctx.beginPath();
        ctx.arc(x, y, 36, 0, Math.PI * 2);
        ctx.arc(x + 34, y - 10, 44, 0, Math.PI * 2);
        ctx.arc(x + 74, y, 34, 0, Math.PI * 2);
        ctx.fill();
      });

      ctx.fillStyle = '#5fc2fa';
      for (let i = -1; i < 6; i++) {
        const bx = i * 420 + (p1 % 420);
        ctx.beginPath();
        ctx.arc(bx + 180, 520, 210, Math.PI, 0);
        ctx.fill();
      }
      ctx.restore();

      // 3. Mid Parallax Mesas
      ctx.save();
      const p2 = -camX * 0.45;
      ctx.fillStyle = '#2e98ee';
      for (let i = -1; i < 7; i++) {
        const mx = i * 380 + (p2 % 380);
        const h = 210 + (i % 2) * 85;
        ctx.beginPath();
        ctx.roundRect(mx, 560 - h, 145, h + 200, [48, 48, 0, 0]);
        ctx.fill();
      }
      ctx.restore();

      // 4. Near Parallax Stylized Pine Trees
      ctx.save();
      const p3 = -camX * 0.72;
      ctx.fillStyle = '#1e7fd9';
      [140, 460, 790, 1180, 1540, 1890, 2240].forEach((tx, idx) => {
        const x = tx + p3;
        const baseY = 535 + (idx % 2) * 18;
        const treeH = 145 + (idx % 3) * 28;
        ctx.fillRect(x - 10, baseY - 24, 20, 40);
        ctx.beginPath();
        ctx.moveTo(x, baseY - treeH);
        ctx.lineTo(x + 56, baseY - 18);
        ctx.quadraticCurveTo(x, baseY - 4, x - 56, baseY - 18);
        ctx.closePath();
        ctx.fill();
      });
      ctx.restore();

      // World Space
      ctx.save();
      ctx.translate(-camX + shakeX, shakeY);

      // 5. Terrain Cliff Fill + Snow Cap
      const pts = state.terrain.points;
      ctx.beginPath();
      ctx.moveTo(pts[0].x, pts[0].y);
      for (let i = 1; i < pts.length; i++) {
        ctx.lineTo(pts[i].x, pts[i].y);
      }
      ctx.lineTo(WORLD_WIDTH + 300, VIRTUAL_HEIGHT + 100);
      ctx.lineTo(-300, VIRTUAL_HEIGHT + 100);
      ctx.closePath();
      ctx.fillStyle = '#223564';
      ctx.fill();

      ctx.save();
      ctx.clip();
      ctx.fillStyle = '#1a2a52';
      [610, 680, 745].forEach((sy, idx) => {
        ctx.beginPath();
        ctx.roundRect(120 + idx * 140, sy, 520, 38, 19);
        ctx.roundRect(pts[4].x + 60 + idx * 120, sy - 20, 560, 38, 19);
        ctx.fill();
      });

      ctx.fillStyle = '#19284f';
      ctx.beginPath();
      ctx.moveTo(pts[1].x, pts[1].y);
      ctx.lineTo(pts[2].x, pts[2].y);
      ctx.lineTo(pts[2].x, VIRTUAL_HEIGHT);
      ctx.lineTo(pts[1].x - 80, VIRTUAL_HEIGHT);
      ctx.closePath();
      ctx.fill();

      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.moveTo(pts[0].x, pts[0].y);
      ctx.lineTo(pts[1].x, pts[1].y);
      ctx.lineTo(pts[1].x - 18, pts[1].y + 24);
      ctx.lineTo(pts[0].x, pts[0].y + 24);
      ctx.closePath();
      ctx.fill();

      ctx.beginPath();
      ctx.moveTo(pts[4].x, pts[4].y);
      ctx.lineTo(pts[5].x, pts[5].y);
      ctx.lineTo(pts[5].x, pts[5].y + 24);
      ctx.lineTo(pts[4].x + 18, pts[4].y + 24);
      ctx.closePath();
      ctx.fill();

      ctx.beginPath();
      ctx.moveTo(pts[2].x, pts[2].y);
      ctx.lineTo(pts[3].x, pts[3].y);
      ctx.lineTo(pts[3].x, pts[3].y + 18);
      ctx.lineTo(pts[2].x, pts[2].y + 18);
      ctx.closePath();
      ctx.fill();
      ctx.restore();

      ctx.strokeStyle = '#0b0e14';
      ctx.lineWidth = 4;
      ctx.lineJoin = 'round';
      ctx.beginPath();
      ctx.moveTo(pts[0].x, pts[0].y);
      for (let i = 1; i < pts.length; i++) {
        ctx.lineTo(pts[i].x, pts[i].y);
      }
      ctx.stroke();

      // 6. Fighters
      drawFighter(state.p1, 'p1', '#f13a3a', '#c92424', nowSec);
      drawFighter(state.p2, 'p2', '#2eb6ff', '#1a94d9', nowSec);

      // 7. Dotted Trajectory Aim Preview
      if (
        state.phase === 'AIM' &&
        state.turn === localSlot &&
        state.aim.active &&
        state.aim.forcePercent >= 12
      ) {
        const myFighter = localSlot === 'p1' ? state.p1 : state.p2;
        const gy = getGroundY(state.terrain, myFighter.x);
        const sx = myFighter.x + myFighter.facing * 24;
        const sy = gy + SHOULDER_OFFSET_Y;
        for (let i = 1; i <= 7; i++) {
          const t = i * 0.058;
          const dx = sx + state.aim.vx * t;
          const dy = sy + state.aim.vy * t + 0.5 * GRAVITY * t * t;
          ctx.fillStyle = `rgba(255, 255, 255, ${0.92 - i * 0.1})`;
          ctx.beginPath();
          ctx.arc(dx, dy, Math.max(2.6, 5.2 - i * 0.35), 0, Math.PI * 2);
          ctx.fill();
        }
      }

      // 8. Projectile & Trail
      if (state.projectile) {
        const proj = state.projectile;
        if (proj.trail.length > 1) {
          for (let i = 1; i < proj.trail.length; i++) {
            const alpha = (i / proj.trail.length) * 0.65;
            ctx.strokeStyle = `rgba(255, 255, 255, ${alpha})`;
            ctx.lineWidth = (i / proj.trail.length) * 8;
            ctx.lineCap = 'round';
            ctx.beginPath();
            ctx.moveTo(proj.trail[i - 1].x, proj.trail[i - 1].y);
            ctx.lineTo(proj.trail[i].x, proj.trail[i].y);
            ctx.stroke();
          }
        }
        ctx.fillStyle = '#ffffff';
        ctx.strokeStyle = '#0b0e14';
        ctx.lineWidth = 3.2;
        ctx.beginPath();
        ctx.arc(proj.x, proj.y, 8.5, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
      }

      // 9. Snow Splash Particles
      state.particles.forEach((p) => {
        const alpha = Math.min(1, p.life / 0.25);
        ctx.save();
        ctx.globalAlpha = alpha;
        ctx.fillStyle = p.color;
        ctx.strokeStyle = '#0b0e14';
        ctx.lineWidth = 2.4;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
        ctx.restore();
      });

      // 10. Headshot Starburst & Floating "Headshot!" Text
      state.headshotBursts.forEach(drawHeadshotStarburst);

      state.banners.forEach((b) => {
        const alpha = Math.min(1, b.life / 0.35);
        ctx.save();
        ctx.globalAlpha = alpha;
        ctx.font = '900 31px "Outfit", "Cairo", sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.lineWidth = 7;
        ctx.strokeStyle = '#0b0e14';
        ctx.strokeText(b.text, b.x, b.y);
        ctx.fillStyle = '#44d8ff';
        ctx.fillText(b.text, b.x, b.y);
        ctx.restore();
      });

      // 11. Aiming Force / Angle Speech Card in World Space above active player
      if (state.phase === 'AIM' && state.turn === localSlot && state.aim.active) {
        const myFighter = localSlot === 'p1' ? state.p1 : state.p2;
        const gy = getGroundY(state.terrain, myFighter.x);
        const cardX = myFighter.x + (localSlot === 'p1' ? -18 : 18);
        const cardY = gy - 168;
        const cardW = 126;
        const cardH = 60;

        ctx.save();
        ctx.fillStyle = 'rgba(255, 255, 255, 0.96)';
        ctx.strokeStyle = 'rgba(11, 14, 20, 0.14)';
        ctx.lineWidth = 2;
        ctx.shadowColor = 'rgba(0, 0, 0, 0.18)';
        ctx.shadowBlur = 12;
        ctx.shadowOffsetY = 4;
        ctx.beginPath();
        ctx.roundRect(cardX - cardW / 2, cardY - cardH / 2, cardW, cardH, 14);
        ctx.fill();
        ctx.shadowColor = 'transparent';
        ctx.stroke();

        ctx.strokeStyle = 'rgba(15, 23, 42, 0.12)';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(cardX, cardY - 18);
        ctx.lineTo(cardX, cardY + 18);
        ctx.stroke();

        ctx.textAlign = 'center';
        ctx.fillStyle = '#0f172a';
        ctx.font = '800 18px "Outfit", "Cairo", sans-serif';
        ctx.fillText(`${state.aim.forcePercent}%`, cardX - 31, cardY - 5);
        ctx.fillText(`${state.aim.angleDeg}°`, cardX + 31, cardY - 5);

        ctx.fillStyle = '#64748b';
        ctx.font = '700 11px "Cairo", sans-serif';
        ctx.fillText('القوة', cardX - 31, cardY + 15);
        ctx.fillText('الزاوية', cardX + 31, cardY + 15);
        ctx.restore();
      }

      ctx.restore(); // End world space

      // 12. Opponent Distance Badge (Screen Space)
      if (state.phase === 'AIM' || state.phase === 'BOT_THINK') {
        const isP1Shooting = state.turn === 'p1';
        const opponent = isP1Shooting ? state.p2 : state.p1;
        const opponentScreenX = opponent.x - camX;
        const isOffscreen = opponentScreenX < 40 || opponentScreenX > vw - 40;

        if (isOffscreen) {
          const distMeters = Math.max(
            1,
            Math.round(Math.abs(state.p2.x - state.p1.x) / PIXELS_PER_METER),
          );
          const oppGy = getGroundY(state.terrain, opponent.x);
          const badgeY = Math.max(170, Math.min(VIRTUAL_HEIGHT - 170, oppGy - 62));
          const badgeX = isP1Shooting ? vw - 44 : 44;
          const badgeColor = isP1Shooting ? '#2eb6ff' : '#f13a3a';

          ctx.save();
          ctx.fillStyle = '#ffffff';
          ctx.strokeStyle = '#0b0e14';
          ctx.lineWidth = 3;
          ctx.shadowColor = 'rgba(0,0,0,0.2)';
          ctx.shadowBlur = 10;
          ctx.beginPath();
          ctx.roundRect(badgeX - 28, badgeY - 32, 56, 66, 18);
          ctx.fill();
          ctx.shadowColor = 'transparent';
          ctx.stroke();

          ctx.fillStyle = badgeColor;
          ctx.beginPath();
          ctx.roundRect(badgeX - 15, badgeY - 22, 30, 26, 8);
          ctx.fill();
          ctx.strokeStyle = '#0b0e14';
          ctx.lineWidth = 2;
          ctx.stroke();

          ctx.fillStyle = '#ffe0c2';
          ctx.beginPath();
          ctx.roundRect(badgeX - 8, badgeY - 17, 16, 15, 4);
          ctx.fill();
          ctx.stroke();

          ctx.fillStyle = '#14171f';
          ctx.fillRect(badgeX - 4, badgeY - 12, 2.5, 4.5);
          ctx.fillRect(badgeX + 1.5, badgeY - 12, 2.5, 4.5);

          ctx.fillStyle = '#0f172a';
          ctx.font = '800 13px "Outfit", sans-serif';
          ctx.textAlign = 'center';
          ctx.fillText(`${distMeters}m`, badgeX, badgeY + 23);
          ctx.restore();
        }
      }

      ctx.restore();
      rafId = requestAnimationFrame(render);
    };

    rafId = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(rafId);
      ro.disconnect();
    };
  }, [difficulty, localSlot, mode, onGameOver, p1Label, p2Label]);

  const computeAimFromPointer = (clientX: number, clientY: number) => {
    const state = engineRef.current;
    const canvas = canvasRef.current;
    if (!state || !canvas) return;
    const rect = canvas.getBoundingClientRect();
    const scaleY = VIRTUAL_HEIGHT / Math.max(1, rect.height);

    const currX = (clientX - rect.left) * scaleY;
    const currY = (clientY - rect.top) * scaleY;

    // Slingshot: p1 pulls LEFT & DOWN to shoot RIGHT; p2 pulls RIGHT & DOWN to shoot LEFT
    const rawForwardDx =
      localSlot === 'p1' ? state.aim.startX - currX : currX - state.aim.startX;
    const rawDy = currY - state.aim.startY;
    const dragDist = Math.hypot(currX - state.aim.startX, currY - state.aim.startY);

    const maxDrag = 140;
    const clampedRatio = Math.min(1, dragDist / maxDrag);
    const forcePercent = Math.max(10, Math.round(clampedRatio * 100));

    let angleDeg = 15;
    if (dragDist >= 6) {
      const dx = Math.max(10, rawForwardDx);
      angleDeg = Math.round((Math.atan2(rawDy, dx) * 180) / Math.PI);
      angleDeg = Math.max(-12, Math.min(75, angleDeg));
    }

    const angleRad = (angleDeg * Math.PI) / 180;
    const speed =
      MIN_THROW_SPEED + (forcePercent / 100) * (MAX_THROW_SPEED - MIN_THROW_SPEED);

    const dirSign = localSlot === 'p1' ? 1 : -1;
    state.aim.currX = currX;
    state.aim.currY = currY;
    state.aim.forcePercent = forcePercent;
    state.aim.angleDeg = angleDeg;
    state.aim.vx = dirSign * Math.cos(angleRad) * speed;
    state.aim.vy = -Math.sin(angleRad) * speed;
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const state = engineRef.current;
    const canvas = canvasRef.current;
    if (!state || !canvas || state.phase !== 'AIM' || state.turn !== localSlot) return;

    const rect = canvas.getBoundingClientRect();
    const scaleY = VIRTUAL_HEIGHT / Math.max(1, rect.height);
    const startX = (e.clientX - rect.left) * scaleY;
    const startY = (e.clientY - rect.top) * scaleY;

    canvas.setPointerCapture(e.pointerId);
    state.aim.active = true;
    state.aim.startX = startX;
    state.aim.startY = startY;
    state.aim.currX = startX;
    state.aim.currY = startY;
    computeAimFromPointer(e.clientX, e.clientY);
    setIsAimingUi(true);
    setTapHintVisible(false);

    if (mode === 'online' && onlineClient) {
      onlineClient.sendAimSync(true, state.aim.forcePercent, state.aim.angleDeg);
    }
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const state = engineRef.current;
    if (!state || !state.aim.active || state.phase !== 'AIM' || state.turn !== localSlot) return;
    computeAimFromPointer(e.clientX, e.clientY);
    if (mode === 'online' && onlineClient) {
      onlineClient.sendAimSync(true, state.aim.forcePercent, state.aim.angleDeg);
    }
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const state = engineRef.current;
    const canvas = canvasRef.current;
    if (!state || !state.aim.active) return;

    if (canvas?.hasPointerCapture(e.pointerId)) {
      canvas.releasePointerCapture(e.pointerId);
    }

    const dragDist = Math.hypot(
      state.aim.currX - state.aim.startX,
      state.aim.currY - state.aim.startY,
    );

    state.aim.active = false;
    setIsAimingUi(false);

    if (dragDist < 14) {
      state.tapHintTimer = 2.0;
      setTapHintVisible(true);
      if (mode === 'online' && onlineClient) {
        onlineClient.sendAimSync(false, 0, 0);
      }
      return;
    }

    if (mode === 'online' && onlineClient) {
      onlineClient.sendAimSync(false, 0, 0);
      state.phase = 'AWAITING_SERVER';
      setPhaseUi('AWAITING_SERVER');
      onlineClient.fireShot(state.aim.vx, state.aim.vy);
      return;
    }

    // Local Bot mode launch
    const shooter = state.p1;
    const gy = getGroundY(state.terrain, shooter.x);
    const sx = shooter.x + 24;
    const sy = gy + SHOULDER_OFFSET_Y;

    shooter.throwAnimTimer = 0.28;
    state.projectile = {
      x: sx,
      y: sy,
      vx: state.aim.vx,
      vy: state.aim.vy,
      shooterSlot: 'p1',
      trail: [{ x: sx, y: sy }],
      flightElapsed: 0,
    };
    state.phase = 'FLIGHT';
    setPhaseUi('FLIGHT');
    soundManager.playThrow();
  };

  const isLocalTurn = turnUi === localSlot;
  const isOpponentTurnHighlight = !isLocalTurn && phaseUi !== 'VICTORY_POSE';
  const opponentName = localSlot === 'p1' ? p2Label : p1Label;
  const canDragNow = phaseUi === 'AIM' && isLocalTurn;

  return (
    <div
      ref={containerRef}
      className="relative w-full h-full select-none overflow-hidden bg-[#4ebcff]"
      dir="ltr"
    >
      <canvas
        ref={canvasRef}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={handlePointerUp}
        className={`block w-full h-full touch-none ${
          canDragNow ? 'cursor-crosshair' : 'cursor-default'
        }`}
      />

      {/* Glowing Cyan Vignette on Opponent/Bot Turn */}
      {isOpponentTurnHighlight && (
        <div
          className="pointer-events-none absolute inset-0 transition-opacity duration-300"
          style={{
            boxShadow: 'inset 0 0 42px 8px rgba(0, 185, 255, 0.78)',
          }}
        />
      )}

      {/* Top Health Bars HUD */}
      <div className="pointer-events-none absolute top-3.5 left-3 right-3 z-20 flex items-start justify-between gap-3">
        {/* P1 Red Bar (Left) */}
        <div className="flex flex-col flex-1 max-w-[46%]">
          <div className="flex items-center">
            <div
              className={`relative z-10 flex items-center justify-center w-11 h-11 rounded-xl border-[3px] border-[#0b0e14] bg-[#f13a3a] shadow-md transition-transform ${
                turnUi === 'p1' && phaseUi === 'AIM' ? 'scale-105 ring-2 ring-white/80' : ''
              }`}
            >
              <MiniAvatarIcon color="#f13a3a" />
            </div>
            <div className="relative -ml-2 flex-1 h-6 rounded-r-full border-[3px] border-[#0b0e14] bg-[#2a3340] overflow-hidden shadow-md">
              <div
                className="h-full bg-[#f13a3a] transition-all duration-300 ease-out relative"
                style={{ width: `${(p1HpUi / MAX_HP) * 100}%` }}
              >
                <div className="absolute inset-x-0 bottom-0 h-1.5 bg-[#c92424]" />
              </div>
              {p1HpUi <= 0 && (
                <div className="absolute inset-0 flex items-center justify-center text-[#ff3b4e] font-black text-xl drop-shadow-[0_1px_1px_#000]">
                  ✕
                </div>
              )}
            </div>
          </div>
          {mode === 'online' && (
            <span
              className="mt-1 px-1 text-[11px] font-black text-white truncate drop-shadow-[0_1px_2px_rgba(0,0,0,0.85)]"
              dir="rtl"
            >
              {p1Label}
            </span>
          )}
        </div>

        {/* P2 Blue Bar (Right) */}
        <div className="flex flex-col items-end flex-1 max-w-[46%]">
          <div className="flex items-center justify-end w-full">
            <div className="relative -mr-2 flex-1 h-6 rounded-l-full border-[3px] border-[#0b0e14] bg-[#2a3340] overflow-hidden shadow-md">
              <div
                className="ml-auto h-full bg-[#2eb6ff] transition-all duration-300 ease-out relative"
                style={{ width: `${(p2HpUi / MAX_HP) * 100}%` }}
              >
                <div className="absolute inset-x-0 bottom-0 h-1.5 bg-[#1a94d9]" />
              </div>
              {p2HpUi <= 0 && (
                <div className="absolute inset-0 flex items-center justify-center text-[#ff3b4e] font-black text-xl drop-shadow-[0_1px_1px_#000]">
                  ✕
                </div>
              )}
            </div>
            <div
              className={`relative z-10 flex items-center justify-center w-11 h-11 rounded-xl border-[3px] border-[#0b0e14] bg-[#2eb6ff] shadow-md transition-transform ${
                turnUi === 'p2' ? 'scale-105 ring-2 ring-white/80' : ''
              }`}
            >
              <MiniAvatarIcon color="#2eb6ff" />
            </div>
          </div>
          {mode === 'online' && (
            <span
              className="mt-1 px-1 text-[11px] font-black text-white truncate drop-shadow-[0_1px_2px_rgba(0,0,0,0.85)]"
              dir="rtl"
            >
              {p2Label}
            </span>
          )}
        </div>
      </div>

      {/* Opponent / Bot Turn Center Title */}
      {isOpponentTurnHighlight && (
        <div
          className="pointer-events-none absolute top-18 inset-x-0 z-20 flex justify-center px-4"
          dir="rtl"
        >
          <div
            className="text-white font-black text-2xl sm:text-3xl tracking-tight text-center"
            style={{
              WebkitTextStroke: '1.5px #0b0e14',
              textShadow: '0 3px 0 #0b0e14, 0 6px 14px rgba(0,0,0,0.28)',
            }}
          >
            {mode === 'bot' ? 'دور البوت' : `دور ${opponentName}`}
          </div>
        </div>
      )}

      {/* Tap Hint Bubble when user clicks without dragging */}
      {tapHintVisible && canDragNow && (
        <div
          className="pointer-events-none absolute top-28 inset-x-0 z-20 flex justify-center px-4"
          dir="rtl"
        >
          <div className="flex items-center gap-2 bg-white text-slate-900 font-bold text-sm px-4 py-2.5 rounded-2xl border-2 border-slate-900 shadow-lg">
            <span>👆</span>
            <span>اسحب للخلف للتصويب ثم اترك</span>
          </div>
        </div>
      )}

      {/* "Your Turn" Orange Dome at Bottom Center */}
      {canDragNow && !isAimingUi && (
        <div
          className="pointer-events-none absolute -bottom-16 left-1/2 -translate-x-1/2 z-10 flex items-start justify-center w-64 h-36 rounded-t-full bg-[#f57b35] shadow-[0_0_0_16px_rgba(245,123,53,0.32)] pt-7"
          dir="rtl"
        >
          <span className="text-white font-black text-2xl drop-shadow-sm">دورك</span>
        </div>
      )}

      {/* Sound Toggle Button */}
      <button
        type="button"
        onClick={toggleMute}
        aria-label={muted ? 'تشغيل الصوت' : 'كتم الصوت'}
        className="absolute bottom-4 left-4 z-30 w-12 h-12 rounded-full bg-white/95 text-slate-900 border-2 border-[#0b0e14] shadow-lg flex items-center justify-center active:scale-95 transition-transform cursor-pointer"
      >
        {muted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
      </button>

      {/* EXIT Button */}
      <button
        type="button"
        onClick={onExit}
        className="absolute bottom-4 right-4 z-30 w-14 h-14 rounded-full bg-white text-slate-900 border-2 border-[#0b0e14] shadow-lg flex items-center justify-center font-black text-xs active:scale-95 transition-transform cursor-pointer"
      >
        خروج
      </button>
    </div>
  );
};
