import { useCallback, useEffect, useRef, useState } from 'react';
import { Volume2, VolumeX, LogOut, Zap, Eye } from 'lucide-react';
import {
  ARENA_HEIGHT,
  BASE_CEILING_Y,
  BASE_FLOOR_Y,
  createInitialGravityWorld,
  ensureWorldGeneratedAhead,
  getSpeedAtTime,
  pruneWorldBehind,
  ROUND_DURATION_SECONDS,
  type BiomePalette,
  type GravityWorldData,
  type SpikeTrap,
  type SurfaceSpan,
  type WallObstacle,
  type WoodenCrate,
} from '../game/gravityLevel';
import {
  checkRunnerSpikes,
  FLIP_IMPULSE,
  rectsOverlap,
  RUNNER_H,
  RUNNER_W,
  simulateBotBranch,
  stepRunnerPhysics,
  type RunnerState,
} from '../game/gravityPhysics';
import type { GravityFlipPayload, OnlineGameClient } from '../game/onlineClient';
import { soundManager } from '../game/sound';
import type {
  Difficulty,
  GameResult,
  GravityTickPayload,
  OnlineRoomSnapshot,
  PlayerSlot,
  PlayMode,
} from '../game/types';

interface GravityRunArenaProps {
  mode: PlayMode;
  difficulty: Difficulty;
  playerName: string;
  onlineSnapshot?: OnlineRoomSnapshot;
  onlineClient?: OnlineGameClient;
  latestGravityState?: GravityTickPayload | null;
  latestGravityFlip?: { seq: number; flip: GravityFlipPayload } | null;
  onExit: () => void;
  onGameOver: (result: GameResult) => void;
}

interface SparkParticle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  color: string;
  size: number;
}

interface RenderRunnerEntry {
  slot: PlayerSlot;
  label: string;
  accent: string;
  state: RunnerState;
  isLocal: boolean;
}

const SLOT_COLORS: Record<PlayerSlot, string> = {
  p1: '#ef4444', // Red
  p2: '#3b82f6', // Blue
  p3: '#a855f7', // Purple
};

function hexToRgb(hex: string): [number, number, number] {
  const clean = hex.replace('#', '');
  const num = parseInt(clean.length === 3 ? clean.replace(/(.)/g, '$1$1') : clean, 16);
  return [(num >> 16) & 255, (num >> 8) & 255, num & 255];
}

function lerpHex(a: string, b: string, t: number): string {
  if (!a.startsWith('#') || !b.startsWith('#')) return t < 0.5 ? a : b;
  const [r1, g1, b1] = hexToRgb(a);
  const [r2, g2, b2] = hexToRgb(b);
  const r = Math.round(r1 + (r2 - r1) * t);
  const g = Math.round(g1 + (g2 - g1) * t);
  const bl = Math.round(b1 + (b2 - b1) * t);
  return `rgb(${r}, ${g}, ${bl})`;
}

function getBiomeState(
  world: GravityWorldData,
  elapsedSec: number,
): { current: BiomePalette; next: BiomePalette; blend: number; index: number } {
  const order = world.biomeOrder;
  const thresholds = [0, 27, 54, 81, 106];
  let idx = 0;
  for (let i = thresholds.length - 1; i >= 0; i--) {
    if (elapsedSec >= thresholds[i]) {
      idx = i;
      break;
    }
  }
  const current = order[idx];
  const nextIdx = Math.min(order.length - 1, idx + 1);
  const next = order[nextIdx];
  let blend = 0;
  if (idx < thresholds.length - 1) {
    const nextStart = thresholds[idx + 1];
    if (elapsedSec >= nextStart - 3) {
      blend = Math.min(1, Math.max(0, (elapsedSec - (nextStart - 3)) / 3));
    }
  }
  return { current, next, blend, index: idx };
}

function getGraceSeconds(difficulty: Difficulty): number {
  if (difficulty === 'easy') return 80; // 1:20 (loses before 2:00 finish)
  if (difficulty === 'medium') return 102; // 1:42 (harder, can lose before 2:00 finish)
  return Number.POSITIVE_INFINITY; // Hard never falls or touches spikes
}

function createRunner(startX: number, phaseOffset = 0): RunnerState {
  return {
    x: startX,
    y: BASE_FLOOR_Y - RUNNER_H,
    vy: 0,
    gravityDir: 1,
    grounded: true,
    coyoteTimer: 0.085,
    flipBufferTimer: 0,
    boostTimer: 0,
    runPhase: phaseOffset,
    trail: [],
    alive: true,
    stuckDir: null,
  };
}

export function GravityRunArena({
  mode,
  difficulty,
  playerName,
  onlineSnapshot,
  onlineClient,
  latestGravityState,
  latestGravityFlip,
  onExit,
  onGameOver,
}: GravityRunArenaProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [muted, setMuted] = useState(soundManager.muted);
  const [isSpectating, setIsSpectating] = useState(false);
  const [hudState, setHudState] = useState<{
    hasBoost: boolean;
    markers: Array<{ slot: PlayerSlot; label: string; color: string; progress: number; alive: boolean }>;
  }>({
    hasBoost: false,
    markers: [],
  });

  const onGameOverRef = useRef(onGameOver);
  onGameOverRef.current = onGameOver;
  const onlineSnapRef = useRef(onlineSnapshot);
  onlineSnapRef.current = onlineSnapshot;
  const onlineClientRef = useRef(onlineClient);
  onlineClientRef.current = onlineClient;

  const latestGravityStateRef = useRef<GravityTickPayload | null>(null);
  latestGravityStateRef.current = latestGravityState || null;

  const flipPlayerRef = useRef<() => void>(() => {});
  const remoteFlipHandlerRef = useRef<(flip: GravityFlipPayload) => void>(() => {});

  const toggleMute = () => {
    soundManager.muted = !soundManager.muted;
    setMuted(soundManager.muted);
  };

  const triggerPlayerFlip = useCallback(() => {
    flipPlayerRef.current();
  }, []);

  useEffect(() => {
    if (latestGravityFlip) {
      remoteFlipHandlerRef.current(latestGravityFlip.flip);
    }
  }, [latestGravityFlip]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const initialSeed = mode === 'online' ? onlineSnapRef.current?.seed : undefined;
    const world = createInitialGravityWorld(initialSeed);
    ensureWorldGeneratedAhead(world, 2800, 0);

    const entries: RenderRunnerEntry[] = [];
    const mySlot: PlayerSlot = mode === 'online' ? onlineSnapRef.current?.yourSlot || 'p1' : 'p1';

    if (mode === 'online' && onlineSnapRef.current) {
      const snap = onlineSnapRef.current;
      (['p1', 'p2', 'p3'] as const).forEach((slot, idx) => {
        const p = snap.players[slot];
        if (!p) return;
        entries.push({
          slot,
          label: p.name,
          accent: SLOT_COLORS[slot],
          state: createRunner(220 - idx * 22, idx * 1.1),
          isLocal: slot === mySlot,
        });
      });
    } else {
      entries.push({
        slot: 'p1',
        label: playerName,
        accent: SLOT_COLORS.p1,
        state: createRunner(220, 0),
        isLocal: true,
      });
      entries.push({
        slot: 'p2',
        label: 'البوت',
        accent: SLOT_COLORS.p2,
        state: createRunner(198, 1.3),
        isLocal: false,
      });
    }

    const sparks: SparkParticle[] = [];
    const graceSec = getGraceSeconds(difficulty);

    let cameraX = 0;
    let elapsedSec = 0;
    let finished = false;
    let botFlipCooldown = 0;
    let lastHudUpdate = 0;
    let lastAppliedServerTime = -1;
    let animFrame = 0;
    let lastTimestamp = performance.now();

    const spawnBurst = (x: number, y: number, color: string, count = 16) => {
      for (let i = 0; i < count; i++) {
        const angle = (Math.PI * 2 * i) / count + Math.random() * 0.4;
        const spd = 90 + Math.random() * 240;
        sparks.push({
          x,
          y,
          vx: Math.cos(angle) * spd,
          vy: Math.sin(angle) * spd,
          life: 0.42 + Math.random() * 0.25,
          maxLife: 0.65,
          color,
          size: 3 + Math.random() * 3.5,
        });
      }
    };

    const executeFlip = (runner: RunnerState, accentColor: string, playSfx: boolean) => {
      runner.gravityDir = runner.gravityDir === 1 ? -1 : 1;
      runner.vy = runner.gravityDir * FLIP_IMPULSE;
      runner.grounded = false;
      runner.coyoteTimer = 0;
      runner.flipBufferTimer = 0;
      if (playSfx) {
        soundManager.playGravityFlip(runner.gravityDir);
      }
      spawnBurst(
        runner.x + RUNNER_W / 2,
        runner.gravityDir === -1 ? runner.y + RUNNER_H : runner.y,
        accentColor,
        6,
      );
    };

    const localEntry = entries.find((e) => e.isLocal) || entries[0];

    flipPlayerRef.current = () => {
      if (finished || !localEntry || !localEntry.state.alive) return;
      if (mode === 'online') {
        onlineClientRef.current?.sendGravityFlip();
      }
      if (localEntry.state.grounded || localEntry.state.coyoteTimer > 0) {
        executeFlip(localEntry.state, localEntry.accent, true);
      } else {
        localEntry.state.flipBufferTimer = 0.16;
      }
    };

    remoteFlipHandlerRef.current = (flip: GravityFlipPayload) => {
      if (mode !== 'online') return;
      const target = entries.find((e) => e.slot === flip.slot);
      if (!target || target.isLocal || !target.state.alive) return;
      target.state.x = flip.x;
      target.state.y = flip.y;
      target.state.vy = flip.vy;
      target.state.gravityDir = flip.gravityDir;
      target.state.grounded = false;
      spawnBurst(
        flip.x + RUNNER_W / 2,
        flip.gravityDir === -1 ? flip.y + RUNNER_H : flip.y,
        target.accent,
        6,
      );
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.repeat) return;
      if (
        e.code === 'Space' ||
        e.code === 'ArrowUp' ||
        e.code === 'ArrowDown' ||
        e.code === 'KeyW' ||
        e.code === 'KeyS'
      ) {
        e.preventDefault();
        flipPlayerRef.current();
      }
    };
    window.addEventListener('keydown', handleKeyDown);

    const endBotMatch = (
      didLocalWin: boolean,
      winReason: 'finish' | 'bot_crash' | 'player_crash',
    ) => {
      if (finished) return;
      finished = true;
      if (didLocalWin) {
        soundManager.playVictory();
      } else {
        soundManager.playCrash();
        soundManager.playDefeat();
      }
      setTimeout(() => {
        onGameOverRef.current({
          gameId: 'gravity',
          mode: 'bot',
          winnerSlot: didLocalWin ? 'player' : 'bot',
          winnerName: didLocalWin ? playerName : 'البوت',
          didLocalWin,
          difficulty,
          winReason,
          elapsedSeconds: Math.round(elapsedSec),
        });
      }, 500);
    };

    const endOnlineMatch = (
      winnerSlot: PlayerSlot,
      winReason: 'finish' | 'last_standing' | 'forfeit',
    ) => {
      if (finished) return;
      finished = true;
      const winnerEntry = entries.find((e) => e.slot === winnerSlot);
      const winnerName =
        onlineSnapRef.current?.players[winnerSlot]?.name || winnerEntry?.label || 'انت';
      const didLocalWin = winnerSlot === mySlot;
      if (didLocalWin) {
        soundManager.playVictory();
      } else {
        soundManager.playDefeat();
      }
      setTimeout(() => {
        onGameOverRef.current({
          gameId: 'gravity',
          mode: 'online',
          winnerSlot,
          winnerName,
          didLocalWin,
          winReason,
          elapsedSeconds: Math.round(elapsedSec),
        });
      }, 500);
    };

    const frame = (now: number) => {
      const rawDt = (now - lastTimestamp) / 1000;
      lastTimestamp = now;
      const dt = Math.min(0.035, Math.max(0.001, rawDt));

      const cssW = canvas.clientWidth || window.innerWidth;
      const cssH = canvas.clientHeight || window.innerHeight;
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const targetW = Math.max(320, Math.round(cssW * dpr));
      const targetH = Math.max(240, Math.round(cssH * dpr));
      if (canvas.width !== targetW || canvas.height !== targetH) {
        canvas.width = targetW;
        canvas.height = targetH;
      }

      // Full-screen landscape scale: preserves the entire ARENA_HEIGHT (zero clipping top/bottom)
      // while showing plenty of world horizontally both behind (~220px) and far ahead
      const scale = Math.min(canvas.height / ARENA_HEIGHT, canvas.width / 820);
      const viewWidthWorld = canvas.width / scale;
      const viewHeightWorld = canvas.height / scale;
      const trackOffsetY = (viewHeightWorld - ARENA_HEIGHT) * 0.5;

      if (!finished) {
        if (mode === 'online') {
          // --- ONLINE AUTHORITATIVE SYNC + SMOOTH LOCAL STEP ---
          const srv = latestGravityStateRef.current;
          if (srv && srv.elapsedSec > lastAppliedServerTime) {
            lastAppliedServerTime = srv.elapsedSec;
            elapsedSec = srv.elapsedSec;
            cameraX = cameraX + (srv.cameraX - cameraX) * 0.65;
            if (Math.abs(srv.cameraX - cameraX) > 45) cameraX = srv.cameraX;
            ensureWorldGeneratedAhead(world, cameraX + viewWidthWorld + 1400, elapsedSec);

            for (const entry of entries) {
              const sRunner = srv.runners[entry.slot];
              if (!sRunner) continue;
              const wasAlive = entry.state.alive;
              entry.state.alive = sRunner.alive;

              if (wasAlive && !sRunner.alive) {
                spawnBurst(
                  entry.state.x + RUNNER_W / 2,
                  entry.state.y + RUNNER_H / 2,
                  entry.accent,
                  24,
                );
                if (entry.isLocal) {
                  soundManager.playCrash();
                  setIsSpectating(true);
                }
              }

              if (sRunner.alive) {
                const dxErr = sRunner.x - entry.state.x;
                const dyErr = sRunner.y - entry.state.y;
                if (Math.abs(dxErr) > 36 || Math.abs(dyErr) > 36) {
                  entry.state.x = sRunner.x;
                  entry.state.y = sRunner.y;
                } else {
                  entry.state.x += dxErr * (entry.isLocal ? 0.35 : 0.5);
                  entry.state.y += dyErr * (entry.isLocal ? 0.35 : 0.5);
                }
                entry.state.vy = sRunner.vy;
                entry.state.gravityDir = sRunner.gravityDir;
                entry.state.grounded = sRunner.grounded;
                entry.state.boostTimer = sRunner.boostTimer;
              }
            }

            if (srv.winner && srv.winReason) {
              endOnlineMatch(srv.winner, srv.winReason);
            }
          } else {
            // Smooth between server snapshots
            elapsedSec += dt;
            const baseSpeed = getSpeedAtTime(elapsedSec);
            cameraX += baseSpeed * dt;
            ensureWorldGeneratedAhead(world, cameraX + viewWidthWorld + 1400, elapsedSec);

            for (const entry of entries) {
              if (!entry.state.alive) continue;
              const r = entry.state;
              if (r.flipBufferTimer > 0) r.flipBufferTimer = Math.max(0, r.flipBufferTimer - dt);
              if (r.boostTimer > 0) r.boostTimer = Math.max(0, r.boostTimer - dt);

              let spd = baseSpeed;
              if (r.boostTimer > 0) spd += 95;
              stepRunnerPhysics(r, world, spd * dt, dt);
              if (entry.isLocal && r.grounded && r.flipBufferTimer > 0) {
                executeFlip(r, entry.accent, true);
              }
            }
          }

          for (const entry of entries) {
            if (!entry.state.alive) continue;
            const spd = getSpeedAtTime(elapsedSec);
            entry.state.runPhase += dt * (spd / 42);
          }

          pruneWorldBehind(world, cameraX - 500);
        } else {
          // --- BOT MODE ---
          elapsedSec += dt;
          const baseSpeed = getSpeedAtTime(elapsedSec);
          cameraX += baseSpeed * dt;

          ensureWorldGeneratedAhead(world, cameraX + viewWidthWorld + 1400, elapsedSec);
          pruneWorldBehind(world, cameraX - 500);

          const playerEntry = entries[0];
          const botEntry = entries[1];
          const player = playerEntry.state;
          const bot = botEntry.state;

          // PLAYER UPDATE
          if (player.flipBufferTimer > 0) {
            player.flipBufferTimer = Math.max(0, player.flipBufferTimer - dt);
          }
          if (player.boostTimer > 0) {
            player.boostTimer = Math.max(0, player.boostTimer - dt);
          }

          let playerSpeed = baseSpeed;
          if (player.boostTimer > 0) {
            playerSpeed += 95;
          } else if (player.x < cameraX + 220) {
            playerSpeed += 38;
          } else if (player.x > cameraX + 234) {
            playerSpeed -= 8;
          }
          if (player.x > cameraX + viewWidthWorld * 0.48) {
            playerSpeed = Math.min(playerSpeed, baseSpeed);
          }

          const pPrevX = player.x;
          const pPrevY = player.y;
          const pOutcome = stepRunnerPhysics(player, world, playerSpeed * dt, dt);
          player.runPhase += dt * (playerSpeed / 42);

          if (player.grounded && player.flipBufferTimer > 0) {
            executeFlip(player, playerEntry.accent, true);
          }

          for (let i = 0; i < world.boosts.length; i++) {
            const b = world.boosts[i];
            const by = b.surface === 'floor' ? b.y - 14 : b.y;
            if (rectsOverlap(player.x, player.y, RUNNER_W, RUNNER_H, b.x, by, b.width, 14)) {
              if (player.boostTimer < 0.65) {
                soundManager.playBoost();
                spawnBurst(player.x + RUNNER_W / 2, player.y + RUNNER_H / 2, '#fde047', 10);
              }
              player.boostTimer = 0.95;
            }
          }

          // Off left screen edge after hitting crate/wall = eliminated!
          const pOffScreen = player.x + RUNNER_W < cameraX - 10;
          if (pOutcome.hitSpike || pOutcome.fellOut || pOffScreen) {
            player.alive = false;
            player.x = pPrevX;
            player.y = pPrevY;
            spawnBurst(player.x + RUNNER_W / 2, player.y + RUNNER_H / 2, playerEntry.accent, 24);
            endBotMatch(false, 'player_crash');
          }

          // BOT UPDATE
          if (!finished && bot.alive) {
            botFlipCooldown = Math.max(0, botFlipCooldown - dt);
            if (bot.boostTimer > 0) bot.boostTimer = Math.max(0, bot.boostTimer - dt);

            const isProtected = elapsedSec < graceSec;

            if (isProtected) {
              if (bot.grounded && botFlipCooldown <= 0) {
                const keepRes = simulateBotBranch(bot, world, baseSpeed, false, 30);
                const flipRes = simulateBotBranch(bot, world, baseSpeed, true, 30);
                const urgentKeepRes = simulateBotBranch(bot, world, baseSpeed, false, 18);

                if (!keepRes.safe && flipRes.safe) {
                  executeFlip(bot, botEntry.accent, false);
                  botFlipCooldown = 0.14;
                } else if (
                  !urgentKeepRes.safe &&
                  flipRes.stepsSurvived > urgentKeepRes.stepsSurvived + 3
                ) {
                  executeFlip(bot, botEntry.accent, false);
                  botFlipCooldown = 0.14;
                }
              }
            } else {
              // Past Easy (2:00) / Medium (2:30): Bot makes natural mistimed flips
              if (bot.grounded && botFlipCooldown <= 0) {
                const imminentDanger = !simulateBotBranch(bot, world, baseSpeed, false, 12).safe;
                if (!imminentDanger && Math.random() < 0.026) {
                  executeFlip(bot, botEntry.accent, false);
                  botFlipCooldown = 0.45;
                }
              }
            }

            let botSpeed = baseSpeed;
            if (bot.boostTimer > 0) {
              botSpeed += 38;
            } else if (bot.x < cameraX + 192) {
              botSpeed += 34;
            } else if (bot.x > cameraX + 206) {
              botSpeed -= 10;
            }

            const botSavedX = bot.x;
            const botSavedY = bot.y;
            const botSavedVy = bot.vy;
            const botSavedDir = bot.gravityDir;

            const bOutcome = stepRunnerPhysics(bot, world, botSpeed * dt, dt);
            bot.runPhase += dt * (botSpeed / 42);

            for (let i = 0; i < world.boosts.length; i++) {
              const b = world.boosts[i];
              const by = b.surface === 'floor' ? b.y - 14 : b.y;
              if (rectsOverlap(bot.x, bot.y, RUNNER_W, RUNNER_H, b.x, by, b.width, 14)) {
                bot.boostTimer = 0.65;
              }
            }

            const bOffScreen = bot.x + RUNNER_W < cameraX - 10;
            if (bOutcome.hitSpike || bOutcome.fellOut || bOffScreen) {
              if (isProtected) {
                bot.x = Math.max(cameraX + 190, botSavedX + botSpeed * dt);
                bot.y = botSavedY;
                bot.vy = botSavedVy;
                bot.gravityDir = botSavedDir === 1 ? -1 : 1;
                const safeY =
                  bot.gravityDir === 1 ? BASE_FLOOR_Y - RUNNER_H : BASE_CEILING_Y;
                if (!checkRunnerSpikes(bot.x, safeY, world)) {
                  bot.y = safeY;
                  bot.vy = 0;
                  bot.grounded = true;
                } else {
                  bot.y = ARENA_HEIGHT * 0.5 - RUNNER_H * 0.5;
                  bot.vy = 0;
                  bot.grounded = false;
                }
              } else {
                bot.alive = false;
                spawnBurst(bot.x + RUNNER_W / 2, bot.y + RUNNER_H / 2, botEntry.accent, 24);
                endBotMatch(true, 'bot_crash');
              }
            }
          }

          // FINISH LINE CHECK (3:00)
          if (!finished && world.finishLineX !== null) {
            const pCross = player.alive && player.x + RUNNER_W >= world.finishLineX;
            const bCross = bot.alive && bot.x + RUNNER_W >= world.finishLineX;
            if (pCross && bCross) {
              spawnBurst(world.finishLineX, ARENA_HEIGHT * 0.5, '#facc15', 30);
              endBotMatch(player.x >= bot.x, 'finish');
            } else if (pCross) {
              spawnBurst(world.finishLineX, player.y + RUNNER_H / 2, '#facc15', 30);
              endBotMatch(true, 'finish');
            } else if (bCross) {
              spawnBurst(world.finishLineX, bot.y + RUNNER_H / 2, botEntry.accent, 30);
              endBotMatch(false, 'finish');
            }
          }
        }

        // Trails update
        for (const entry of entries) {
          if (!entry.state.alive) continue;
          entry.state.trail.push({ x: entry.state.x, y: entry.state.y, alpha: 0.42 });
          if (entry.state.trail.length > 6) entry.state.trail.shift();
          entry.state.trail.forEach((t) => {
            t.alpha *= 0.82;
          });
        }
      }

      // Sparks update
      for (let i = sparks.length - 1; i >= 0; i--) {
        const sp = sparks[i];
        sp.x += sp.vx * dt;
        sp.y += sp.vy * dt;
        sp.life -= dt;
        if (sp.life <= 0) sparks.splice(i, 1);
      }

      // Biome & HUD update
      const biomeState = getBiomeState(world, elapsedSec);

      if (now - lastHudUpdate > 100) {
        lastHudUpdate = now;
        const approxTotalX =
          world.finishLineX ??
          Math.max(cameraX + 1200, 180 + ROUND_DURATION_SECONDS * 430);
        setHudState({
          hasBoost: localEntry ? localEntry.state.boostTimer > 0 : false,
          markers: entries.map((e) => ({
            slot: e.slot,
            label: e.label,
            color: e.accent,
            alive: e.state.alive,
            progress: Math.min(1, Math.max(0, (e.state.x - 220) / (approxTotalX - 220))),
          })),
        });
      }

      // ======================== RENDER ========================
      const { current: bA, next: bB, blend } = biomeState;
      const skyTop = lerpHex(bA.skyTop, bB.skyTop, blend);
      const skyBottom = lerpHex(bA.skyBottom, bB.skyBottom, blend);
      const platformFill = lerpHex(bA.platformFill, bB.platformFill, blend);
      const platformTrim = lerpHex(bA.platformTrim, bB.platformTrim, blend);
      const parallaxFar = lerpHex(bA.parallaxFar, bB.parallaxFar, blend);
      const parallaxNear = lerpHex(bA.parallaxNear, bB.parallaxNear, blend);
      const spikeFill = lerpHex(bA.spikeFill, bB.spikeFill, blend);

      ctx.save();
      ctx.scale(scale, scale);

      const bgGrad = ctx.createLinearGradient(0, 0, 0, viewHeightWorld);
      bgGrad.addColorStop(0, skyTop);
      bgGrad.addColorStop(1, skyBottom);
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, viewWidthWorld, viewHeightWorld);

      ctx.save();
      ctx.translate(0, trackOffsetY);
      const activePattern = blend > 0.5 ? bB.patternType : bA.patternType;
      drawBiomeParallax(
        ctx,
        viewWidthWorld,
        trackOffsetY,
        cameraX,
        parallaxFar,
        parallaxNear,
        bA.gridColor,
        activePattern,
      );

      ctx.save();
      ctx.translate(-cameraX, 0);

      // Floors & Ceilings (visually extended edge-to-edge vertically while keeping pits/gaps open)
      const verticalExtend = Math.max(80, Math.ceil(Math.max(0, trackOffsetY)) + 40);
      drawSurfaces(
        ctx,
        world.floors,
        cameraX,
        viewWidthWorld,
        platformFill,
        platformTrim,
        activePattern,
        false,
        verticalExtend,
      );
      drawSurfaces(
        ctx,
        world.ceilings,
        cameraX,
        viewWidthWorld,
        platformFill,
        platformTrim,
        activePattern,
        true,
        verticalExtend,
      );

      // Boost Pads
      for (let i = 0; i < world.boosts.length; i++) {
        const bp = world.boosts[i];
        if (bp.x + bp.width < cameraX - 20 || bp.x > cameraX + viewWidthWorld + 20) continue;
        drawBoostPad(ctx, bp.x, bp.y, bp.width, bp.surface, now);
      }

      // Wooden Crates
      for (let i = 0; i < world.crates.length; i++) {
        const crate = world.crates[i];
        if (crate.x + crate.width < cameraX - 40 || crate.x > cameraX + viewWidthWorld + 40) continue;
        drawWoodenCrate(ctx, crate);
      }

      // Solid Walls & Wall-mounted Spikes
      for (let i = 0; i < world.walls.length; i++) {
        const w = world.walls[i];
        if (w.x + w.width < cameraX - 40 || w.x > cameraX + viewWidthWorld + 40) continue;
        drawWall(ctx, w, platformFill, platformTrim);
        for (let j = 0; j < w.spikes.length; j++) {
          drawSpikeTrap(ctx, w.spikes[j], spikeFill, bA.spikeGlow);
        }
      }

      // Floor / Ceiling Spikes
      for (let i = 0; i < world.spikes.length; i++) {
        const sp = world.spikes[i];
        if (sp.x + sp.width < cameraX - 40 || sp.x > cameraX + viewWidthWorld + 40) continue;
        drawSpikeTrap(ctx, sp, spikeFill, bA.spikeGlow);
      }

      // Finish Line Arch (3:00)
      if (world.finishLineX !== null && world.finishLineX < cameraX + viewWidthWorld + 120) {
        drawFinishLine(ctx, world.finishLineX, now);
      }

      // Runners (remote/bot first, local player last on top)
      const orderedEntries = [...entries].sort((a, b) => Number(a.isLocal) - Number(b.isLocal));
      for (const entry of orderedEntries) {
        if (!entry.state.alive) continue;
        drawCustomCharacter(ctx, entry.state, entry.accent, entry.label, entry.isLocal);
      }

      // Burst particles
      for (let i = 0; i < sparks.length; i++) {
        const sp = sparks[i];
        ctx.globalAlpha = Math.max(0, sp.life / sp.maxLife);
        ctx.fillStyle = sp.color;
        ctx.beginPath();
        ctx.arc(sp.x, sp.y, sp.size, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalAlpha = 1;

      ctx.restore();
      ctx.restore();
      ctx.restore();

      animFrame = requestAnimationFrame(frame);
    };

    animFrame = requestAnimationFrame(frame);

    return () => {
      cancelAnimationFrame(animFrame);
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [difficulty, mode, playerName]);

  return (
    <div className="relative w-full h-full select-none overflow-hidden bg-[#0a1324]">
      <canvas
        ref={canvasRef}
        onPointerDown={(e) => {
          e.preventDefault();
          triggerPlayerFlip();
        }}
        className="w-full h-full block touch-none cursor-pointer"
      />

      {/* Ultra-slim Top Progress Bar at the very top edge so it never covers the playable track */}
      <div className="pointer-events-none absolute top-1 inset-x-0 px-2.5 flex items-center gap-2 z-10">
        <button
          type="button"
          onClick={onExit}
          className="pointer-events-auto shrink-0 flex items-center gap-1 rounded-lg bg-black/50 hover:bg-black/75 border border-white/20 px-2 py-1 text-[11px] font-extrabold text-white backdrop-blur-sm cursor-pointer"
        >
          <LogOut className="w-3 h-3" />
          <span>خروج</span>
        </button>

        <div className="mx-auto flex-1 max-w-[440px] rounded-xl bg-black/45 border border-white/15 px-2.5 py-1 backdrop-blur-sm">
          <div className="flex items-center justify-between gap-2 text-[10px] font-extrabold text-white/90 mb-0.5">
            <div className="flex items-center gap-2 flex-wrap">
              {hudState.markers.map((m) => (
                <span
                  key={m.slot}
                  className={`inline-flex items-center gap-1 ${m.alive ? '' : 'opacity-45 line-through'}`}
                >
                  <span
                    className="inline-block w-2 h-2 rounded-full border border-white/70"
                    style={{ backgroundColor: m.color }}
                  />
                  {m.label}
                </span>
              ))}
            </div>
            {hudState.hasBoost && (
              <span className="text-amber-300 inline-flex items-center gap-0.5">
                <Zap className="w-3 h-3 fill-amber-300" />
              </span>
            )}
          </div>
          <div className="relative h-1.5 rounded-full bg-white/15" dir="ltr">
            {hudState.markers.map((m) => (
              <div
                key={m.slot}
                className={`absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-2.5 h-2.5 rounded-full border-2 border-white shadow transition-all duration-100 ${
                  m.alive ? '' : 'opacity-40 grayscale'
                }`}
                style={{
                  left: `${Math.round(m.progress * 100)}%`,
                  backgroundColor: m.color,
                }}
              />
            ))}
            <span className="absolute -right-1 top-1/2 -translate-y-1/2 text-[10px] leading-none">
              🏁
            </span>
          </div>
        </div>

        <button
          type="button"
          onClick={toggleMute}
          aria-label={muted ? 'تشغيل الصوت' : 'كتم الصوت'}
          className="pointer-events-auto shrink-0 flex items-center justify-center rounded-lg bg-black/50 hover:bg-black/75 border border-white/20 w-7 h-7 text-white backdrop-blur-sm cursor-pointer"
        >
          {muted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
        </button>
      </div>

      {/* Live Spectate Badge (3-player Online after elimination) */}
      {isSpectating && (
        <div className="pointer-events-none absolute top-14 inset-x-0 flex justify-center z-20 px-4">
          <div className="flex items-center gap-2 rounded-xl bg-[#0f172a]/85 border border-amber-400/55 px-4 py-1.5 text-xs sm:text-sm font-black text-amber-200 shadow-lg backdrop-blur-md">
            <Eye className="w-4 h-4 text-amber-300" />
            <span>خرجت من الشاشة — تتابع السباق الآن حتى يتحدد الفائز</span>
          </div>
        </div>
      )}
    </div>
  );
}

// ==================== CANVAS RENDERING HELPERS ====================

function drawBiomeParallax(
  ctx: CanvasRenderingContext2D,
  viewW: number,
  trackOffsetY: number,
  cameraX: number,
  farColor: string,
  nearColor: string,
  gridColor: string,
  patternType: BiomePalette['patternType'],
): void {
  const topY = -Math.max(0, trackOffsetY) - 20;
  const bottomY = ARENA_HEIGHT + Math.max(0, trackOffsetY) + 20;

  ctx.strokeStyle = gridColor;
  ctx.lineWidth = 1;
  const gridSpacing = 70;
  const offset = -(cameraX * 0.35) % gridSpacing;
  for (let gx = offset; gx < viewW; gx += gridSpacing) {
    ctx.beginPath();
    ctx.moveTo(gx, topY);
    ctx.lineTo(gx, bottomY);
    ctx.stroke();
  }
  const startGridY = Math.floor(topY / 75) * 75;
  for (let gy = startGridY; gy < bottomY; gy += 75) {
    ctx.beginPath();
    ctx.moveTo(0, gy);
    ctx.lineTo(viewW, gy);
    ctx.stroke();
  }

  const farSpan = 260;
  const farShift = -(cameraX * 0.16) % farSpan;
  ctx.fillStyle = farColor;
  for (let x = farShift - farSpan; x < viewW + farSpan; x += farSpan) {
    if (patternType === 'crystal') {
      ctx.beginPath();
      ctx.moveTo(x + 20, ARENA_HEIGHT);
      ctx.lineTo(x + 85, 220);
      ctx.lineTo(x + 150, ARENA_HEIGHT);
      ctx.lineTo(x + 195, 290);
      ctx.lineTo(x + 250, ARENA_HEIGHT);
      ctx.fill();
    } else if (patternType === 'chevron') {
      ctx.beginPath();
      ctx.moveTo(x + 30, ARENA_HEIGHT);
      ctx.lineTo(x + 95, 200);
      ctx.lineTo(x + 135, 200);
      ctx.lineTo(x + 200, ARENA_HEIGHT);
      ctx.fill();
    } else if (patternType === 'industrial') {
      ctx.fillRect(x + 25, 190, 56, 360);
      ctx.fillRect(x + 125, 240, 82, 310);
      ctx.fillRect(x + 81, 270, 44, 22);
    } else if (patternType === 'stadium') {
      ctx.fillRect(x + 40, 150, 16, 380);
      ctx.beginPath();
      ctx.moveTo(x + 48, 160);
      ctx.lineTo(x + 190, 260);
      ctx.lineTo(x + 120, 320);
      ctx.closePath();
      ctx.fill();
    } else {
      ctx.fillRect(x + 30, 210, 66, 320);
      ctx.fillRect(x + 136, 175, 48, 355);
      ctx.fillRect(x + 54, 185, 18, 25);
    }
  }

  const nearSpan = 210;
  const nearShift = -(cameraX * 0.3) % nearSpan;
  ctx.fillStyle = nearColor;
  for (let x = nearShift - nearSpan; x < viewW + nearSpan; x += nearSpan) {
    if (patternType === 'crystal') {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x + 45, 165);
      ctx.lineTo(x + 90, 0);
      ctx.fill();
    } else if (patternType === 'industrial') {
      ctx.fillRect(x + 18, 325, 64, 210);
      ctx.fillRect(x + 115, 295, 50, 240);
    } else {
      ctx.fillRect(x + 22, 340, 58, 200);
      ctx.fillRect(x + 122, 305, 42, 235);
    }
  }
}

function drawSurfaces(
  ctx: CanvasRenderingContext2D,
  spans: SurfaceSpan[],
  cameraX: number,
  viewW: number,
  fill: string,
  trim: string,
  patternType: BiomePalette['patternType'],
  isCeiling: boolean,
  verticalExtend: number,
): void {
  for (let i = 0; i < spans.length; i++) {
    const s = spans[i];
    if (s.x + s.width < cameraX - 20 || s.x > cameraX + viewW + 20) continue;

    const drawX = Math.floor(s.x);
    const drawW = Math.ceil(s.width) + 1;
    const drawY = isCeiling ? s.y - verticalExtend : s.y;
    const drawH = s.thickness + verticalExtend;

    ctx.fillStyle = fill;
    ctx.fillRect(drawX, drawY, drawW, drawH);

    // Subtle deep-ground shadow band so extended floor/ceiling keeps crisp depth
    if (verticalExtend > 20) {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.2)';
      if (isCeiling) {
        ctx.fillRect(drawX, drawY, drawW, verticalExtend);
      } else {
        ctx.fillRect(drawX, s.y + s.thickness, drawW, verticalExtend);
      }
    }

    const trimY = isCeiling ? s.y + s.thickness - 7 : s.y;
    ctx.fillStyle = trim;
    ctx.fillRect(drawX, trimY, drawW, 7);

    // Clean vertical edge trim on raised steps so elevated platforms look crisp
    if (!isCeiling && s.y < BASE_FLOOR_Y) {
      ctx.fillRect(drawX, s.y, 4, BASE_FLOOR_Y - s.y + 7);
      ctx.fillRect(drawX + drawW - 4, s.y, 4, BASE_FLOOR_Y - s.y + 7);
    }

    ctx.save();
    ctx.beginPath();
    ctx.rect(s.x, s.y, s.width, s.thickness);
    ctx.clip();

    ctx.strokeStyle = trim;
    ctx.globalAlpha = 0.25;
    ctx.lineWidth = 2;

    const step = 48;
    const startX = Math.floor(s.x / step) * step;
    for (let px = startX; px < s.x + s.width + step; px += step) {
      const py = isCeiling ? s.y + s.thickness - 26 : s.y + 24;
      if (patternType === 'chevron' || patternType === 'stadium') {
        ctx.beginPath();
        ctx.moveTo(px, py - 8);
        ctx.lineTo(px + 12, py);
        ctx.lineTo(px, py + 8);
        ctx.stroke();
      } else if (patternType === 'industrial') {
        ctx.fillStyle = trim;
        ctx.fillRect(px, py - 4, 22, 8);
      } else if (patternType === 'crystal') {
        ctx.beginPath();
        ctx.moveTo(px, py);
        ctx.lineTo(px + 14, py - 9);
        ctx.lineTo(px + 28, py);
        ctx.stroke();
      } else {
        ctx.beginPath();
        ctx.moveTo(px, py);
        ctx.lineTo(px + 24, py);
        ctx.arc(px + 28, py, 3.5, 0, Math.PI * 2);
        ctx.stroke();
      }
    }
    ctx.restore();
  }
}

function drawWoodenCrate(ctx: CanvasRenderingContext2D, c: WoodenCrate): void {
  ctx.save();
  // Base wood fill
  ctx.fillStyle = '#c27828';
  ctx.fillRect(c.x, c.y, c.width, c.height);

  // Inner recessed wood panel
  const pad = 7;
  ctx.fillStyle = '#a35d18';
  ctx.fillRect(c.x + pad, c.y + pad, c.width - pad * 2, c.height - pad * 2);

  // Cross-brace planks
  ctx.strokeStyle = '#783f0d';
  ctx.lineWidth = 5;
  ctx.beginPath();
  ctx.moveTo(c.x + pad, c.y + pad);
  ctx.lineTo(c.x + c.width - pad, c.y + c.height - pad);
  ctx.moveTo(c.x + c.width - pad, c.y + pad);
  ctx.lineTo(c.x + pad, c.y + c.height - pad);
  ctx.stroke();

  // Plank divider horizontal line
  ctx.strokeStyle = '#5c2d06';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(c.x + pad, c.y + c.height * 0.5);
  ctx.lineTo(c.x + c.width - pad, c.y + c.height * 0.5);
  ctx.stroke();

  // Outer thick wood frame + black outline
  ctx.strokeStyle = '#5c2d06';
  ctx.lineWidth = 4;
  ctx.strokeRect(c.x + 2, c.y + 2, c.width - 4, c.height - 4);
  ctx.strokeStyle = '#090d16';
  ctx.lineWidth = 2.5;
  ctx.strokeRect(c.x, c.y, c.width, c.height);

  // Corner iron nails
  ctx.fillStyle = '#e5e7eb';
  const corners = [
    [c.x + 5, c.y + 5],
    [c.x + c.width - 5, c.y + 5],
    [c.x + 5, c.y + c.height - 5],
    [c.x + c.width - 5, c.y + c.height - 5],
  ];
  for (const [nx, ny] of corners) {
    ctx.beginPath();
    ctx.arc(nx, ny, 2.2, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

function drawWall(
  ctx: CanvasRenderingContext2D,
  w: WallObstacle,
  fill: string,
  trim: string,
): void {
  ctx.fillStyle = fill;
  ctx.fillRect(w.x, w.y, w.width, w.height);

  ctx.strokeStyle = trim;
  ctx.lineWidth = 3;
  ctx.strokeRect(w.x + 1.5, w.y + 1.5, w.width - 3, w.height - 3);

  ctx.save();
  ctx.beginPath();
  ctx.rect(w.x + 4, w.y + 4, w.width - 8, w.height - 8);
  ctx.clip();
  ctx.strokeStyle = trim;
  ctx.globalAlpha = 0.22;
  ctx.lineWidth = 5;
  for (let dy = w.y - w.width; dy < w.y + w.height + w.width; dy += 22) {
    ctx.beginPath();
    ctx.moveTo(w.x, dy);
    ctx.lineTo(w.x + w.width, dy + w.width * 0.65);
    ctx.stroke();
  }
  ctx.restore();
}

function drawSpikeTrap(
  ctx: CanvasRenderingContext2D,
  sp: SpikeTrap,
  fill: string,
  glow: string,
): void {
  ctx.save();
  ctx.fillStyle = fill;
  ctx.strokeStyle = '#0f172a';
  ctx.lineWidth = 1.8;
  ctx.shadowColor = glow;
  ctx.shadowBlur = 10;

  if (sp.dir === 'up' || sp.dir === 'down') {
    const toothW = 16;
    const count = Math.max(2, Math.round(sp.width / toothW));
    const step = sp.width / count;
    for (let i = 0; i < count; i++) {
      const x0 = sp.x + i * step;
      const xMid = x0 + step / 2;
      const x1 = x0 + step;
      ctx.beginPath();
      if (sp.dir === 'up') {
        ctx.moveTo(x0, sp.y);
        ctx.lineTo(xMid, sp.y - sp.height);
        ctx.lineTo(x1, sp.y);
      } else {
        ctx.moveTo(x0, sp.y);
        ctx.lineTo(xMid, sp.y + sp.height);
        ctx.lineTo(x1, sp.y);
      }
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
    }
  } else {
    const toothH = 16;
    const count = Math.max(2, Math.round(sp.height / toothH));
    const step = sp.height / count;
    for (let i = 0; i < count; i++) {
      const y0 = sp.y + i * step;
      const yMid = y0 + step / 2;
      const y1 = y0 + step;
      ctx.beginPath();
      if (sp.dir === 'left') {
        ctx.moveTo(sp.x, y0);
        ctx.lineTo(sp.x - sp.width, yMid);
        ctx.lineTo(sp.x, y1);
      } else {
        ctx.moveTo(sp.x, y0);
        ctx.lineTo(sp.x + sp.width, yMid);
        ctx.lineTo(sp.x, y1);
      }
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
    }
  }
  ctx.restore();
}

function drawBoostPad(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  surface: 'floor' | 'ceiling',
  now: number,
): void {
  const padY = surface === 'floor' ? y - 9 : y;
  const pulse = 0.72 + Math.sin(now * 0.01) * 0.25;
  ctx.save();
  ctx.fillStyle = `rgba(250, 204, 21, ${pulse})`;
  ctx.fillRect(x, padY, width, 9);

  ctx.strokeStyle = '#fef08a';
  ctx.lineWidth = 2.6;
  const chevY = surface === 'floor' ? padY - 9 : padY + 18;
  for (let cx = x + 14; cx < x + width - 10; cx += 20) {
    ctx.beginPath();
    ctx.moveTo(cx - 5, chevY - 5);
    ctx.lineTo(cx + 3, chevY);
    ctx.lineTo(cx - 5, chevY + 5);
    ctx.stroke();
  }
  ctx.restore();
}

function drawFinishLine(ctx: CanvasRenderingContext2D, finishX: number, now: number): void {
  ctx.save();
  const tile = 16;
  for (let y = BASE_CEILING_Y; y < BASE_FLOOR_Y; y += tile) {
    const row = Math.floor((y - BASE_CEILING_Y) / tile);
    for (let col = 0; col < 2; col++) {
      ctx.fillStyle = (row + col) % 2 === 0 ? '#ffffff' : '#0f172a';
      ctx.fillRect(finishX + col * tile, y, tile, Math.min(tile, BASE_FLOOR_Y - y));
    }
  }

  const glowPulse = 14 + Math.sin(now * 0.008) * 6;
  ctx.shadowColor = '#facc15';
  ctx.shadowBlur = glowPulse;
  ctx.strokeStyle = '#facc15';
  ctx.lineWidth = 5;
  ctx.strokeRect(finishX - 4, BASE_CEILING_Y, 40, BASE_FLOOR_Y - BASE_CEILING_Y);

  ctx.shadowBlur = 0;
  ctx.fillStyle = '#facc15';
  ctx.beginPath();
  ctx.roundRect(finishX - 36, BASE_CEILING_Y + 18, 104, 34, 10);
  ctx.fill();
  ctx.fillStyle = '#0f172a';
  ctx.font = '900 15px Cairo, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('🏁 النهاية', finishX + 16, BASE_CEILING_Y + 36);
  ctx.restore();
}

/**
 * Renders the custom ninja-crown character matching the user's reference image:
 * - Rounded dark charcoal body with thick black outline
 * - 3-peak golden crown on top
 * - Colored headband + fluttering tails + matching pill feet (Red / Blue / Purple)
 * - Two large white eyes with pupils looking right
 */
function drawCustomCharacter(
  ctx: CanvasRenderingContext2D,
  r: RunnerState,
  accent: string,
  label: string,
  isLocal: boolean,
): void {
  // Subtle motion trail
  for (let i = 0; i < r.trail.length; i++) {
    const tr = r.trail[i];
    ctx.save();
    ctx.globalAlpha = tr.alpha * 0.35;
    ctx.fillStyle = accent;
    ctx.beginPath();
    ctx.ellipse(tr.x + RUNNER_W / 2, tr.y + RUNNER_H / 2, 16, 18, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  ctx.save();
  const cx = r.x + RUNNER_W / 2;
  const cy = r.y + RUNNER_H / 2;
  ctx.translate(cx, cy);
  if (r.gravityDir === -1) {
    ctx.scale(1, -1);
  }
  ctx.scale(1.12, 1.12);

  const stride = r.grounded ? Math.sin(r.runPhase) * 6 : 3;

  // Speed boost aura
  if (r.boostTimer > 0) {
    ctx.strokeStyle = '#facc15';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.ellipse(0, 1, RUNNER_W * 0.62, RUNNER_H * 0.56, 0, 0, Math.PI * 2);
    ctx.stroke();
  }

  // 1. Two colored pill-shaped feet (team color + thick black outline)
  ctx.fillStyle = accent;
  ctx.strokeStyle = '#07090e';
  ctx.lineWidth = 3.2;

  ctx.beginPath();
  ctx.roundRect(-14 + stride, 16, 13, 10, 5);
  ctx.fill();
  ctx.stroke();

  ctx.beginPath();
  ctx.roundRect(2 - stride, 16, 13, 10, 5);
  ctx.fill();
  ctx.stroke();

  // 2. Dark slate rounded chubby body/head
  ctx.fillStyle = '#1f2937';
  ctx.strokeStyle = '#07090e';
  ctx.lineWidth = 3.5;
  ctx.beginPath();
  ctx.ellipse(0, 2, 18, 17, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();

  // 3. Two big white rounded eyes looking forward
  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.ellipse(3, 3, 6.2, 7.2, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.ellipse(11.5, 3, 5.6, 6.8, 0, 0, Math.PI * 2);
  ctx.fill();

  // Eye pupils
  ctx.fillStyle = '#07090e';
  ctx.beginPath();
  ctx.arc(5, 3.2, 2.2, 0, Math.PI * 2);
  ctx.arc(13.2, 3.2, 2.1, 0, Math.PI * 2);
  ctx.fill();

  // 4. Golden 3-peak crown above the headband
  ctx.fillStyle = '#facc15';
  ctx.strokeStyle = '#07090e';
  ctx.lineWidth = 3;
  ctx.lineJoin = 'round';
  ctx.beginPath();
  ctx.moveTo(-10, -13);
  ctx.lineTo(-12, -25);
  ctx.lineTo(-4, -19);
  ctx.lineTo(0, -27);
  ctx.lineTo(5, -19);
  ctx.lineTo(12, -25);
  ctx.lineTo(10, -13);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  // 5. Fluttering headband tails behind (left side)
  const wave = Math.sin(r.runPhase * 1.3) * 3;
  ctx.fillStyle = accent;
  ctx.strokeStyle = '#07090e';
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(-16, -9);
  ctx.lineTo(-27, -13 + wave);
  ctx.lineTo(-25, -7 + wave);
  ctx.lineTo(-16, -5);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  // 6. Main colored headband strap across forehead
  ctx.fillStyle = accent;
  ctx.strokeStyle = '#07090e';
  ctx.lineWidth = 3.2;
  ctx.beginPath();
  ctx.roundRect(-20, -14, 40, 9.5, 4.7);
  ctx.fill();
  ctx.stroke();

  ctx.restore();

  // Player Name Tag
  ctx.save();
  const tagY = r.gravityDir === 1 ? r.y - 12 : r.y + RUNNER_H + 17;
  ctx.font = '800 12px Cairo, sans-serif';
  ctx.textAlign = 'center';
  ctx.fillStyle = isLocal ? '#ffffff' : '#e2e8f0';
  ctx.strokeStyle = 'rgba(0,0,0,0.82)';
  ctx.lineWidth = 3.2;
  ctx.strokeText(label, r.x + RUNNER_W / 2, tagY);
  ctx.fillText(label, r.x + RUNNER_W / 2, tagY);
  ctx.restore();
}
